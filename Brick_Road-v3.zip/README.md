
  # Brick Road

  This is a code bundle for Brick Road. The original project is available at https://www.figma.com/design/csMMRPZL0IDJ5OlHJPZfb7/Brick-Road.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  