import { NavLink, Outlet, useLocation } from "react-router";
import { useEffect, useState } from "react";
import imgBg from "figma:asset/4848057d62f972cd7ff1167d004ac4f21357ad47.png";

const C = "#54ACBF";
const CA = (a: number) => `rgba(84,172,191,${a})`;

function NavBtn({ to, label, end }: { to: string; label: string; end?: boolean }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) =>
        `px-4 py-1.5 font-['Inter:Bold',sans-serif] font-bold text-[11px] tracking-[1.5px] uppercase transition-all duration-200 ${
          isActive
            ? "bg-[#54ACBF] text-[#020B10]"
            : "text-[#54ACBF] border border-[rgba(84,172,191,0.3)] hover:border-[rgba(84,172,191,0.6)] hover:bg-[rgba(84,172,191,0.1)]"
        }`
      }
    >
      {label}
    </NavLink>
  );
}

export default function Root() {
  const [utcTime, setUtcTime] = useState("");
  const [cpuLoad] = useState(12);
  const location = useLocation();

  const isRtl = location.pathname === "/rtl-sdr";
  const isPluto = location.pathname === "/pluto";
  const isBrickRoad = location.pathname === "/";

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      setUtcTime(
        now.toISOString().slice(11, 19) + " UTC"
      );
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const footerDevice = isRtl
    ? "RTL-SDR V3 DONGLE"
    : isPluto
    ? "PLUTOSDR_01_REV_B"
    : "MULTI-DEVICE HUB";

  const footerFirmware = isRtl ? "V4.2.0-RTL" : isPluto ? "V2.4.1-RC" : "V4.2.0";
  const footerBuffer = isPluto ? "1024 MS/S" : "1024 MS";

  return (
    <div className="relative flex flex-col min-h-screen bg-[#020B10] overflow-hidden">
      {/* Ambient background */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <img
          src={imgBg}
          alt=""
          className="absolute w-full h-[125%] top-[-12.5%] object-cover opacity-[0.12]"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[rgba(2,8,12,0.6)] via-transparent to-[rgba(2,8,12,0.8)]" />
      </div>

      {/* ── UNIFIED HEADER ── */}
      <header className="relative z-20 flex-shrink-0 border-b border-[rgba(84,172,191,0.18)] bg-[rgba(4,14,20,0.88)] backdrop-blur-xl">
        <div className="flex items-center justify-between px-6 py-2.5">
          {/* Brand + Nav */}
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3 pr-6 border-r border-[rgba(84,172,191,0.2)]">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#54ACBF] opacity-60" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#54ACBF]" />
              </span>
              <span className="font-['Inter:Black',sans-serif] font-black text-[#54ACBF] text-[13px] tracking-[2px] uppercase" style={{ textShadow: `0 0 12px ${CA(0.5)}` }}>
                BRICK ROAD
              </span>
              <span className="font-mono text-[rgba(84,172,191,0.4)] text-[10px] tracking-wider">
                FORENSIC HUD v4.2.0
              </span>
            </div>
            <nav className="flex items-center gap-1">
              <NavBtn to="/" label="LAUNCH PAD" end />
              <NavBtn to="/rtl-sdr" label="RTL-SDR" />
              <NavBtn to="/pluto" label="PLUTOSDR+" />
            </nav>
          </div>

          {/* Right status */}
          <div className="flex items-center gap-5">
            {isRtl && (
              <div className="flex items-center gap-2 px-3 py-1 border border-[rgba(84,172,191,0.3)] bg-[rgba(84,172,191,0.06)]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#54ACBF] shadow-[0_0_6px_#54ACBF]" />
                <span className="font-mono text-[#54ACBF] text-[10px] tracking-wider uppercase">V3_DONGLE_ACTIVE</span>
              </div>
            )}
            {isPluto && (
              <div className="flex items-center gap-2 px-3 py-1 border border-[rgba(84,172,191,0.3)] bg-[rgba(84,172,191,0.06)]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#54ACBF] shadow-[0_0_6px_#54ACBF]" />
                <span className="font-mono text-[#54ACBF] text-[10px] tracking-wider uppercase">PLUTO_01_REV_B</span>
              </div>
            )}
            {isBrickRoad && (
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#54ACBF] animate-pulse" />
                <span className="font-mono text-[rgba(84,172,191,0.7)] text-[10px] tracking-wider uppercase">SYSTEM NOMINAL</span>
              </div>
            )}
            <span className="font-mono text-[rgba(84,172,191,0.35)] text-[10px]">{utcTime}</span>
          </div>
        </div>
      </header>

      {/* ── MAIN CONTENT ── */}
      <main className="relative z-10 flex-1 flex flex-col min-h-0">
        <Outlet />
      </main>

      {/* ── UNIFIED FOOTER ── */}
      <footer className="relative z-20 flex-shrink-0 border-t border-[rgba(84,172,191,0.18)] bg-[rgba(4,14,20,0.88)] backdrop-blur-xl">
        <div className="flex items-center justify-between px-6 py-2">
          <div className="flex items-center gap-6">
            <span className="font-mono text-[rgba(84,172,191,0.45)] text-[10px] uppercase tracking-wider">
              DEVICE: {footerDevice}
            </span>
            <span className="text-[rgba(84,172,191,0.2)] text-xs">│</span>
            <span className="font-mono text-[rgba(84,172,191,0.45)] text-[10px] uppercase">
              BUFFER: {footerBuffer}
            </span>
            <span className="text-[rgba(84,172,191,0.2)] text-xs">│</span>
            <span className="font-mono text-[rgba(84,172,191,0.45)] text-[10px] uppercase">
              FIRMWARE: {footerFirmware}
            </span>
          </div>
          <div className="flex items-center gap-5">
            <div className="flex items-center gap-2">
              <span className="font-mono text-[rgba(84,172,191,0.45)] text-[10px] uppercase">CPU</span>
              <div className="w-16 h-1 bg-[rgba(84,172,191,0.1)]">
                <div className="h-full bg-[#54ACBF]" style={{ width: `${cpuLoad}%` }} />
              </div>
              <span className="font-mono text-[#54ACBF] text-[10px]">{cpuLoad}%</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#54ACBF]" />
              <span className="font-mono text-[#54ACBF] text-[10px] uppercase tracking-wider">SYSTEM NOMINAL</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
