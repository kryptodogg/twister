import { Plus, Rocket } from "lucide-react";
import { useRef, useEffect, useState } from "react";
import { motion } from "motion/react";
import { useNavigate } from "react-router";
import imgBg from "figma:asset/4848057d62f972cd7ff1167d004ac4f21357ad47.png";

const CA = (a: number) => `rgba(84,172,191,${a})`;

/* ─── Mini Spectrum Canvas (RTL-SDR card) ─── */
function RtlPreviewCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef(0);
  const dataRef = useRef(new Float32Array(16).fill(0.2));

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;

    const peaks = [3, 7, 10, 13];
    let t = 0;

    function draw() {
      t += 0.04;
      const W = canvas!.width, H = canvas!.height;
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = "rgba(2,10,15,0.0)";
      ctx.fillRect(0, 0, W, H);

      const N = dataRef.current.length;
      const barW = (W - (N + 1) * 3) / N;

      for (let i = 0; i < N; i++) {
        const isPeak = peaks.includes(i);
        const target = isPeak
          ? 0.35 + 0.45 * Math.abs(Math.sin(t * 0.8 + i * 0.6))
          : 0.05 + 0.2 * Math.abs(Math.sin(t * 1.2 + i * 1.1));
        dataRef.current[i] = dataRef.current[i] * 0.82 + target * 0.18;
        const h = dataRef.current[i] * H;
        const x = 3 + i * (barW + 3);

        const grad = ctx.createLinearGradient(0, H - h, 0, H);
        grad.addColorStop(0, isPeak ? "#54ACBF" : CA(0.6));
        grad.addColorStop(1, CA(0.15));
        ctx.fillStyle = grad;

        if (isPeak) {
          ctx.shadowColor = "#54ACBF";
          ctx.shadowBlur = 8;
        } else {
          ctx.shadowBlur = 0;
        }
        ctx.fillRect(x, H - h, barW, h);
        ctx.shadowBlur = 0;
      }
      frameRef.current = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(frameRef.current);
  }, []);

  return <canvas ref={ref} width={220} height={100} className="w-full h-full" />;
}

/* ─── Dual Wave Canvas (PlutoSDR+ card) ─── */
function PlutoPreviewCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef(0);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let t = 0;

    function draw() {
      t += 0.03;
      const W = canvas!.width, H = canvas!.height;
      ctx.clearRect(0, 0, W, H);

      // TX wave — brighter, thicker
      ctx.beginPath();
      ctx.strokeStyle = "#54ACBF";
      ctx.lineWidth = 2.5;
      ctx.shadowColor = "#54ACBF";
      ctx.shadowBlur = 10;
      for (let x = 0; x <= W; x += 2) {
        const y = H * 0.35 + Math.sin((x / W) * 5 * Math.PI + t * 2.2) * H * 0.22;
        x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.stroke();

      // TX label
      ctx.shadowBlur = 0;
      ctx.fillStyle = CA(0.5);
      ctx.font = "bold 8px monospace";
      ctx.fillText("TX", 4, H * 0.18);

      // RX wave — dimmer, different freq
      ctx.beginPath();
      ctx.strokeStyle = CA(0.5);
      ctx.lineWidth = 1.5;
      ctx.shadowColor = CA(0.4);
      ctx.shadowBlur = 6;
      for (let x = 0; x <= W; x += 2) {
        const y = H * 0.7 + Math.sin((x / W) * 7 * Math.PI + t * 1.5 + 1.2) * H * 0.18;
        x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.shadowBlur = 0;
      ctx.fillStyle = CA(0.35);
      ctx.fillText("RX", 4, H * 0.58);

      frameRef.current = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(frameRef.current);
  }, []);

  return <canvas ref={ref} width={220} height={100} className="w-full h-full" />;
}

/* ─── Radar Canvas (Phased Array card) ─── */
function RadarPreviewCanvas() {
  const ref = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef(0);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let angle = 0;

    function draw() {
      angle += 0.03;
      const W = canvas!.width, H = canvas!.height;
      const cx = W / 2, cy = H / 2;
      const R = Math.min(W, H) * 0.43;

      ctx.clearRect(0, 0, W, H);

      // Rings
      [0.33, 0.66, 1].forEach((r) => {
        ctx.beginPath();
        ctx.arc(cx, cy, R * r, 0, Math.PI * 2);
        ctx.strokeStyle = CA(0.15);
        ctx.lineWidth = 1;
        ctx.stroke();
      });

      // 8 radial lines (antenna elements)
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R);
        ctx.strokeStyle = CA(0.2);
        ctx.lineWidth = 1;
        ctx.stroke();
        // endpoint dot
        ctx.beginPath();
        ctx.arc(cx + Math.cos(a) * R, cy + Math.sin(a) * R, 2, 0, Math.PI * 2);
        ctx.fillStyle = CA(0.5);
        ctx.fill();
      }

      // Sweep sector
      const sweepWidth = 0.3;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, R, angle - sweepWidth, angle);
      ctx.closePath();
      const fillGrad = ctx.createLinearGradient(cx, cy, cx + R * Math.cos(angle), cy + R * Math.sin(angle));
      fillGrad.addColorStop(0, CA(0));
      fillGrad.addColorStop(1, CA(0.3));
      ctx.fillStyle = fillGrad;
      ctx.fill();
      ctx.restore();

      // Sweep line
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(angle) * R, cy + Math.sin(angle) * R);
      ctx.strokeStyle = "#54ACBF";
      ctx.lineWidth = 1.5;
      ctx.shadowColor = "#54ACBF";
      ctx.shadowBlur = 8;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Center dot
      ctx.beginPath();
      ctx.arc(cx, cy, 3, 0, Math.PI * 2);
      ctx.fillStyle = "#54ACBF";
      ctx.shadowColor = "#54ACBF";
      ctx.shadowBlur = 10;
      ctx.fill();
      ctx.shadowBlur = 0;

      frameRef.current = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(frameRef.current);
  }, []);

  return <canvas ref={ref} width={120} height={100} className="h-full mx-auto" style={{ width: "120px" }} />;
}

/* ─── GPIO Grid (Pico 2 card) ─── */
function GpioGrid() {
  const [active, setActive] = useState<Set<number>>(new Set([1, 4, 10]));

  useEffect(() => {
    const id = setInterval(() => {
      setActive((prev) => {
        const next = new Set(prev);
        const idx = Math.floor(Math.random() * 12);
        if (next.has(idx)) next.delete(idx);
        else next.add(idx);
        return next;
      });
    }, 300);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="grid grid-cols-6 gap-1.5 px-4">
      {Array.from({ length: 12 }, (_, i) => (
        <motion.div
          key={i}
          animate={{
            backgroundColor: active.has(i) ? "#54ACBF" : CA(0.18),
            boxShadow: active.has(i) ? `0 0 8px ${CA(0.8)}` : "none",
          }}
          transition={{ duration: 0.25 }}
          className="h-7 border"
          style={{ borderColor: CA(active.has(i) ? 0.7 : 0.25) }}
        />
      ))}
    </div>
  );
}

/* ─── Haptic Rings ─── */
function HapticRings() {
  return (
    <div className="flex items-center justify-center h-full">
      <div className="relative flex items-center justify-center" style={{ width: 100, height: 100 }}>
        {/* Outer ring */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 5, ease: "linear" }}
          className="absolute border border-[rgba(84,172,191,0.35)]"
          style={{ width: 100, height: 100 }}
        />
        {/* Diagonal rotated square */}
        <motion.div
          animate={{ rotate: [45, 405] }}
          transition={{ repeat: Infinity, duration: 7, ease: "linear" }}
          className="absolute border border-[rgba(84,172,191,0.5)]"
          style={{ width: 78, height: 78 }}
        />
        {/* Inner ring counter */}
        <motion.div
          animate={{ rotate: [0, -360] }}
          transition={{ repeat: Infinity, duration: 3.5, ease: "linear" }}
          className="absolute border border-[rgba(84,172,191,0.6)]"
          style={{ width: 52, height: 52 }}
        />
        {/* Center pulse */}
        <motion.div
          animate={{ scale: [1, 1.5, 1], opacity: [1, 0.4, 1] }}
          transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
          className="w-2 h-2 rounded-full bg-[#54ACBF] shadow-[0_0_10px_#54ACBF]"
        />
      </div>
    </div>
  );
}

/* ─── Card component ─── */
interface CardProps {
  title: string;
  status: "CONNECTED" | "UNWIRED" | "ADD";
  description: string;
  preview: React.ReactNode;
  features: string[];
  onClick?: () => void;
  dashed?: boolean;
}

function HardwareCard({ title, status, description, preview, features, onClick, dashed }: CardProps) {
  const [hovered, setHovered] = useState(false);

  const statusColor =
    status === "CONNECTED"
      ? { bg: CA(0.2), text: "#54ACBF", border: CA(0.5) }
      : status === "UNWIRED"
      ? { bg: "rgba(148,163,184,0.1)", text: "#94a3b8", border: "rgba(148,163,184,0.4)" }
      : { bg: CA(0.1), text: CA(0.7), border: CA(0.3) };

  return (
    <motion.div
      className="relative cursor-pointer flex flex-col"
      style={{
        background: CA(0.03),
        backdropFilter: "blur(8px)",
        border: `1px solid ${dashed ? CA(0.35) : CA(0.2)}`,
        borderStyle: dashed ? "dashed" : "solid",
        minHeight: 280,
      }}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      whileHover={{
        borderColor: CA(0.7),
        boxShadow: `0 0 24px ${CA(0.12)}, 0 0 2px ${CA(0.4)} inset`,
      }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-4 pb-3 border-b border-[rgba(84,172,191,0.12)]">
        <span className="font-['Inter:Bold',sans-serif] font-bold text-[#54ACBF] text-[11px] tracking-[1.5px] uppercase">
          {title}
        </span>
        <span
          className="font-['Inter:Bold',sans-serif] font-bold text-[9px] tracking-wider uppercase px-2 py-0.5"
          style={{ background: statusColor.bg, color: statusColor.text, border: `1px solid ${statusColor.border}` }}
        >
          [{status}]
        </span>
      </div>

      {/* Preview area */}
      <div className="flex-1 flex items-center justify-center py-4 px-2" style={{ minHeight: 110 }}>
        {preview}
      </div>

      {/* Feature tags — shown on hover */}
      <motion.div
        className="px-4 pb-2 flex flex-wrap gap-1.5"
        animate={{ opacity: hovered ? 1 : 0, y: hovered ? 0 : 4 }}
        transition={{ duration: 0.2 }}
      >
        {features.map((f) => (
          <span
            key={f}
            className="font-mono text-[8px] uppercase tracking-wider px-1.5 py-0.5"
            style={{ background: CA(0.08), color: CA(0.7), border: `1px solid ${CA(0.2)}` }}
          >
            {f}
          </span>
        ))}
      </motion.div>

      {/* Footer */}
      <div className="px-4 pb-4 flex items-center justify-between">
        <span
          className="font-['Inter:Medium',sans-serif] font-medium text-[#54ACBF] text-[10px] tracking-wider uppercase opacity-70"
        >
          {description}
        </span>
        {status !== "ADD" && (
          <motion.span
            className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-wider uppercase px-3 py-1"
            style={{ background: CA(0.2), color: "#54ACBF", border: `1px solid ${CA(0.5)}` }}
            animate={{ opacity: hovered ? 1 : 0, x: hovered ? 0 : 8 }}
            transition={{ duration: 0.2 }}
          >
            LAUNCH →
          </motion.span>
        )}
      </div>

      {/* Glow corners on hover */}
      <motion.div
        className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-[#54ACBF]"
        animate={{ opacity: hovered ? 1 : 0 }}
      />
      <motion.div
        className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-[#54ACBF]"
        animate={{ opacity: hovered ? 1 : 0 }}
      />
      <motion.div
        className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-[#54ACBF]"
        animate={{ opacity: hovered ? 1 : 0 }}
      />
      <motion.div
        className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-[#54ACBF]"
        animate={{ opacity: hovered ? 1 : 0 }}
      />
    </motion.div>
  );
}

/* ─── Main BrickRoad Page ─── */
export default function BrickRoad() {
  const navigate = useNavigate();

  return (
    <div className="relative flex flex-col min-h-[calc(100vh-88px)] overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0 pointer-events-none">
        <img
          src={imgBg}
          alt=""
          className="absolute w-full h-[125%] top-[-12.5%] object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[rgba(2,10,15,0.5)] to-[rgba(2,10,15,0.85)]" />
      </div>

      {/* Page header */}
      <div className="relative z-10 flex items-end justify-between px-10 pt-8 pb-5 border-b border-[rgba(84,172,191,0.12)]">
        <div className="flex flex-col">
          <h1
            className="font-['Inter:Black',sans-serif] font-black text-[#54ACBF] text-[52px] tracking-[-2px] leading-none uppercase"
            style={{ textShadow: `0 0 40px ${CA(0.35)}` }}
          >
            BRICK ROAD
          </h1>
          <span className="font-mono text-[rgba(84,172,191,0.45)] text-[11px] tracking-widest uppercase mt-1">
            SYSTEM_ID: Forensic HUD v4.2.0 — Hardware Integration Suite
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-end">
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[rgba(84,172,191,0.5)] text-[9px] tracking-wider uppercase">System Telemetry</span>
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[#54ACBF] text-[20px] tracking-tight" style={{ textShadow: `0 0 12px ${CA(0.4)}` }}>
              STABLE // 98.4% SCAN
            </span>
          </div>
          <div className="flex flex-col items-end ml-6">
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[rgba(84,172,191,0.5)] text-[9px] tracking-wider uppercase">Forensic Status</span>
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[#54ACBF] text-[20px] tracking-tight" style={{ textShadow: `0 0 12px ${CA(0.4)}` }}>
              ACTIVE
            </span>
          </div>
          <button
            onClick={() => navigate("/rtl-sdr")}
            className="flex items-center gap-2 px-6 py-2.5 ml-4 font-['Inter:Bold',sans-serif] font-bold text-[11px] tracking-[1.5px] uppercase transition-all duration-200 hover:shadow-[0_0_20px_rgba(84,172,191,0.3)]"
            style={{ background: CA(0.2), color: "#54ACBF", border: `1px solid ${CA(0.5)}` }}
          >
            <Rocket size={12} />
            DEPLOY SYSTEM
          </button>
        </div>
      </div>

      {/* Card Grid */}
      <div className="relative z-10 flex-1 px-10 py-8">
        <div className="grid grid-cols-3 gap-5 max-w-[1280px]">

          {/* RTL-SDR */}
          <HardwareCard
            title="RTL-SDR"
            status="CONNECTED"
            description="Spectral Density Bars"
            features={["0–1766 MHz", "WFM/NFM/AM/SSB/CW", "LNA Gain", "Bias Tee", "Waterfall", "Scanner"]}
            preview={
              <div className="w-full h-[100px]">
                <RtlPreviewCanvas />
              </div>
            }
            onClick={() => navigate("/rtl-sdr")}
          />

          {/* PlutoSDR+ */}
          <HardwareCard
            title="PlutoSDR+"
            status="CONNECTED"
            description="Dual Wave Monitors (TX/RX)"
            features={["2TX + 2RX", "70 MHz–6 GHz", "Full Duplex", "Waveform Gen", "IQ Analysis", "Decode"]}
            preview={
              <div className="w-full h-[100px]">
                <PlutoPreviewCanvas />
              </div>
            }
            onClick={() => navigate("/pluto")}
          />

          {/* Haptic DualSense */}
          <HardwareCard
            title="Haptic (DualSense)"
            status="UNWIRED"
            description="3D DCC-Style Orientation Rings"
            features={["Gyroscope", "Accelerometer", "Haptic FB", "Bluetooth", "USB-C"]}
            preview={<HapticRings />}
          />

          {/* Pico 2 */}
          <HardwareCard
            title="Pico 2"
            status="CONNECTED"
            description="Graphical GPIO Map"
            features={["26 GPIO", "2× SPI", "2× I²C", "2× UART", "ADC", "RP2350"]}
            preview={
              <div className="w-full">
                <GpioGrid />
              </div>
            }
          />

          {/* 8-Channel Phased Array */}
          <HardwareCard
            title="8-Channel Phased Array"
            status="CONNECTED"
            description="Radar / Disc Display"
            features={["8-Element", "Beam Steering", "DOA Est.", "MIMO", "2.4 GHz"]}
            preview={<RadarPreviewCanvas />}
          />

          {/* Add Hardware */}
          <HardwareCard
            title="Integrate Hardware"
            status="ADD"
            dashed
            description="Add new hardware device"
            features={[]}
            preview={
              <div className="flex flex-col items-center gap-3">
                <motion.div
                  animate={{
                    opacity: [0.5, 1, 0.5],
                    scale: [0.9, 1.05, 0.9],
                    boxShadow: [`0 0 0px ${CA(0)}`, `0 0 20px ${CA(0.4)}`, `0 0 0px ${CA(0)}`],
                  }}
                  transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut" }}
                  className="w-12 h-12 rounded-full border-2 border-[rgba(84,172,191,0.5)] flex items-center justify-center"
                >
                  <Plus size={22} color="#54ACBF" />
                </motion.div>
                <span className="font-['Inter:Bold',sans-serif] font-bold text-[#54ACBF] text-[10px] tracking-[3px] uppercase">
                  Integrate Hardware
                </span>
              </div>
            }
          />
        </div>
      </div>

      {/* Latency badge bottom-right */}
      <div className="relative z-10 flex items-center justify-end px-10 pb-6 gap-4">
        <div className="flex flex-col items-end">
          <span className="font-['Inter:Bold',sans-serif] font-bold text-[rgba(84,172,191,0.5)] text-[9px] tracking-wider uppercase">Latency</span>
          <span className="font-['Inter:Medium',sans-serif] font-medium text-[#54ACBF] text-[18px] tracking-tight">12ms</span>
        </div>
      </div>
    </div>
  );
}