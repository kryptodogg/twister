import { useRef, useEffect, useState } from "react";
import imgTxBg from "figma:asset/6cdc195c8d447e165439b039ff926d8db70d89fb.png";
import imgRxBg from "figma:asset/cf93f596ab63cd0a9efacd3364a5dfa7414b2e67.png";
import { AlertTriangle, CheckCircle, Thermometer, Zap, Radio, Activity, Settings, Cpu, BarChart3, MessageSquare } from "lucide-react";

const CA = (a: number) => `rgba(84,172,191,${a})`;
const PANEL = { background: CA(0.04), border: `1px solid ${CA(0.25)}` };

/* ── Waveform Canvas (TX) ── */
function WaveformCanvas({ tx1On, tx2On }: { tx1On: boolean; tx2On: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef(0);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let t = 0;
    function draw() {
      t += 0.025;
      const W = canvas!.width, H = canvas!.height;
      ctx.fillStyle = "rgba(2,10,15,0.1)";
      ctx.fillRect(0, 0, W, H);

      // Grid lines
      ctx.strokeStyle = CA(0.06);
      ctx.lineWidth = 1;
      for (let y = 0; y < H; y += H / 4) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
      }

      if (tx1On) {
        ctx.beginPath();
        ctx.strokeStyle = "#54ACBF";
        ctx.lineWidth = 2.5;
        ctx.shadowColor = "#54ACBF";
        ctx.shadowBlur = 10;
        for (let x = 0; x <= W; x += 2) {
          const y = H * 0.3 + Math.sin((x / W) * 4 * Math.PI + t * 2.5) * H * 0.2;
          x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        }
        ctx.stroke();
        // TX1 label
        ctx.shadowBlur = 0;
        ctx.fillStyle = CA(0.6);
        ctx.font = "bold 9px monospace";
        ctx.fillText("TX-1  2.412 GHz", 8, 14);
      }

      if (tx2On) {
        ctx.beginPath();
        ctx.strokeStyle = CA(0.45);
        ctx.lineWidth = 1.8;
        ctx.shadowColor = CA(0.4);
        ctx.shadowBlur = 6;
        for (let x = 0; x <= W; x += 2) {
          const y = H * 0.7 + Math.sin((x / W) * 6.5 * Math.PI + t * 1.8 + 0.9) * H * 0.17;
          x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        }
        ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.fillStyle = CA(0.4);
        ctx.font = "bold 9px monospace";
        ctx.fillText("TX-2  5.800 GHz", 8, H - 6);
      }

      // Amplitude & phase label
      ctx.fillStyle = CA(0.35);
      ctx.font = "9px monospace";
      ctx.fillText("AMPLITUDE  PHASE OFFSET", W - 160, H - 6);
      ctx.fillStyle = "#54ACBF";
      ctx.font = "bold 14px monospace";
      ctx.fillText("1.44V  12.5°", W - 120, H - 20);

      frameRef.current = requestAnimationFrame(draw);
    }
    ctx.fillStyle = "rgba(2,10,15,0.95)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    draw();
    return () => cancelAnimationFrame(frameRef.current);
  }, [tx1On, tx2On]);

  return <canvas ref={ref} width={900} height={320} className="w-full h-full" />;
}

/* ── RX Spectrum Canvas ── */
function RxSpectrumCanvas({ channelIdx, locked }: { channelIdx: number; locked: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef(0);
  const dataRef = useRef(new Float32Array(256).fill(-90));

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const N = 256;
    const peaks = channelIdx === 0
      ? [{ bin: 60, p: -82, w: 18 }, { bin: 110, p: -68, w: 6 }, { bin: 160, p: -72, w: 14 }]
      : [{ bin: 120, p: -105, w: 5 }];
    let t = 0, last = 0;

    function loop(ts: number) {
      if (ts - last > 50) {
        last = ts; t += 0.016;
        const data = dataRef.current;
        for (let i = 0; i < N; i++) data[i] = -93 + (Math.random() - 0.5) * 5;
        peaks.forEach(({ bin, p, w }) => {
          const wob = Math.sin(t * 0.4 + bin * 0.05) * 2;
          for (let d = -w * 2; d <= w * 2; d++) {
            const idx = bin + d;
            if (idx < 0 || idx >= N) continue;
            const env = Math.exp(-(d * d) / (w * w));
            const v = (p + wob) * env;
            if (v > data[idx]) data[idx] = v;
          }
        });

        const W = canvas!.width, H = canvas!.height;
        ctx.fillStyle = "rgba(2,10,15,0.95)";
        ctx.fillRect(0, 0, W, H);

        // Grid
        ctx.strokeStyle = CA(0.07);
        ctx.lineWidth = 1;
        for (let i = 0; i <= 4; i++) {
          const x = (W / 4) * i;
          ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
        }
        [-100, -90, -80, -70, -60].forEach((db) => {
          const y = H - ((db + 110) / 60) * H;
          ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
          ctx.fillStyle = CA(0.25); ctx.font = "8px monospace";
          ctx.fillText(`${db}`, 2, y - 1);
        });

        // Fill
        ctx.beginPath();
        for (let i = 0; i < N; i++) {
          const x = (i / N) * W;
          const y = H - ((data[i] + 110) / 60) * H;
          i === 0 ? ctx.moveTo(x, Math.max(0, y)) : ctx.lineTo(x, Math.max(0, y));
        }
        ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath();
        const grad = ctx.createLinearGradient(0, 0, 0, H);
        grad.addColorStop(0, CA(locked ? 0.35 : 0.12));
        grad.addColorStop(1, CA(0.02));
        ctx.fillStyle = grad; ctx.fill();

        // Line
        ctx.beginPath();
        ctx.strokeStyle = locked ? "#54ACBF" : CA(0.4);
        ctx.lineWidth = 1.5;
        ctx.shadowColor = locked ? "#54ACBF" : CA(0.4);
        ctx.shadowBlur = locked ? 4 : 2;
        for (let i = 0; i < N; i++) {
          const x = (i / N) * W;
          const y = H - ((data[i] + 110) / 60) * H;
          i === 0 ? ctx.moveTo(x, Math.max(0, y)) : ctx.lineTo(x, Math.max(0, y));
        }
        ctx.stroke(); ctx.shadowBlur = 0;
      }
      frameRef.current = requestAnimationFrame(loop);
    }
    frameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frameRef.current);
  }, [channelIdx, locked]);

  return <canvas ref={ref} width={600} height={180} className="w-full block" />;
}

/* ── IQ Constellation Canvas ── */
function ConstellationCanvas({ modType }: { modType: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef(0);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let t = 0;
    const pts: { x: number; y: number }[] = [];
    const N = 400;

    const constellations: Record<string, { x: number; y: number }[]> = {
      PSK: [{ x: 0.7, y: 0 }, { x: -0.7, y: 0 }, { x: 0, y: 0.7 }, { x: 0, y: -0.7 }, { x: 0.5, y: 0.5 }, { x: -0.5, y: 0.5 }, { x: 0.5, y: -0.5 }, { x: -0.5, y: -0.5 }],
      QAM: [{ x: 0.3, y: 0.3 }, { x: -0.3, y: 0.3 }, { x: 0.3, y: -0.3 }, { x: -0.3, y: -0.3 }, { x: 0.7, y: 0.3 }, { x: -0.7, y: 0.3 }, { x: 0.7, y: -0.3 }, { x: -0.7, y: -0.3 }, { x: 0.3, y: 0.7 }, { x: -0.3, y: 0.7 }, { x: 0.3, y: -0.7 }, { x: -0.3, y: -0.7 }, { x: 0.7, y: 0.7 }, { x: -0.7, y: 0.7 }, { x: 0.7, y: -0.7 }, { x: -0.7, y: -0.7 }],
      OFDM: Array.from({ length: 20 }, (_, i) => ({ x: (Math.random() - 0.5) * 1.4, y: (Math.random() - 0.5) * 1.4 })),
      DSSS: Array.from({ length: 6 }, (_, i) => { const a = (i / 6) * Math.PI * 2; return { x: Math.cos(a) * 0.7, y: Math.sin(a) * 0.7 }; }),
    };

    const basePoints = constellations[modType] || constellations.PSK;

    function draw(ts: number) {
      t = ts * 0.001;
      const W = canvas!.width, H = canvas!.height;
      const cx = W / 2, cy = H / 2, r = Math.min(W, H) * 0.42;

      ctx.fillStyle = "rgba(2,10,15,0.15)";
      ctx.fillRect(0, 0, W, H);

      // Grid circles
      ctx.strokeStyle = CA(0.08); ctx.lineWidth = 1;
      [0.3, 0.6, 1].forEach((fr) => {
        ctx.beginPath(); ctx.arc(cx, cy, r * fr, 0, Math.PI * 2); ctx.stroke();
      });
      ctx.beginPath(); ctx.moveTo(cx - r, cy); ctx.lineTo(cx + r, cy); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(cx, cy - r); ctx.lineTo(cx, cy + r); ctx.stroke();

      // Labels
      ctx.fillStyle = CA(0.3); ctx.font = "8px monospace";
      ctx.fillText("I", cx + r + 2, cy + 3);
      ctx.fillText("Q", cx + 2, cy - r - 2);

      // Add new scattered points
      const idx = Math.floor(Math.random() * basePoints.length);
      const bp = basePoints[idx];
      pts.push({
        x: bp.x + (Math.random() - 0.5) * 0.08,
        y: bp.y + (Math.random() - 0.5) * 0.08,
      });
      if (pts.length > N) pts.shift();

      // Draw points
      pts.forEach((pt, i) => {
        const alpha = (i / pts.length) * 0.8;
        const px = cx + pt.x * r;
        const py = cy + pt.y * r;
        ctx.beginPath();
        ctx.arc(px, py, 2, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(84,172,191,${alpha})`;
        ctx.fill();
      });

      frameRef.current = requestAnimationFrame(draw);
    }

    ctx.fillStyle = "rgba(2,10,15,0.95)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    frameRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frameRef.current);
  }, [modType]);

  return <canvas ref={ref} width={300} height={300} className="w-full aspect-square" />;
}

/* ── Toggle ── */
function Toggle({ checked, onChange }: { checked: boolean; onChange: () => void }) {
  return (
    <button onClick={onChange} className="relative w-10 h-5 transition-colors duration-200"
      style={{ background: checked ? CA(0.5) : CA(0.1), border: `1px solid ${CA(checked ? 0.8 : 0.3)}` }}>
      <span className="absolute top-0.5 h-4 w-4 transition-all duration-200"
        style={{ background: checked ? "#54ACBF" : CA(0.4), left: checked ? "calc(100% - 18px)" : "2px", boxShadow: checked ? `0 0 8px ${CA(0.8)}` : "none" }} />
    </button>
  );
}

/* ── Labeled Slider ── */
function LabeledSlider({ label, value, min, max, step, unit, onChange }: {
  label: string; value: number; min: number; max: number; step: number; unit: string; onChange: (v: number) => void;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <span className="font-['Inter:Bold',sans-serif] font-bold text-[#54ACBF] text-[10px] tracking-[1px] uppercase">{label}</span>
        <span className="font-mono text-[#54ACBF] text-[11px]">{value.toFixed(typeof step === 'number' && step < 1 ? 1 : 0)} {unit}</span>
      </div>
      <div className="relative h-1 w-full" style={{ background: CA(0.1) }}>
        <div className="absolute top-0 left-0 h-full" style={{ width: `${((value - min) / (max - min)) * 100}%`, background: CA(0.6) }} />
        <input type="range" min={min} max={max} step={step} value={value}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="absolute inset-0 w-full opacity-0 cursor-pointer h-full" />
      </div>
    </div>
  );
}

/* ── Section header ── */
function SH({ label, badge }: { label: string; badge?: string }) {
  return (
    <div className="flex items-center justify-between mb-2.5 pb-1.5 border-b border-[rgba(84,172,191,0.15)]">
      <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-[2px] uppercase text-[#54ACBF]">{label}</span>
      {badge && <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px] uppercase">{badge}</span>}
    </div>
  );
}

/* ── Mode Button ── */
function ModeBtn({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick}
      className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-wider uppercase py-1.5 px-2 transition-all duration-150"
      style={{ background: active ? "#54ACBF" : CA(0.05), color: active ? "#020B10" : "#54ACBF", border: `1px solid ${active ? "#54ACBF" : CA(0.2)}` }}>
      {label}
    </button>
  );
}

/* ── Value field ── */
function ValueField({ label, value, unit, onChange, min = 0, max = 9999, step = 0.001 }: {
  label: string; value: number; unit: string; onChange?: (v: number) => void; min?: number; max?: number; step?: number;
}) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-[rgba(84,172,191,0.1)]">
      <span className="font-['Inter:Bold',sans-serif] font-bold text-[9px] uppercase tracking-wider text-[rgba(84,172,191,0.55)]">{label}</span>
      <div className="flex items-baseline gap-1">
        <span className="font-['Liberation_Mono:Regular',monospace] text-[#54ACBF] text-[16px]">{value}</span>
        <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px]">{unit}</span>
      </div>
    </div>
  );
}

/* ── Stat Box ── */
function StatBox({ label, value, unit }: { label: string; value: string; unit?: string }) {
  return (
    <div className="flex flex-col p-3 gap-1" style={{ background: CA(0.04), border: `1px solid ${CA(0.2)}` }}>
      <span className="font-mono text-[rgba(84,172,191,0.45)] text-[8px] uppercase tracking-wider">{label}</span>
      <div className="flex items-baseline gap-1">
        <span className="font-['Liberation_Mono:Regular',monospace] text-[#54ACBF] text-[22px]">{value}</span>
        {unit && <span className="font-mono text-[rgba(84,172,191,0.6)] text-[10px]">{unit}</span>}
      </div>
    </div>
  );
}

/* ── Waveform button ── */
function WaveBtn({ label, icon, active, onClick }: { label: string; icon: React.ReactNode; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick}
      className="flex flex-col items-center gap-1.5 py-3 transition-all"
      style={{ background: active ? CA(0.2) : CA(0.04), border: `1px solid ${active ? "#54ACBF" : CA(0.2)}`, boxShadow: active ? `0 0 12px ${CA(0.25)}` : "none" }}>
      <span style={{ color: active ? "#54ACBF" : CA(0.5) }}>{icon}</span>
      <span className="font-['Inter:Bold',sans-serif] font-bold text-[9px] uppercase tracking-wider" style={{ color: active ? "#54ACBF" : CA(0.5) }}>{label}</span>
    </button>
  );
}

/* ══════════════════════════════════════════
   TAB: TRANSMISSION
══════════════════════════════════════════ */
function TransmissionTab() {
  const [tx1 ] = useState({ freq: 2.412, gain: -12.0, bw: 56, port: "A" });
  const [tx2] = useState({ freq: 5.800, gain: -0.0, bw: 56, port: "B" });
  const [tx1On, setTx1On] = useState(true);
  const [tx2On, setTx2On] = useState(false);
  const [waveform, setWaveform] = useState("SINE");
  const [dutyCycle, setDutyCycle] = useState(50);
  const [modDepth, setModDepth] = useState(85);
  const [tx1Freq, setTx1Freq] = useState(2.412);
  const [tx1Gain, setTx1Gain] = useState(-12.0);
  const [tx2Freq, setTx2Freq] = useState(5.800);
  const [tx2Gain, setTx2Gain] = useState(-0.0);

  const WAVEFORMS = [
    { id: "SINE", label: "SINE", icon: <svg width={20} height={14} viewBox="0 0 20 14"><path d="M0,7 Q2.5,0 5,7 Q7.5,14 10,7 Q12.5,0 15,7 Q17.5,14 20,7" stroke="currentColor" strokeWidth="1.5" fill="none"/></svg> },
    { id: "SAW", label: "SAW", icon: <svg width={20} height={14} viewBox="0 0 20 14"><path d="M0,14 L7,0 L7,14 L14,0 L14,14 L20,0" stroke="currentColor" strokeWidth="1.5" fill="none"/></svg> },
    { id: "SQUARE", label: "SQUARE", icon: <svg width={20} height={14} viewBox="0 0 20 14"><path d="M0,14 L0,2 L8,2 L8,14 L16,14 L16,2 L20,2" stroke="currentColor" strokeWidth="1.5" fill="none"/></svg> },
    { id: "IMPULSE_UWB", label: "IMPULSE UWB", icon: <svg width={20} height={16} viewBox="0 0 20 16"><path d="M0,12 L6,12 L8,2 L10,14 L12,2 L14,12 L20,12" stroke="currentColor" strokeWidth="1.5" fill="none"/></svg> },
  ];

  return (
    <div className="flex h-full gap-0">
      {/* Left column */}
      <div className="w-[320px] flex-shrink-0 flex flex-col gap-0 border-r border-[rgba(84,172,191,0.15)] overflow-y-auto bg-[rgba(4,14,20,0.5)] backdrop-blur-sm">
        <div className="p-5 flex flex-col gap-5">

          {/* TX Channel 1 */}
          <div style={{ background: CA(0.04), border: `1px solid ${CA(tx1On ? 0.4 : 0.15)}` }}>
            <div className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: CA(0.12), background: CA(0.06) }}>
              <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-[2px] uppercase text-[#54ACBF]">Channel TX-1</span>
              <div className="flex items-center gap-3">
                <span className="font-mono text-[9px] uppercase" style={{ color: tx1On ? "#54ACBF" : CA(0.4) }}>{tx1On ? "ACTIVE" : "STANDBY"}</span>
                <Toggle checked={tx1On} onChange={() => setTx1On(!tx1On)} />
              </div>
            </div>
            <div className="px-4 py-3">
              <ValueField label="Frequency" value={tx1Freq} unit="GHz" />
              <ValueField label="Gain" value={tx1Gain} unit="dBm" />
              <div className="pt-2">
                <LabeledSlider label="Freq" value={tx1Freq} min={0.07} max={6} step={0.001} unit="GHz" onChange={setTx1Freq} />
                <div className="mt-2">
                  <LabeledSlider label="Gain" value={tx1Gain} min={-89.75} max={0} step={0.25} unit="dBm" onChange={setTx1Gain} />
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)]">RF Port</span>
                  {["A","B"].map(p => (
                    <button key={p} className="px-3 py-1 font-mono text-[9px] transition-all"
                      style={{ background: tx1.port === p ? CA(0.2) : CA(0.04), color: "#54ACBF", border: `1px solid ${CA(tx1.port === p ? 0.5 : 0.2)}` }}>{p}</button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* TX Channel 2 */}
          <div style={{ background: CA(tx2On ? 0.04 : 0.02), border: `1px solid ${CA(tx2On ? 0.35 : 0.12)}` }}>
            <div className="flex items-center justify-between px-4 py-2.5 border-b" style={{ borderColor: CA(0.12), background: CA(0.03) }}>
              <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-[2px] uppercase" style={{ color: tx2On ? "#54ACBF" : CA(0.4) }}>Channel TX-2</span>
              <div className="flex items-center gap-3">
                <span className="font-mono text-[9px] uppercase" style={{ color: tx2On ? "#54ACBF" : CA(0.35) }}>{tx2On ? "ACTIVE" : "STANDBY"}</span>
                <Toggle checked={tx2On} onChange={() => setTx2On(!tx2On)} />
              </div>
            </div>
            <div className="px-4 py-3" style={{ opacity: tx2On ? 1 : 0.45 }}>
              <ValueField label="Frequency" value={tx2Freq} unit="GHz" />
              <ValueField label="Gain" value={tx2Gain.toFixed(1)} unit="dBm" />
              {tx2On && (
                <div className="pt-2">
                  <LabeledSlider label="Freq" value={tx2Freq} min={0.07} max={6} step={0.001} unit="GHz" onChange={setTx2Freq} />
                  <div className="mt-2">
                    <LabeledSlider label="Gain" value={tx2Gain} min={-89.75} max={0} step={0.25} unit="dBm" onChange={setTx2Gain} />
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)]">RF Port</span>
                    {["A","B"].map(p => (
                      <button key={p} className="px-3 py-1 font-mono text-[9px]"
                        style={{ background: tx2.port === p ? CA(0.2) : CA(0.04), color: "#54ACBF", border: `1px solid ${CA(tx2.port === p ? 0.5 : 0.2)}` }}>{p}</button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Waveform Generator */}
          <div style={{ background: CA(0.03), border: `1px solid ${CA(0.2)}` }}>
            <div className="px-4 py-2 border-b flex items-center gap-2" style={{ borderColor: CA(0.12), background: CA(0.08) }}>
              <Activity size={10} color="#54ACBF" />
              <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-[2px] uppercase text-[#54ACBF]">Waveform Generator</span>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-2 gap-2 mb-4">
                {WAVEFORMS.map((wf) => (
                  <WaveBtn key={wf.id} label={wf.label} icon={wf.icon} active={waveform === wf.id} onClick={() => setWaveform(wf.id)} />
                ))}
              </div>
              <div className="flex flex-col gap-3">
                <LabeledSlider label="Duty Cycle" value={dutyCycle} min={0} max={100} step={1} unit="%" onChange={setDutyCycle} />
                <LabeledSlider label="Modulation Depth" value={modDepth} min={0} max={100} step={1} unit="%" onChange={setModDepth} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right: Waveform display + stats */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <div className="flex-1 relative min-h-0">
          {/* BG */}
          <div className="absolute inset-0 pointer-events-none">
            <img src={imgTxBg} alt="" className="absolute w-full h-[125%] top-[-12.5%] object-cover opacity-15" />
            <div className="absolute inset-0 bg-[rgba(2,10,15,0.6)]" />
          </div>
          <div className="relative z-10 p-5 h-full flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <span className="font-mono text-[rgba(84,172,191,0.45)] text-[9px] uppercase tracking-wider">REAL-TIME 3D WAVEFORM ANALYSIS</span>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#54ACBF] animate-pulse" />
                <span className="font-mono text-[rgba(84,172,191,0.6)] text-[9px]">LIVE</span>
              </div>
            </div>
            <div className="flex-1 min-h-0 border" style={{ borderColor: CA(0.15) }}>
              <WaveformCanvas tx1On={tx1On} tx2On={tx2On} />
            </div>
          </div>
        </div>

        {/* Stats row */}
        <div className="flex-shrink-0 grid grid-cols-4 gap-px bg-[rgba(84,172,191,0.1)] border-t border-[rgba(84,172,191,0.15)]">
          <StatBox label="SWR" value="1.12:1" />
          <StatBox label="Efficiency" value="94.2" unit="%" />
          <StatBox label="Temperature" value="42.8" unit="°C" />
          <div className="flex flex-col p-3 gap-1" style={{ background: CA(0.04) }}>
            <span className="font-mono text-[rgba(84,172,191,0.45)] text-[8px] uppercase tracking-wider">Signal Status</span>
            <span className="font-['Inter:Black',sans-serif] font-black text-[#54ACBF] text-[16px] leading-tight">{tx1On || tx2On ? "TRANSMITTING" : "IDLE"}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   TAB: RECEPTION
══════════════════════════════════════════ */
function ReceptionTab() {
  const [rx1] = useState({ freq: 104.700, gain: 42.5, bw: 200, port: "A" });
  const [rx2] = useState({ freq: 2.442, gain: 18.0, bw: 20, port: "B" });
  const [rx1Locked, setRx1Locked] = useState(true);
  const [rx2Locked, setRx2Locked] = useState(false);
  const [rx1Mode, setRx1Mode] = useState("WFM");
  const [rx2Mode, setRx2Mode] = useState("PSK");
  const [rx1Freq, setRx1Freq] = useState(104.700);
  const [rx1Gain, setRx1Gain] = useState(42.5);
  const [rx2Freq, setRx2Freq] = useState(2442);
  const [rx2Gain, setRx2Gain] = useState(18.0);
  const [rx1AgcMode, setRx1AgcMode] = useState("slow");
  const [rx2AgcMode, setRx2AgcMode] = useState("manual");
  const [rx1DcCorr, setRx1DcCorr] = useState(true);
  const [rx2DcCorr, setRx2DcCorr] = useState(true);

  const RX1_MODES = ["WFM", "NFM", "AM", "LSB", "USB", "CW"];
  const RX2_MODES = ["AUTO", "PSK", "QAM", "OFDM", "DSSS"];
  const AGC_MODES = ["fast", "slow", "manual"];

  return (
    <div className="flex h-full">
      {/* RX1 column */}
      <div className="flex-1 flex flex-col border-r border-[rgba(84,172,191,0.15)] min-w-0">
        {/* RX1 Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[rgba(84,172,191,0.15)]" style={{ background: CA(0.04) }}>
          <span className="font-['Inter:Bold',sans-serif] font-bold text-[#54ACBF] text-[11px] tracking-[1.5px] uppercase">RX1 – Channel Alpha</span>
          <div className="flex items-center gap-2">
            <span className="font-mono text-[9px] px-2 py-0.5" style={{ background: CA(rx1Locked ? 0.2 : 0.06), color: rx1Locked ? "#54ACBF" : CA(0.4), border: `1px solid ${CA(rx1Locked ? 0.5 : 0.2)}` }}>
              {rx1Locked ? "LOCKED" : "SEARCHING"} / {rx1Freq.toFixed(3)} {rx1Freq < 1000 ? "MHz" : "GHz"}
            </span>
            <Toggle checked={rx1Locked} onChange={() => setRx1Locked(!rx1Locked)} />
          </div>
        </div>

        {/* RX1 controls */}
        <div className="flex gap-0 flex-shrink-0 border-b border-[rgba(84,172,191,0.12)]">
          {[
            { label: "Frequency", value: `${rx1Freq.toFixed(3)}`, unit: rx1Freq < 1000 ? "MHz" : "GHz" },
            { label: "Gain", value: rx1Gain.toFixed(1), unit: "dB" },
            { label: "Bandwidth", value: "200", unit: "kHz" },
          ].map((f) => (
            <div key={f.label} className="flex-1 p-3 border-r" style={{ borderColor: CA(0.1), background: CA(0.025) }}>
              <span className="font-mono text-[8px] uppercase tracking-wider block text-[rgba(84,172,191,0.45)]">{f.label}</span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="font-['Liberation_Mono:Regular',monospace] text-[#54ACBF] text-[17px]">{f.value}</span>
                <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px]">{f.unit}</span>
              </div>
            </div>
          ))}
        </div>

        {/* RX1 inline controls */}
        <div className="px-4 py-3 flex flex-col gap-2 border-b border-[rgba(84,172,191,0.1)]" style={{ background: CA(0.02) }}>
          <LabeledSlider label="Freq (MHz)" value={rx1Freq} min={70} max={6000} step={0.001} unit="MHz" onChange={setRx1Freq} />
          <LabeledSlider label="Gain" value={rx1Gain} min={0} max={73} step={1} unit="dB" onChange={setRx1Gain} />
          <div className="flex items-center justify-between">
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[9px] uppercase tracking-wider text-[#54ACBF]">AGC Mode</span>
            <div className="flex gap-1">
              {AGC_MODES.map(m => (
                <button key={m} onClick={() => setRx1AgcMode(m)}
                  className="font-mono text-[8px] uppercase px-2 py-1 transition-all"
                  style={{ background: rx1AgcMode === m ? CA(0.2) : CA(0.04), color: rx1AgcMode === m ? "#54ACBF" : CA(0.5), border: `1px solid ${CA(rx1AgcMode === m ? 0.5 : 0.15)}` }}>{m}</button>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[9px] uppercase tracking-wider text-[#54ACBF]">DC Correction</span>
            <Toggle checked={rx1DcCorr} onChange={() => setRx1DcCorr(!rx1DcCorr)} />
          </div>
        </div>

        {/* RX1 Spectrum */}
        <div className="flex-1 relative min-h-0">
          <div className="absolute inset-0 pointer-events-none">
            <img src={imgRxBg} alt="" className="absolute w-full h-[125%] top-[-12.5%] object-cover opacity-10" />
          </div>
          <div className="relative z-10 p-3 h-full flex flex-col">
            <span className="font-mono text-[rgba(84,172,191,0.4)] text-[8px] uppercase mb-1">HOLOGRAPHIC SPECTRAL RX1
              <span className="ml-auto float-right text-[#54ACBF]">-82.4 dBm</span>
            </span>
            <div className="flex-1 min-h-0">
              <RxSpectrumCanvas channelIdx={0} locked={rx1Locked} />
            </div>
          </div>
        </div>

        {/* RX1 Modulation Matrix */}
        <div className="p-3 border-t border-[rgba(84,172,191,0.12)]" style={{ background: CA(0.03) }}>
          <span className="font-mono text-[rgba(84,172,191,0.45)] text-[8px] uppercase tracking-wider block mb-2">Modulation Matrix</span>
          <div className="flex gap-1.5">
            {RX1_MODES.map(m => <ModeBtn key={m} label={m} active={rx1Mode === m} onClick={() => setRx1Mode(m)} />)}
          </div>
        </div>
      </div>

      {/* RX2 column */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* RX2 Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[rgba(84,172,191,0.15)]" style={{ background: CA(0.04) }}>
          <span className="font-['Inter:Bold',sans-serif] font-bold text-[#54ACBF] text-[11px] tracking-[1.5px] uppercase">RX2 – Channel Beta</span>
          <div className="flex items-center gap-2">
            <span className="font-mono text-[9px] px-2 py-0.5" style={{ background: CA(rx2Locked ? 0.2 : 0.06), color: rx2Locked ? "#54ACBF" : CA(0.35), border: `1px solid ${CA(rx2Locked ? 0.5 : 0.18)}` }}>
              {rx2Locked ? "LOCKED" : "STANDBY"} / {(rx2Freq / 1000).toFixed(3)} GHz
            </span>
            <Toggle checked={rx2Locked} onChange={() => setRx2Locked(!rx2Locked)} />
          </div>
        </div>

        {/* RX2 controls */}
        <div className="flex gap-0 flex-shrink-0 border-b border-[rgba(84,172,191,0.12)]">
          {[
            { label: "Frequency", value: (rx2Freq / 1000).toFixed(3), unit: "GHz" },
            { label: "Gain", value: rx2Gain.toFixed(1), unit: "dB" },
            { label: "Bandwidth", value: "20", unit: "MHz" },
          ].map((f) => (
            <div key={f.label} className="flex-1 p-3 border-r" style={{ borderColor: CA(0.1), background: CA(0.025) }}>
              <span className="font-mono text-[8px] uppercase tracking-wider block text-[rgba(84,172,191,0.45)]">{f.label}</span>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className="font-['Liberation_Mono:Regular',monospace] text-[#54ACBF] text-[17px]" style={{ opacity: rx2Locked ? 1 : 0.5 }}>{f.value}</span>
                <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px]">{f.unit}</span>
              </div>
            </div>
          ))}
        </div>

        {/* RX2 inline controls */}
        <div className="px-4 py-3 flex flex-col gap-2 border-b border-[rgba(84,172,191,0.1)]" style={{ background: CA(0.02) }}>
          <LabeledSlider label="Freq (MHz)" value={rx2Freq} min={70} max={6000} step={1} unit="MHz" onChange={setRx2Freq} />
          <LabeledSlider label="Gain" value={rx2Gain} min={0} max={73} step={1} unit="dB" onChange={setRx2Gain} />
          <div className="flex items-center justify-between">
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[9px] uppercase tracking-wider text-[#54ACBF]">AGC Mode</span>
            <div className="flex gap-1">
              {AGC_MODES.map(m => (
                <button key={m} onClick={() => setRx2AgcMode(m)}
                  className="font-mono text-[8px] uppercase px-2 py-1 transition-all"
                  style={{ background: rx2AgcMode === m ? CA(0.2) : CA(0.04), color: rx2AgcMode === m ? "#54ACBF" : CA(0.5), border: `1px solid ${CA(rx2AgcMode === m ? 0.5 : 0.15)}` }}>{m}</button>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[9px] uppercase tracking-wider text-[#54ACBF]">DC Correction</span>
            <Toggle checked={rx2DcCorr} onChange={() => setRx2DcCorr(!rx2DcCorr)} />
          </div>
        </div>

        {/* RX2 Spectrum */}
        <div className="flex-1 relative min-h-0">
          <div className="relative z-10 p-3 h-full flex flex-col">
            <span className="font-mono text-[rgba(84,172,191,0.4)] text-[8px] uppercase mb-1">HOLOGRAPHIC SPECTRAL RX2
              <span className="ml-auto float-right" style={{ color: rx2Locked ? "#54ACBF" : CA(0.4) }}>-105.1 dBm</span>
            </span>
            <div className="flex-1 min-h-0">
              <RxSpectrumCanvas channelIdx={1} locked={rx2Locked} />
            </div>
          </div>
        </div>

        {/* RX2 Modulation Matrix */}
        <div className="p-3 border-t border-[rgba(84,172,191,0.12)]" style={{ background: CA(0.03) }}>
          <span className="font-mono text-[rgba(84,172,191,0.45)] text-[8px] uppercase tracking-wider block mb-2">Modulation Matrix</span>
          <div className="flex gap-1.5">
            {RX2_MODES.map(m => <ModeBtn key={m} label={m} active={rx2Mode === m} onClick={() => setRx2Mode(m)} />)}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   TAB: ANALYSIS
══════════════════════════════════════════ */
function AnalysisTab() {
  const [modType, setModType] = useState("PSK");
  const MOD_TYPES = ["PSK", "QAM", "OFDM", "DSSS", "WFM"];

  return (
    <div className="flex h-full p-5 gap-5">
      {/* Constellation */}
      <div className="w-[320px] flex-shrink-0 flex flex-col gap-3">
        <div style={{ background: CA(0.04), border: `1px solid ${CA(0.2)}` }}>
          <div className="px-4 py-2 border-b flex items-center gap-2" style={{ borderColor: CA(0.12) }}>
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-[2px] uppercase text-[#54ACBF]">IQ Constellation</span>
          </div>
          <div className="p-3">
            <div className="flex gap-1.5 mb-3">
              {MOD_TYPES.map(m => (
                <button key={m} onClick={() => setModType(m)}
                  className="font-mono text-[9px] uppercase px-2 py-1 transition-all"
                  style={{ background: modType === m ? CA(0.2) : CA(0.04), color: modType === m ? "#54ACBF" : CA(0.5), border: `1px solid ${CA(modType === m ? 0.5 : 0.15)}` }}>{m}</button>
              ))}
            </div>
            <ConstellationCanvas modType={modType} />
          </div>
        </div>
        <div style={{ background: CA(0.04), border: `1px solid ${CA(0.2)}`, padding: "12px 16px" }}>
          <SH label="Signal Metrics" />
          {[
            { l: "EVM", v: "2.3", u: "%" },
            { l: "SNR", v: "28.4", u: "dB" },
            { l: "PAPR", v: "9.2", u: "dB" },
            { l: "MER", v: "32.1", u: "dB" },
            { l: "Phase Error", v: "±0.8", u: "°" },
          ].map(({ l, v, u }) => (
            <div key={l} className="flex items-center justify-between py-1.5 border-b" style={{ borderColor: CA(0.08) }}>
              <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)]">{l}</span>
              <div className="flex items-baseline gap-1">
                <span className="font-['Liberation_Mono:Regular',monospace] text-[#54ACBF] text-[14px]">{v}</span>
                <span className="font-mono text-[rgba(84,172,191,0.5)] text-[8px]">{u}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right analysis panels */}
      <div className="flex-1 flex flex-col gap-4 min-w-0">
        <div style={{ background: CA(0.04), border: `1px solid ${CA(0.2)}` }}>
          <div className="px-4 py-2 border-b" style={{ borderColor: CA(0.12) }}>
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-[2px] uppercase text-[#54ACBF]">Phase Noise Analysis</span>
          </div>
          <div className="p-4">
            <RxSpectrumCanvas channelIdx={0} locked={true} />
          </div>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <StatBox label="IQ Imbalance" value="0.12" unit="dB" />
          <StatBox label="DC Offset" value="-0.003" unit="V" />
          <StatBox label="Phase Jitter" value="0.45" unit="ps" />
          <StatBox label="TX Power" value="-12.0" unit="dBm" />
          <StatBox label="RX Sensitivity" value="-105" unit="dBm" />
          <StatBox label="LO Leakage" value="-42" unit="dBc" />
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   TAB: DECODE
══════════════════════════════════════════ */
const DECODED_MSGS = [
  { ts: "14:32:01", proto: "ADS-B", hex: "8D4840D6202CC371C32CE0576098", decoded: "ICAO: 4840D6 | ALT: 38000ft | SPEED: 485kt" },
  { ts: "14:31:48", proto: "APRS", hex: "", decoded: "W9XYZ-9>APRS: !4503.50N/08730.00W> Speed: 45 mph" },
  { ts: "14:31:22", proto: "DMR", hex: "0x04E2A1", decoded: "TG: 3142 | CCID: 2048 | Voice LC: TALKER" },
  { ts: "14:30:59", proto: "ADS-B", hex: "8D4CA2479912583801B67D3C2DE3", decoded: "ICAO: 4CA247 | LAT: 45.23 | LON: -122.45" },
  { ts: "14:30:31", proto: "WSPR", hex: "", decoded: "K7ABC FN31 37 — 10m WSP beacon detected" },
  { ts: "14:29:44", proto: "FT8", hex: "", decoded: "CQ DX K7ABC FN31 — Signal: -12dB, DT: +0.3s" },
];

function DecodeTab() {
  const [proto, setProto] = useState("ADS-B");
  const [running, setRunning] = useState(true);
  const PROTOCOLS = ["ADS-B", "APRS", "DMR", "P25", "D-STAR", "WSPR", "FT8", "POCSAG"];

  return (
    <div className="flex h-full p-5 gap-5">
      <div className="w-[220px] flex-shrink-0 flex flex-col gap-3">
        <div style={{ background: CA(0.04), border: `1px solid ${CA(0.2)}` }}>
          <div className="px-4 py-2.5 border-b" style={{ borderColor: CA(0.12) }}>
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-[2px] uppercase text-[#54ACBF]">Protocol</span>
          </div>
          <div className="p-3 flex flex-col gap-1.5">
            {PROTOCOLS.map(p => (
              <button key={p} onClick={() => setProto(p)}
                className="text-left px-3 py-2 font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase tracking-wider transition-all"
                style={{ background: proto === p ? CA(0.2) : CA(0.03), color: proto === p ? "#54ACBF" : CA(0.5), border: `1px solid ${CA(proto === p ? 0.5 : 0.12)}` }}>{p}</button>
            ))}
          </div>
        </div>
        <button onClick={() => setRunning(!running)}
          className="px-4 py-2.5 font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase tracking-wider transition-all"
          style={{ background: running ? CA(0.25) : CA(0.08), color: "#54ACBF", border: `1px solid ${CA(running ? 0.6 : 0.25)}` }}>
          {running ? "■ STOP DECODE" : "▶ START DECODE"}
        </button>
      </div>

      <div className="flex-1 flex flex-col gap-3 min-w-0">
        <div className="flex items-center justify-between">
          <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-[2px] uppercase text-[#54ACBF]">Decoded Messages — {proto}</span>
          <div className="flex items-center gap-2">
            {running && <span className="w-1.5 h-1.5 rounded-full bg-[#54ACBF] animate-pulse" />}
            <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px] uppercase">{running ? "DECODING" : "IDLE"}</span>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto" style={{ background: CA(0.03), border: `1px solid ${CA(0.18)}` }}>
          <table className="w-full">
            <thead className="sticky top-0" style={{ background: CA(0.08) }}>
              <tr>
                {["Time", "Protocol", "Hex", "Decoded"].map(h => (
                  <th key={h} className="font-mono text-[8px] uppercase text-[rgba(84,172,191,0.5)] text-left px-3 py-2">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {DECODED_MSGS.filter(m => m.proto === proto || true).map((m, i) => (
                <tr key={i} style={{ borderBottom: `1px solid ${CA(0.06)}`, opacity: m.proto === proto ? 1 : 0.4 }}>
                  <td className="font-mono text-[9px] text-[rgba(84,172,191,0.55)] px-3 py-2">{m.ts}</td>
                  <td className="px-3 py-2">
                    <span className="font-['Inter:Bold',sans-serif] font-bold text-[9px] px-1.5 py-0.5 uppercase"
                      style={{ background: CA(0.15), color: "#54ACBF", border: `1px solid ${CA(0.3)}` }}>{m.proto}</span>
                  </td>
                  <td className="font-mono text-[9px] text-[rgba(84,172,191,0.4)] px-3 py-2 max-w-[120px] truncate">{m.hex}</td>
                  <td className="font-mono text-[9px] text-[#54ACBF] px-3 py-2">{m.decoded}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   TAB: SETTINGS
══════════════════════════════════════════ */
function SettingsTab() {
  const [ipAddr, setIpAddr] = useState("192.168.2.1");
  const [sampleRate, setSampleRate] = useState("2.084");
  const [refClk, setRefClk] = useState("internal");
  const [loopback, setLoopback] = useState(false);
  const [fir, setFir] = useState(true);

  return (
    <div className="p-5 h-full overflow-y-auto">
      <div className="max-w-[800px] flex flex-col gap-5">
        {/* Device Info */}
        <div style={{ background: CA(0.04), border: `1px solid ${CA(0.2)}` }}>
          <div className="px-5 py-3 border-b" style={{ borderColor: CA(0.12), background: CA(0.06) }}>
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[11px] tracking-[2px] uppercase text-[#54ACBF]">Device Information</span>
          </div>
          <div className="p-5 grid grid-cols-2 gap-x-10 gap-y-3">
            {[
              { l: "Device", v: "PlutoSDR Rev.B" },
              { l: "Serial", v: "104473222A000021" },
              { l: "IP Address", v: ipAddr },
              { l: "USB", v: "USB 2.0 Hi-Speed" },
              { l: "Firmware", v: "v2.4.1-RC" },
              { l: "HDL Version", v: "v0.35" },
              { l: "Linux Kernel", v: "4.14.0-42045-g3ced112" },
              { l: "Temperature", v: "42.8 °C" },
            ].map(({ l, v }) => (
              <div key={l} className="flex items-center justify-between border-b py-1.5" style={{ borderColor: CA(0.08) }}>
                <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)]">{l}</span>
                <span className="font-mono text-[10px] text-[#54ACBF]">{v}</span>
              </div>
            ))}
          </div>
        </div>

        {/* RF Configuration */}
        <div style={{ background: CA(0.04), border: `1px solid ${CA(0.2)}` }}>
          <div className="px-5 py-3 border-b" style={{ borderColor: CA(0.12), background: CA(0.06) }}>
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[11px] tracking-[2px] uppercase text-[#54ACBF]">RF Configuration</span>
          </div>
          <div className="p-5 flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)] block mb-1.5">Sample Rate (MSPS)</span>
                <input value={sampleRate} onChange={e => setSampleRate(e.target.value)}
                  className="w-full bg-transparent font-mono text-[#54ACBF] text-[13px] px-3 py-2 outline-none"
                  style={{ border: `1px solid ${CA(0.3)}` }} />
              </div>
              <div>
                <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)] block mb-1.5">IP Address</span>
                <input value={ipAddr} onChange={e => setIpAddr(e.target.value)}
                  className="w-full bg-transparent font-mono text-[#54ACBF] text-[13px] px-3 py-2 outline-none"
                  style={{ border: `1px solid ${CA(0.3)}` }} />
              </div>
            </div>
            <div>
              <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)] block mb-1.5">Reference Clock</span>
              <div className="flex gap-2">
                {["internal", "external", "VCTCXO"].map(r => (
                  <button key={r} onClick={() => setRefClk(r)}
                    className="px-3 py-1.5 font-mono text-[10px] uppercase transition-all"
                    style={{ background: refClk === r ? CA(0.2) : CA(0.04), color: refClk === r ? "#54ACBF" : CA(0.5), border: `1px solid ${CA(refClk === r ? 0.5 : 0.15)}` }}>{r}</button>
                ))}
              </div>
            </div>
            <div className="flex gap-6">
              <div className="flex items-center gap-3">
                <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase tracking-wider text-[#54ACBF]">RF Loopback</span>
                <Toggle checked={loopback} onChange={() => setLoopback(!loopback)} />
              </div>
              <div className="flex items-center gap-3">
                <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase tracking-wider text-[#54ACBF]">FIR Filter</span>
                <Toggle checked={fir} onChange={() => setFir(!fir)} />
              </div>
            </div>
          </div>
        </div>

        {/* Calibration */}
        <div style={{ background: CA(0.04), border: `1px solid ${CA(0.2)}` }}>
          <div className="px-5 py-3 border-b" style={{ borderColor: CA(0.12), background: CA(0.06) }}>
            <span className="font-['Inter:Bold',sans-serif] font-bold text-[11px] tracking-[2px] uppercase text-[#54ACBF]">Calibration</span>
          </div>
          <div className="p-5 flex gap-3">
            {["Calibrate RX", "Calibrate TX", "DCXO Trim", "Reset to Default"].map(a => (
              <button key={a}
                className="px-4 py-2 font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase tracking-wider transition-all hover:shadow-[0_0_12px_rgba(84,172,191,0.2)]"
                style={{ background: CA(0.08), color: "#54ACBF", border: `1px solid ${CA(0.3)}` }}>{a}</button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   MAIN PAGE
══════════════════════════════════════════ */
const TABS = [
  { id: "TX", label: "TRANSMISSION", icon: <Zap size={11} /> },
  { id: "RX", label: "RECEPTION", icon: <Radio size={11} /> },
  { id: "ANALYSIS", label: "ANALYSIS", icon: <BarChart3 size={11} /> },
  { id: "DECODE", label: "DECODE", icon: <MessageSquare size={11} /> },
  { id: "SETTINGS", label: "SETTINGS", icon: <Settings size={11} /> },
] as const;

export default function PlutoSdrPage() {
  const [activeTab, setActiveTab] = useState<typeof TABS[number]["id"]>("TX");
  const [emergencyKill, setEmergencyKill] = useState(false);

  return (
    <div className="relative flex flex-col h-[calc(100vh-88px)] overflow-hidden">
      {/* BG */}
      <div className="absolute inset-0 pointer-events-none">
        <img src={imgTxBg} alt="" className="absolute w-full h-[125%] top-[-12.5%] object-cover opacity-12" />
        <div className="absolute inset-0 bg-[rgba(2,10,15,0.78)]" />
      </div>

      {/* Device header + tab bar */}
      <div className="relative z-10 flex-shrink-0 border-b border-[rgba(84,172,191,0.18)] bg-[rgba(4,14,20,0.85)] backdrop-blur-md">
        <div className="flex items-stretch justify-between">
          {/* Logo + device ID */}
          <div className="flex items-center gap-4 px-5 py-2.5">
            <div className="flex items-center gap-3">
              <div className="w-7 h-7 flex items-center justify-center" style={{ background: "#54ACBF" }}>
                <Radio size={14} color="#020B10" />
              </div>
              <div>
                <h2 className="font-['Inter:Black',sans-serif] font-black text-[#54ACBF] text-[15px] tracking-[-0.5px] uppercase leading-none" style={{ textShadow: `0 0 12px rgba(84,172,191,0.4)` }}>
                  PlutoSDR+ Suite
                </h2>
                <span className="font-mono text-[rgba(84,172,191,0.4)] text-[9px] uppercase">SYSTEM DIAGNOSTICS / FULL DUPLEX 2TX 2RX</span>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-stretch">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="flex items-center gap-2 px-5 font-['Inter:Bold',sans-serif] font-bold text-[11px] tracking-[1.2px] uppercase transition-all duration-200 border-r"
                style={{
                  borderColor: CA(0.15),
                  background: activeTab === tab.id ? "#54ACBF" : "transparent",
                  color: activeTab === tab.id ? "#020B10" : CA(0.6),
                  boxShadow: activeTab === tab.id ? `0 -2px 0 #54ACBF inset` : "none",
                }}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>

          {/* Emergency Kill */}
          <div className="flex items-center gap-3 px-5">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#54ACBF]" />
              <span className="font-mono text-[rgba(84,172,191,0.6)] text-[9px] uppercase">SYSTEM NOMINAL</span>
            </div>
            <button
              onClick={() => setEmergencyKill(!emergencyKill)}
              className="px-3 py-1.5 font-['Inter:Bold',sans-serif] font-bold text-[9px] uppercase tracking-wider transition-all"
              style={{
                background: emergencyKill ? "rgba(239,68,68,0.3)" : CA(0.08),
                color: emergencyKill ? "#ef4444" : "#54ACBF",
                border: `1px solid ${emergencyKill ? "rgba(239,68,68,0.6)" : CA(0.3)}`,
              }}
            >
              {emergencyKill ? "⚠ KILLED" : "EMERGENCY KILL"}
            </button>
          </div>
        </div>
      </div>

      {/* Tab content */}
      <div className="relative z-10 flex-1 min-h-0 overflow-hidden">
        {activeTab === "TX" && <TransmissionTab />}
        {activeTab === "RX" && <ReceptionTab />}
        {activeTab === "ANALYSIS" && <AnalysisTab />}
        {activeTab === "DECODE" && <DecodeTab />}
        {activeTab === "SETTINGS" && <SettingsTab />}
      </div>

      {/* Device footer */}
      <div className="relative z-10 flex-shrink-0 flex items-center justify-between px-5 py-2 border-t border-[rgba(84,172,191,0.15)] bg-[rgba(4,14,20,0.85)] backdrop-blur-md">
        <div className="flex items-center gap-5">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#54ACBF]" />
            <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px] uppercase">DEVICE: PLUTOSOR_01_REVB</span>
          </div>
          <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px] uppercase">BUFFER: 1024 MS/S</span>
          <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px] uppercase">FIRMWARE: V2.4.1-RC</span>
          <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px] uppercase">TEMP: 42.8°C</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="font-mono text-[rgba(84,172,191,0.45)] text-[9px]">TX DISARMED</span>
          <span className="font-mono text-[rgba(84,172,191,0.35)] text-[9px]">|</span>
          <span className="font-mono text-[rgba(84,172,191,0.45)] text-[9px]">UTC: {new Date().toISOString().slice(11, 19)}</span>
        </div>
      </div>
    </div>
  );
}
