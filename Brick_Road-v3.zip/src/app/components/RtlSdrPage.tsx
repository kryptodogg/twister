import { useRef, useEffect, useState, useCallback } from "react";
import { ChevronDown, ChevronUp, Search, List, Volume2 } from "lucide-react";
import imgBg from "figma:asset/4848057d62f972cd7ff1167d004ac4f21357ad47.png";

const CA = (a: number) => `rgba(84,172,191,${a})`;
const PANEL = { background: CA(0.04), border: `1px solid ${CA(0.2)}`, backdropFilter: "blur(6px)" };

/* ─── Spectrum + Waterfall Canvas ─── */
function SpectrumCanvas({ centerFreq, sampleRate }: { centerFreq: number; sampleRate: number }) {
  const specRef = useRef<HTMLCanvasElement>(null);
  const wfRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef(0);
  const dataRef = useRef(new Float32Array(512).fill(-85));
  const peaksRef = useRef([
    { bin: 70, power: -58, w: 3, speed: 0.4 },
    { bin: 148, power: -42, w: 5, speed: 0.6 },
    { bin: 230, power: -38, w: 8, speed: 0.3 },
    { bin: 310, power: -55, w: 4, speed: 0.8 },
    { bin: 390, power: -49, w: 6, speed: 0.5 },
    { bin: 440, power: -62, w: 2, speed: 1.0 },
    { bin: 480, power: -45, w: 4, speed: 0.7 },
  ]);

  useEffect(() => {
    const spec = specRef.current;
    const wf = wfRef.current;
    if (!spec || !wf) return;
    const sCtx = spec.getContext("2d")!;
    const wCtx = wf.getContext("2d")!;
    const N = 512;
    let t = 0, lastT = 0;

    function update() {
      t += 0.016;
      const data = dataRef.current;
      for (let i = 0; i < N; i++) {
        data[i] = -86 + (Math.random() - 0.5) * 7;
      }
      peaksRef.current.forEach(({ bin, power, w, speed }) => {
        const wobble = Math.sin(t * speed + bin * 0.1) * 3;
        for (let d = -w * 2; d <= w * 2; d++) {
          const idx = Math.floor(bin + d);
          if (idx < 0 || idx >= N) continue;
          const env = Math.exp(-(d * d) / (w * w));
          const v = (power + wobble) * env;
          if (v > data[idx]) data[idx] = v;
        }
      });
    }

    function drawSpectrum() {
      const W = spec!.width, H = spec!.height;
      const data = dataRef.current;
      sCtx.fillStyle = "rgba(2,10,15,0.96)";
      sCtx.fillRect(0, 0, W, H);

      // Grid
      sCtx.strokeStyle = CA(0.07);
      sCtx.lineWidth = 1;
      [-100, -90, -80, -70, -60, -50, -40, -30, -20].forEach((db) => {
        const y = H - ((db + 100) / 80) * H;
        sCtx.beginPath(); sCtx.moveTo(0, y); sCtx.lineTo(W, y); sCtx.stroke();
        sCtx.fillStyle = CA(0.3);
        sCtx.font = "9px monospace";
        sCtx.fillText(`${db}`, 3, y - 2);
      });
      for (let i = 0; i <= 8; i++) {
        const x = (W / 8) * i;
        sCtx.beginPath(); sCtx.moveTo(x, 0); sCtx.lineTo(x, H); sCtx.stroke();
      }

      // Fill
      sCtx.beginPath();
      for (let i = 0; i < N; i++) {
        const x = (i / N) * W;
        const y = H - ((data[i] + 100) / 80) * H;
        i === 0 ? sCtx.moveTo(x, Math.max(0, y)) : sCtx.lineTo(x, Math.max(0, y));
      }
      sCtx.lineTo(W, H); sCtx.lineTo(0, H); sCtx.closePath();
      const grad = sCtx.createLinearGradient(0, 0, 0, H);
      grad.addColorStop(0, CA(0.45)); grad.addColorStop(0.6, CA(0.12)); grad.addColorStop(1, CA(0.02));
      sCtx.fillStyle = grad; sCtx.fill();

      // Line
      sCtx.beginPath();
      sCtx.strokeStyle = "#54ACBF"; sCtx.lineWidth = 1.5;
      sCtx.shadowColor = "#54ACBF"; sCtx.shadowBlur = 4;
      for (let i = 0; i < N; i++) {
        const x = (i / N) * W;
        const y = H - ((data[i] + 100) / 80) * H;
        i === 0 ? sCtx.moveTo(x, Math.max(0, y)) : sCtx.lineTo(x, Math.max(0, y));
      }
      sCtx.stroke(); sCtx.shadowBlur = 0;

      // Freq labels
      const hw = sampleRate / 2;
      sCtx.fillStyle = CA(0.4); sCtx.font = "9px monospace";
      for (let i = 0; i <= 4; i++) {
        const x = (W / 4) * i;
        const f = ((centerFreq - hw + (sampleRate / 4) * i) / 1e6).toFixed(1);
        sCtx.fillText(`${f} MHz`, x + 2, H - 3);
      }
    }

    function drawWaterfall() {
      const W = wf!.width, H = wf!.height;
      const data = dataRef.current;
      const img = wCtx.getImageData(0, 0, W, H - 1);
      wCtx.putImageData(img, 0, 1);
      const line = wCtx.createImageData(W, 1);
      for (let x = 0; x < W; x++) {
        const b = Math.floor((x / W) * data.length);
        const v = Math.max(0, Math.min(1, (data[b] + 100) / 80));
        const idx = x * 4;
        line.data[idx] = Math.floor(v * 84);
        line.data[idx + 1] = Math.floor(v * 172);
        line.data[idx + 2] = Math.floor(v * 191);
        line.data[idx + 3] = Math.floor(40 + v * 215);
      }
      wCtx.putImageData(line, 0, 0);
    }

    let last = 0;
    function loop(ts: number) {
      if (ts - last > 50) { last = ts; update(); drawSpectrum(); drawWaterfall(); }
      animRef.current = requestAnimationFrame(loop);
    }
    animRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animRef.current);
  }, [centerFreq, sampleRate]);

  return (
    <div className="flex flex-col gap-0.5 w-full">
      <canvas ref={specRef} width={1024} height={220} className="w-full block" />
      <canvas ref={wfRef} width={1024} height={100} className="w-full block" />
    </div>
  );
}

/* ─── Toggle ─── */
function Toggle({ checked, onChange }: { checked: boolean; onChange: () => void }) {
  return (
    <button
      onClick={onChange}
      className="relative w-10 h-5 transition-colors duration-200"
      style={{ background: checked ? CA(0.5) : CA(0.1), border: `1px solid ${CA(checked ? 0.8 : 0.3)}` }}
    >
      <span
        className="absolute top-0.5 h-4 w-4 transition-all duration-200"
        style={{
          background: checked ? "#54ACBF" : CA(0.4),
          left: checked ? "calc(100% - 18px)" : "2px",
          boxShadow: checked ? `0 0 8px ${CA(0.8)}` : "none",
        }}
      />
    </button>
  );
}

/* ─── Small labeled slider ─── */
function LabeledSlider({
  label, value, min, max, step, unit, onChange,
}: {
  label: string; value: number; min: number; max: number; step: number; unit: string; onChange: (v: number) => void;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <span className="font-['Inter:Bold',sans-serif] font-bold text-[#54ACBF] text-[11px] tracking-[1px] uppercase">{label}</span>
        <span className="font-mono text-[#54ACBF] text-[11px]">{value.toFixed(1)} {unit}</span>
      </div>
      <div className="relative h-1 w-full" style={{ background: CA(0.1) }}>
        <div
          className="absolute top-0 left-0 h-full"
          style={{ width: `${((value - min) / (max - min)) * 100}%`, background: CA(0.6) }}
        />
        <input
          type="range" min={min} max={max} step={step} value={value}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="absolute inset-0 w-full opacity-0 cursor-pointer h-full"
        />
      </div>
    </div>
  );
}

/* ─── Mode Button ─── */
function ModeBtn({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="font-['Inter:Bold',sans-serif] font-bold text-[11px] tracking-wider uppercase py-2 transition-all duration-150"
      style={{
        background: active ? "#54ACBF" : CA(0.05),
        color: active ? "#020B10" : "#54ACBF",
        border: `1px solid ${active ? "#54ACBF" : CA(0.25)}`,
        boxShadow: active ? `0 0 12px ${CA(0.4)}` : "none",
      }}
    >
      {label}
    </button>
  );
}

/* ─── Frequency Display ─── */
function FreqDisplay({ freq }: { freq: number }) {
  const s = Math.floor(freq).toString().padStart(9, "0");
  const parts = [s.slice(0, 3), s.slice(3, 6), s.slice(6, 9)];
  return (
    <div className="flex items-baseline gap-0.5">
      {parts.map((p, i) => (
        <span key={i} className="font-['Liberation_Mono:Regular',monospace] text-[#54ACBF]" style={{ fontSize: 30, letterSpacing: -1, textShadow: `0 0 20px ${CA(0.6)}` }}>
          {p}{i < 2 && <span className="text-[rgba(84,172,191,0.4)]">.</span>}
        </span>
      ))}
      <span className="font-mono text-[rgba(84,172,191,0.6)] text-[11px] ml-1 uppercase">Hz</span>
    </div>
  );
}

/* ─── Section header ─── */
function SectionHeader({ label, badge }: { label: string; badge?: string }) {
  return (
    <div className="flex items-center justify-between border-l-2 border-[#54ACBF] pl-3 py-0.5 mb-3">
      <span className="font-['Inter:Bold',sans-serif] font-bold text-[#54ACBF] text-[11px] tracking-[1.5px] uppercase">{label}</span>
      {badge && <span className="font-mono text-[rgba(84,172,191,0.4)] text-[9px] uppercase">{badge}</span>}
    </div>
  );
}

const MODES = ["WFM", "NFM", "AM", "CW", "LSB", "USB", "DSB", "FM"] as const;
const SAMPLE_RATES = [0.25, 0.5, 1.024, 1.4, 1.8, 2.048, 2.4, 3.2];
const STEP_SIZES = [1, 10, 100, 1000, 10000, 100000, 1000000];
const STEP_LABELS = ["1 Hz", "10 Hz", "100 Hz", "1 kHz", "10 kHz", "100 kHz", "1 MHz"];
const BW_OPTIONS: Record<string, number[]> = {
  WFM: [75, 100, 150, 200], NFM: [5, 8, 10, 12.5], AM: [5, 6, 8, 10],
  CW: [0.1, 0.25, 0.5, 1], LSB: [2.4, 2.7, 3.0], USB: [2.4, 2.7, 3.0],
  DSB: [6, 8, 10], FM: [150, 200, 250],
};

const SIGNAL_LOG = [
  { time: "14:31:02", freq: "101.300 MHz", mode: "WFM", level: "-42.5 dBm", note: "FM Broadcast" },
  { time: "14:30:48", freq: "162.400 MHz", mode: "NFM", level: "-68.2 dBm", note: "NOAA Weather" },
  { time: "14:29:11", freq: "121.500 MHz", mode: "AM", level: "-55.0 dBm", note: "Aviation Guard" },
  { time: "14:28:55", freq: "156.800 MHz", mode: "NFM", level: "-72.1 dBm", note: "Marine VHF Ch16" },
  { time: "14:27:33", freq: "433.920 MHz", mode: "NFM", level: "-61.3 dBm", note: "ISM 433" },
];

const BOOKMARKS = [
  { name: "FM Broadcast", freq: 101300000 },
  { name: "NOAA Weather", freq: 162400000 },
  { name: "Aviation Guard", freq: 121500000 },
  { name: "Marine Ch16", freq: 156800000 },
  { name: "ADS-B", freq: 1090000000 },
];

export default function RtlSdrPage() {
  const [mode, setMode] = useState<typeof MODES[number]>("WFM");
  const [freq, setFreq] = useState(101300000);
  const [deltaOffset, setDeltaOffset] = useState(12.4);
  const [lnaGain, setLnaGain] = useState(32.8);
  const [agcOn, setAgcOn] = useState(false);
  const [biasTee, setBiasTee] = useState(true);
  const [dcOffset, setDcOffset] = useState(true);
  const [iqBalance, setIqBalance] = useState(true);
  const [ppm, setPpm] = useState(0);
  const [squelch, setSquelch] = useState(-80);
  const [sampleRate, setSampleRate] = useState(2.048);
  const [bandwidth, setBandwidth] = useState(200);
  const [stepIdx, setStepIdx] = useState(4);
  const [ifGains, setIfGains] = useState([20, 20, 20, 20, 20, 20]);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [logOpen, setLogOpen] = useState(false);
  const [isLive, setIsLive] = useState(true);
  const [volume, setVolume] = useState(85);
  const [audioOut, setAudioOut] = useState("INTERNAL SPEAKERS");
  const [scanRange, setScanRange] = useState({ start: 88, end: 108 });
  const [scanning, setScanning] = useState(false);
  const [currentDbm] = useState(-42.5);
  const [fftCore] = useState(32768);

  const step = STEP_SIZES[stepIdx];

  const changeFreq = useCallback((delta: number) => {
    setFreq((f) => Math.max(100000, Math.min(1766000000, f + delta)));
  }, []);

  const bwOptions = BW_OPTIONS[mode] || [200];

  return (
    <div className="relative flex flex-col h-[calc(100vh-88px)] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <img src={imgBg} alt="" className="absolute w-full h-[125%] top-[-12.5%] object-cover opacity-20" />
        <div className="absolute inset-0 bg-[rgba(2,10,15,0.75)]" />
      </div>

      {/* Page header row */}
      <div className="relative z-10 flex items-end justify-between px-8 pt-5 pb-4 border-b border-[rgba(84,172,191,0.15)]">
        <div className="flex items-end gap-6">
          <div>
            <h2 className="font-['Inter:Black',sans-serif] font-black text-[#54ACBF] text-[36px] tracking-[-1.5px] leading-none uppercase" style={{ textShadow: `0 0 20px ${CA(0.4)}` }}>
              RTL-SDR
            </h2>
            <span className="font-mono text-[rgba(84,172,191,0.45)] text-[10px] tracking-wider uppercase">BRICK ROAD / FORENSIC HUD v4.2.0</span>
          </div>
          <div className="flex items-center gap-2 pb-1 px-3 py-1 border border-[rgba(84,172,191,0.3)] bg-[rgba(84,172,191,0.06)]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#54ACBF] shadow-[0_0_6px_#54ACBF]" />
            <span className="font-mono text-[#54ACBF] text-[10px] uppercase tracking-wider">V3_DONGLE_ACTIVE</span>
          </div>
        </div>
        <div className="flex items-center gap-4 pb-1">
          <div className="flex flex-col items-end">
            <span className="font-mono text-[rgba(84,172,191,0.4)] text-[9px] uppercase">FFT_CORE</span>
            <span className="font-mono text-[rgba(84,172,191,0.7)] text-[11px]">{fftCore}</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="font-mono text-[rgba(84,172,191,0.4)] text-[9px] uppercase">SAMPLE_RATE</span>
            <span className="font-mono text-[rgba(84,172,191,0.7)] text-[11px]">{sampleRate} MS/s</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="font-mono text-[rgba(84,172,191,0.4)] text-[9px] uppercase">Signal Flux Density</span>
            <span className="font-['Inter:Black',sans-serif] font-black text-[#54ACBF] text-[28px] tracking-tight leading-none" style={{ textShadow: `0 0 16px ${CA(0.5)}` }}>
              {currentDbm} <span className="text-[rgba(84,172,191,0.6)] text-[13px]">dBm</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="relative z-10 flex flex-1 gap-0 min-h-0 overflow-hidden">

        {/* ── LEFT PANEL ── */}
        <div className="w-[260px] flex-shrink-0 flex flex-col gap-0 border-r border-[rgba(84,172,191,0.15)] bg-[rgba(4,14,20,0.6)] backdrop-blur-md overflow-y-auto">
          <div className="p-4 flex flex-col gap-4">

            {/* Modulation */}
            <div>
              <SectionHeader label="Modulation" badge="MODE_SEL" />
              <div className="grid grid-cols-2 gap-1.5">
                {MODES.map((m) => (
                  <ModeBtn key={m} label={m} active={mode === m} onClick={() => setMode(m)} />
                ))}
              </div>
            </div>

            {/* Sample Rate */}
            <div>
              <SectionHeader label="Sample Rate" />
              <div className="grid grid-cols-2 gap-1.5">
                {SAMPLE_RATES.map((r) => (
                  <button
                    key={r}
                    onClick={() => setSampleRate(r)}
                    className="font-mono text-[10px] py-1.5 transition-all duration-150"
                    style={{
                      background: sampleRate === r ? CA(0.2) : CA(0.04),
                      color: sampleRate === r ? "#54ACBF" : CA(0.55),
                      border: `1px solid ${sampleRate === r ? CA(0.5) : CA(0.15)}`,
                    }}
                  >
                    {r} MS
                  </button>
                ))}
              </div>
            </div>

            {/* Bandwidth */}
            <div>
              <SectionHeader label="Bandwidth" />
              <div className="grid grid-cols-2 gap-1.5">
                {bwOptions.map((b) => (
                  <button
                    key={b}
                    onClick={() => setBandwidth(b)}
                    className="font-mono text-[10px] py-1.5 transition-all duration-150"
                    style={{
                      background: bandwidth === b ? CA(0.2) : CA(0.04),
                      color: bandwidth === b ? "#54ACBF" : CA(0.55),
                      border: `1px solid ${bandwidth === b ? CA(0.5) : CA(0.15)}`,
                    }}
                  >
                    {b} kHz
                  </button>
                ))}
              </div>
            </div>

            {/* RF Gain */}
            <div>
              <SectionHeader label="RF Gain" />
              <div className="flex items-center justify-between mb-2">
                <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase text-[#54ACBF] tracking-wider">AGC</span>
                <Toggle checked={agcOn} onChange={() => setAgcOn(!agcOn)} />
              </div>
              {!agcOn && (
                <LabeledSlider label="LNA Gain" value={lnaGain} min={0} max={49.6} step={0.8} unit="dB" onChange={setLnaGain} />
              )}
            </div>

            {/* IF Gain Stages */}
            {!agcOn && (
              <div>
                <SectionHeader label="IF Gain Stages" />
                <div className="flex flex-col gap-2">
                  {ifGains.map((g, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="font-mono text-[9px] text-[rgba(84,172,191,0.5)] w-8">IF{i + 1}</span>
                      <div className="flex-1 relative h-1" style={{ background: CA(0.1) }}>
                        <div className="absolute top-0 left-0 h-full" style={{ width: `${(g / 40) * 100}%`, background: CA(0.55) }} />
                        <input type="range" min={0} max={40} step={0.5} value={g}
                          onChange={(e) => { const n = [...ifGains]; n[i] = parseFloat(e.target.value); setIfGains(n); }}
                          className="absolute inset-0 w-full opacity-0 cursor-pointer h-full"
                        />
                      </div>
                      <span className="font-mono text-[9px] text-[#54ACBF] w-8 text-right">{g}dB</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Advanced */}
            <div>
              <SectionHeader label="Advanced" />
              <div className="flex flex-col gap-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase text-[#54ACBF] tracking-wider">Bias Tee</span>
                  <Toggle checked={biasTee} onChange={() => setBiasTee(!biasTee)} />
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase text-[#54ACBF] tracking-wider">DC Offset Rem.</span>
                  <Toggle checked={dcOffset} onChange={() => setDcOffset(!dcOffset)} />
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase text-[#54ACBF] tracking-wider">IQ Balance Corr.</span>
                  <Toggle checked={iqBalance} onChange={() => setIqBalance(!iqBalance)} />
                </div>
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                    <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase text-[#54ACBF] tracking-wider">PPM Correction</span>
                    <span className="font-mono text-[#54ACBF] text-[11px]">{ppm} ppm</span>
                  </div>
                  <div className="relative h-1" style={{ background: CA(0.1) }}>
                    <div className="absolute top-0 h-full" style={{ left: "50%", width: `${Math.abs(ppm) * 0.5}%`, background: CA(0.55), transform: ppm < 0 ? "translateX(-100%)" : "" }} />
                    <input type="range" min={-100} max={100} step={1} value={ppm}
                      onChange={(e) => setPpm(parseInt(e.target.value))}
                      className="absolute inset-0 w-full opacity-0 cursor-pointer h-full"
                    />
                  </div>
                </div>
                <LabeledSlider label="Squelch" value={squelch} min={-120} max={0} step={1} unit="dBm" onChange={setSquelch} />
              </div>
            </div>

            {/* Bookmarks */}
            <div>
              <SectionHeader label="Bookmarks" />
              <div className="flex flex-col gap-1">
                {BOOKMARKS.map((bm) => (
                  <button
                    key={bm.name}
                    onClick={() => setFreq(bm.freq)}
                    className="flex items-center justify-between px-2 py-1.5 text-left transition-all"
                    style={{ background: CA(0.04), border: `1px solid ${CA(0.15)}` }}
                    onMouseEnter={(e) => (e.currentTarget.style.borderColor = CA(0.4))}
                    onMouseLeave={(e) => (e.currentTarget.style.borderColor = CA(0.15))}
                  >
                    <span className="font-mono text-[#54ACBF] text-[9px] uppercase tracking-wide">{bm.name}</span>
                    <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px]">{(bm.freq / 1e6).toFixed(3)} MHz</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* ── CENTER PANEL ── */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Spectrum + Waterfall */}
          <div className="relative flex-1 min-h-0 bg-[rgba(2,8,12,0.8)]">
            <SpectrumCanvas centerFreq={freq} sampleRate={sampleRate * 1e6} />
          </div>

          {/* Bottom tools bar */}
          <div style={{ background: CA(0.03), borderTop: `1px solid ${CA(0.15)}` }}>
            {/* Frequency Scanner */}
            <button
              onClick={() => setScannerOpen(!scannerOpen)}
              className="flex items-center gap-3 w-full px-5 py-2.5 transition-all"
              style={{ borderBottom: `1px solid ${CA(0.1)}` }}
            >
              <Search size={12} color={CA(0.7)} />
              <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-[1.5px] uppercase text-[#54ACBF]">Frequency Scanner</span>
              {scannerOpen ? <ChevronUp size={12} color={CA(0.5)} /> : <ChevronDown size={12} color={CA(0.5)} />}
            </button>
            {scannerOpen && (
              <div className="px-5 py-3 grid grid-cols-4 gap-3 items-end" style={{ borderBottom: `1px solid ${CA(0.1)}` }}>
                <div>
                  <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.5)] block mb-1">Start Freq (MHz)</span>
                  <input
                    type="number" value={scanRange.start}
                    onChange={(e) => setScanRange((s) => ({ ...s, start: parseFloat(e.target.value) }))}
                    className="w-full bg-transparent font-mono text-[#54ACBF] text-[12px] px-2 py-1 outline-none"
                    style={{ border: `1px solid ${CA(0.3)}` }}
                  />
                </div>
                <div>
                  <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.5)] block mb-1">End Freq (MHz)</span>
                  <input
                    type="number" value={scanRange.end}
                    onChange={(e) => setScanRange((s) => ({ ...s, end: parseFloat(e.target.value) }))}
                    className="w-full bg-transparent font-mono text-[#54ACBF] text-[12px] px-2 py-1 outline-none"
                    style={{ border: `1px solid ${CA(0.3)}` }}
                  />
                </div>
                <div>
                  <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.5)] block mb-1">Step Size</span>
                  <select value={stepIdx} onChange={(e) => setStepIdx(parseInt(e.target.value))}
                    className="w-full bg-[rgba(2,10,15,0.8)] font-mono text-[#54ACBF] text-[11px] px-2 py-1 outline-none"
                    style={{ border: `1px solid ${CA(0.3)}` }}>
                    {STEP_LABELS.map((l, i) => <option key={i} value={i}>{l}</option>)}
                  </select>
                </div>
                <button
                  onClick={() => setScanning(!scanning)}
                  className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-wider uppercase py-1.5 transition-all"
                  style={{
                    background: scanning ? CA(0.4) : CA(0.15),
                    color: "#54ACBF",
                    border: `1px solid ${CA(scanning ? 0.8 : 0.3)}`,
                  }}
                >
                  {scanning ? "■ STOP" : "▶ SCAN"}
                </button>
              </div>
            )}

            {/* Signal Log */}
            <button
              onClick={() => setLogOpen(!logOpen)}
              className="flex items-center gap-3 w-full px-5 py-2.5"
            >
              <List size={12} color={CA(0.7)} />
              <span className="font-['Inter:Bold',sans-serif] font-bold text-[10px] tracking-[1.5px] uppercase text-[#54ACBF]">Signal Log</span>
              {logOpen ? <ChevronUp size={12} color={CA(0.5)} /> : <ChevronDown size={12} color={CA(0.5)} />}
            </button>
            {logOpen && (
              <div className="px-5 pb-3 max-h-36 overflow-y-auto">
                <table className="w-full">
                  <thead>
                    <tr>
                      {["Time", "Frequency", "Mode", "Level", "Note"].map((h) => (
                        <th key={h} className="font-mono text-[8px] uppercase text-[rgba(84,172,191,0.4)] text-left pb-1 pr-3">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {SIGNAL_LOG.map((entry, i) => (
                      <tr key={i} className="border-t border-[rgba(84,172,191,0.07)]">
                        <td className="font-mono text-[9px] text-[rgba(84,172,191,0.6)] py-1 pr-3">{entry.time}</td>
                        <td className="font-mono text-[9px] text-[#54ACBF] pr-3">{entry.freq}</td>
                        <td className="font-mono text-[9px] text-[rgba(84,172,191,0.7)] pr-3">{entry.mode}</td>
                        <td className="font-mono text-[9px] text-[rgba(84,172,191,0.8)] pr-3">{entry.level}</td>
                        <td className="font-mono text-[9px] text-[rgba(84,172,191,0.5)]">{entry.note}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* ── RIGHT PANEL ── */}
        <div className="w-[240px] flex-shrink-0 flex flex-col border-l border-[rgba(84,172,191,0.15)] bg-[rgba(4,14,20,0.6)] backdrop-blur-md overflow-y-auto">
          <div className="p-4 flex flex-col gap-4">

            {/* Target Frequency */}
            <div>
              <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px] uppercase tracking-wider block mb-2">TARGET_FREQUENCY</span>
              <div className="p-3 mb-3" style={{ background: CA(0.04), border: `1px solid ${CA(0.25)}` }}>
                <FreqDisplay freq={freq} />
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => changeFreq(-step)} className="w-8 h-8 font-mono text-[#54ACBF] transition-all hover:bg-[rgba(84,172,191,0.2)]" style={{ border: `1px solid ${CA(0.3)}` }}>−</button>
                <select value={stepIdx} onChange={(e) => setStepIdx(parseInt(e.target.value))}
                  className="flex-1 bg-[rgba(2,10,15,0.8)] font-mono text-[#54ACBF] text-[10px] px-2 py-1.5 outline-none"
                  style={{ border: `1px solid ${CA(0.25)}` }}>
                  {STEP_LABELS.map((l, i) => <option key={i} value={i}>{l}</option>)}
                </select>
                <button onClick={() => changeFreq(step)} className="w-8 h-8 font-mono text-[#54ACBF] transition-all hover:bg-[rgba(84,172,191,0.2)]" style={{ border: `1px solid ${CA(0.3)}` }}>+</button>
              </div>
            </div>

            {/* Delta Offset */}
            <div>
              <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px] uppercase tracking-wider block mb-2">DELTA_OFFSET</span>
              <div className="flex items-center gap-2">
                <button onClick={() => setDeltaOffset((d) => parseFloat((d - 0.1).toFixed(1)))} className="w-8 h-8 font-mono text-[#54ACBF] transition-all hover:bg-[rgba(84,172,191,0.2)]" style={{ border: `1px solid ${CA(0.3)}` }}>−</button>
                <div className="flex-1 p-2 text-center" style={{ background: CA(0.04), border: `1px solid ${CA(0.25)}` }}>
                  <span className="font-['Liberation_Mono:Regular',monospace] text-[#54ACBF] text-[20px]" style={{ textShadow: `0 0 12px ${CA(0.5)}` }}>
                    {deltaOffset > 0 ? "+" : ""}{deltaOffset.toFixed(1)}
                  </span>
                  <span className="font-mono text-[rgba(84,172,191,0.5)] text-[9px] ml-1">kHz</span>
                </div>
                <button onClick={() => setDeltaOffset((d) => parseFloat((d + 0.1).toFixed(1)))} className="w-8 h-8 font-mono text-[#54ACBF] transition-all hover:bg-[rgba(84,172,191,0.2)]" style={{ border: `1px solid ${CA(0.3)}` }}>+</button>
              </div>
            </div>

            {/* Tuner info */}
            <div style={{ ...PANEL, padding: "10px 12px" }}>
              <div className="flex justify-between mb-1.5">
                <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)]">Center Freq</span>
                <span className="font-mono text-[10px] text-[#54ACBF]">{(freq / 1e6).toFixed(3)} MHz</span>
              </div>
              <div className="flex justify-between mb-1.5">
                <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)]">BW</span>
                <span className="font-mono text-[10px] text-[#54ACBF]">{bandwidth} kHz</span>
              </div>
              <div className="flex justify-between mb-1.5">
                <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)]">Sample Rate</span>
                <span className="font-mono text-[10px] text-[#54ACBF]">{sampleRate} MS/s</span>
              </div>
              <div className="flex justify-between">
                <span className="font-mono text-[9px] uppercase text-[rgba(84,172,191,0.45)]">Modulation</span>
                <span className="font-mono text-[10px] text-[#54ACBF]">{mode}</span>
              </div>
            </div>

            {/* Volume */}
            <div>
              <SectionHeader label="Audio Output" />
              <LabeledSlider label="Volume" value={volume} min={0} max={100} step={1} unit="%" onChange={setVolume} />
              <div className="mt-2">
                <select value={audioOut} onChange={(e) => setAudioOut(e.target.value)}
                  className="w-full bg-[rgba(2,10,15,0.8)] font-mono text-[#54ACBF] text-[10px] px-2 py-2 outline-none"
                  style={{ border: `1px solid ${CA(0.25)}` }}>
                  <option>INTERNAL SPEAKERS</option>
                  <option>HEADPHONES</option>
                  <option>USB AUDIO</option>
                  <option>VIRTUAL CABLE</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── BOTTOM FOOTER BAR ── */}
      <div className="relative z-10 flex items-center justify-between px-6 py-2.5 flex-shrink-0 border-t border-[rgba(84,172,191,0.15)] bg-[rgba(4,14,20,0.85)] backdrop-blur-md">
        <div className="flex items-center gap-4">
          <span className="font-['Inter:Bold',sans-serif] font-bold text-[rgba(84,172,191,0.45)] text-[10px] uppercase tracking-wider">FEED</span>
          <button
            onClick={() => setIsLive(!isLive)}
            className="flex items-center gap-2 px-3 py-1 font-['Inter:Bold',sans-serif] font-bold text-[10px] uppercase tracking-wider transition-all"
            style={{ background: isLive ? CA(0.4) : CA(0.08), color: isLive ? "#020B10" : "#54ACBF", border: `1px solid ${CA(isLive ? 0.8 : 0.3)}` }}
          >
            {isLive ? "▶ LIVE_STREAM" : "● REC_MODE"}
          </button>
          <span className="font-['Inter:Bold',sans-serif] font-bold text-[rgba(84,172,191,0.45)] text-[10px] uppercase tracking-wider">OUTPUT</span>
          <select value={audioOut} onChange={(e) => setAudioOut(e.target.value)}
            className="bg-[rgba(2,10,15,0.6)] font-mono text-[#54ACBF] text-[10px] px-2 py-1 outline-none"
            style={{ border: `1px solid ${CA(0.25)}` }}>
            <option>INTERNAL SPEAKERS</option>
            <option>HEADPHONES</option>
            <option>USB AUDIO</option>
          </select>
          <div className="flex items-center gap-1.5">
            <Volume2 size={11} color={CA(0.5)} />
            <div className="w-20 h-1" style={{ background: CA(0.1) }}>
              <div className="h-full" style={{ width: `${volume}%`, background: CA(0.6) }} />
            </div>
            <span className="font-mono text-[rgba(84,172,191,0.6)] text-[9px]">{volume}%</span>
          </div>
        </div>
        <div className="flex items-center gap-5">
          <div className="flex flex-col items-end">
            <span className="font-mono text-[rgba(84,172,191,0.4)] text-[8px] uppercase">CPU Load</span>
            <span className="font-mono text-[rgba(84,172,191,0.7)] text-[10px]">12%</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="font-mono text-[rgba(84,172,191,0.4)] text-[8px] uppercase">Buffer</span>
            <span className="font-mono text-[rgba(84,172,191,0.7)] text-[10px]">1024ms</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="font-mono text-[rgba(84,172,191,0.4)] text-[8px] uppercase">PPM</span>
            <span className="font-mono text-[rgba(84,172,191,0.7)] text-[10px]">{ppm}</span>
          </div>
        </div>
      </div>
    </div>
  );
}