import { createBrowserRouter } from "react-router";
import Root from "./components/Root";
import BrickRoad from "./components/BrickRoad";
import RtlSdrPage from "./components/RtlSdrPage";
import PlutoSdrPage from "./components/PlutoSdrPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: BrickRoad },
      { path: "rtl-sdr", Component: RtlSdrPage },
      { path: "pluto", Component: PlutoSdrPage },
    ],
  },
]);
