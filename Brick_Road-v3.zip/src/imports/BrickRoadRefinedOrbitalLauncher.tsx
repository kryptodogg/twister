import clsx from "clsx";
import svgPaths from "./svg-owcz4b51oi";
import imgBrickRoadRefinedOrbitalLauncher from "figma:asset/4848057d62f972cd7ff1167d004ac4f21357ad47.png";
type OverlayBorderOverlayBlurBackgroundImageProps = {
  additionalClassNames?: string;
};

function OverlayBorderOverlayBlurBackgroundImage({ children, additionalClassNames = "" }: React.PropsWithChildren<OverlayBorderOverlayBlurBackgroundImageProps>) {
  return (
    <div className={clsx("backdrop-blur-[4px] bg-[rgba(87,242,242,0.03)] justify-self-stretch relative self-start shrink-0", additionalClassNames)}>
      <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.1)] border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col items-start justify-between p-[17px] relative w-full">{children}</div>
    </div>
  );
}

function ContainerBackgroundImage1({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center pb-[47.5px] pt-[47.48px] relative w-full">{children}</div>
    </div>
  );
}

function ContainerBackgroundImage({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-between relative w-full">{children}</div>
    </div>
  );
}
type ContainerBackgroundImageAndText1Props = {
  text: string;
};

function ContainerBackgroundImageAndText1({ text }: ContainerBackgroundImageAndText1Props) {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(87,242,242,0.6)] tracking-[1px] uppercase w-full">
        <p className="leading-[15px]">{text}</p>
      </div>
    </div>
  );
}
type BackgroundImage1Props = {
  additionalClassNames?: string;
};

function BackgroundImage1({ additionalClassNames = "" }: BackgroundImage1Props) {
  return (
    <div className={additionalClassNames}>
      <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.4)] border-solid inset-0 pointer-events-none" />
    </div>
  );
}
type BackgroundImageProps = {
  additionalClassNames?: string;
};

function BackgroundImage({ additionalClassNames = "" }: BackgroundImageProps) {
  return <BackgroundImage1 additionalClassNames={clsx("bg-[rgba(87,242,242,0.2)] justify-self-stretch relative self-stretch shrink-0", additionalClassNames)} />;
}
type ContainerBackgroundImageAndTextProps = {
  text: string;
};

function ContainerBackgroundImageAndText({ text }: ContainerBackgroundImageAndTextProps) {
  return (
    <div className="opacity-80 relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative w-full">
        <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] tracking-[0.6px] uppercase w-full">
          <p className="leading-[16px]">{text}</p>
        </div>
      </div>
    </div>
  );
}
type OverlayBackgroundImageAndTextProps = {
  text: string;
};

function OverlayBackgroundImageAndText({ text }: OverlayBackgroundImageAndTextProps) {
  return (
    <div className="bg-[rgba(87,242,242,0.2)] content-stretch flex flex-col items-start px-[8px] py-[2px] relative shrink-0">
      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[10px] w-[71.33px]">
        <p className="leading-[15px]">{text}</p>
      </div>
    </div>
  );
}

export default function BrickRoadRefinedOrbitalLauncher() {
  return (
    <div className="content-stretch flex flex-col items-start relative size-full" data-name="Brick Road - Refined Orbital Launcher">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <div className="absolute bg-[#102222] inset-0" />
        <div className="absolute inset-0 overflow-hidden">
          <img alt="" className="absolute h-[125%] left-0 max-w-none top-[-12.5%] w-full" src={imgBrickRoadRefinedOrbitalLauncher} />
        </div>
        <div className="absolute bg-[rgba(2,6,23,0.7)] inset-0" />
      </div>
      <div className="relative shrink-0 w-full" data-name="Header">
        <div className="content-stretch flex items-start justify-between p-[32px] relative w-full">
          <div className="content-stretch flex flex-col items-start pb-[10px] relative shrink-0" data-name="Heading 1">
            <div aria-hidden="true" className="absolute border-[rgba(87,242,242,0.3)] border-b-2 border-solid inset-0 pointer-events-none" />
            <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[60px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[60px] tracking-[-3px] w-[338.94px]">
              <p className="leading-[60px]">BRICK ROAD</p>
            </div>
          </div>
          <div className="content-stretch flex gap-[16px] items-start relative shrink-0" data-name="Container">
            <div className="backdrop-blur-[4px] bg-[rgba(87,242,242,0.03)] content-stretch flex items-center justify-center p-px relative shrink-0 size-[40px]" data-name="Button">
              <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.1)] border-solid inset-0 pointer-events-none" />
              <div className="h-[20px] relative shrink-0 w-[20.1px]" data-name="Container">
                <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.1 20">
                  <g id="Container">
                    <path d={svgPaths.p3cdadd00} fill="var(--fill-0, #57F2F2)" id="Icon" />
                  </g>
                </svg>
              </div>
            </div>
            <div className="backdrop-blur-[4px] bg-[rgba(87,242,242,0.03)] content-stretch flex items-center justify-center p-px relative shrink-0 size-[40px]" data-name="Button">
              <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.1)] border-solid inset-0 pointer-events-none" />
              <div className="relative shrink-0 size-[14px]" data-name="Container">
                <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
                  <g id="Container">
                    <path d={svgPaths.p15494480} fill="var(--fill-0, #57F2F2)" id="Icon" />
                  </g>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="relative shrink-0 w-full" data-name="Main">
        <div className="flex flex-row items-center justify-center size-full">
          <div className="content-stretch flex items-center justify-center px-[32px] py-[83.5px] relative w-full">
            <div className="flex-[1_0_0] gap-x-[24px] gap-y-[24px] grid grid-cols-[repeat(3,minmax(0,1fr))] grid-rows-[__292px_292px] h-[608px] max-w-[1280px] min-h-px min-w-px relative" data-name="Container">
              <OverlayBorderOverlayBlurBackgroundImage additionalClassNames="col-1 row-1">
                <ContainerBackgroundImage>
                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] tracking-[1.2px] uppercase w-[60.48px]">
                    <p className="leading-[16px]">RTL-SDR</p>
                  </div>
                  <OverlayBackgroundImageAndText text="[CONNECTED]" />
                </ContainerBackgroundImage>
                <ContainerBackgroundImage1>
                  <div className="flex-[1_0_0] h-[128px] min-h-px min-w-px relative" data-name="Container">
                    <div className="flex flex-row items-end justify-center size-full">
                      <div className="content-stretch flex gap-[4px] items-end justify-center px-[16px] relative size-full">
                        <div className="bg-[rgba(87,242,242,0.4)] flex-[1_0_0] h-[25.59px] min-h-px min-w-px" data-name="Overlay" />
                        <div className="bg-[#57f2f2] flex-[1_0_0] h-[76.8px] min-h-px min-w-px" data-name="Background" />
                        <div className="bg-[rgba(87,242,242,0.6)] flex-[1_0_0] h-[51.19px] min-h-px min-w-px" data-name="Overlay" />
                        <div className="bg-[#57f2f2] flex-[1_0_0] h-[115.19px] min-h-px min-w-px" data-name="Background" />
                        <div className="bg-[rgba(87,242,242,0.4)] flex-[1_0_0] h-[38.39px] min-h-px min-w-px" data-name="Overlay" />
                        <div className="bg-[#57f2f2] flex-[1_0_0] h-[89.59px] min-h-px min-w-px" data-name="Background" />
                        <div className="bg-[rgba(87,242,242,0.2)] flex-[1_0_0] h-[19.19px] min-h-px min-w-px" data-name="Overlay" />
                        <div className="bg-[#57f2f2] flex-[1_0_0] h-[64px] min-h-px min-w-px" data-name="Background" />
                        <div className="bg-[rgba(87,242,242,0.8)] flex-[1_0_0] h-[108.8px] min-h-px min-w-px" data-name="Overlay" />
                      </div>
                    </div>
                  </div>
                </ContainerBackgroundImage1>
                <ContainerBackgroundImageAndText text="Spectral density bars" />
              </OverlayBorderOverlayBlurBackgroundImage>
              <OverlayBorderOverlayBlurBackgroundImage additionalClassNames="col-2 row-1">
                <ContainerBackgroundImage>
                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] tracking-[1.2px] uppercase w-[83.58px]">
                    <p className="leading-[16px]">PlutoSDR+</p>
                  </div>
                  <OverlayBackgroundImageAndText text="[CONNECTED]" />
                </ContainerBackgroundImage>
                <div className="relative shrink-0 w-full" data-name="Container">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-center justify-center pb-[55.5px] pt-[55.48px] relative w-full">
                    <div className="content-stretch flex flex-col h-[48px] items-start justify-center overflow-clip relative shrink-0 w-full" data-name="Container">
                      <div className="h-[48px] overflow-clip relative shrink-0 w-full" data-name="SVG">
                        <div className="absolute inset-[31.25%_16.23%]" data-name="Vector">
                          <div className="absolute inset-[-3.33%_-0.13%]">
                            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 240.617 19.2">
                              <path d={svgPaths.pde53280} id="Vector" stroke="var(--stroke-0, #57F2F2)" strokeWidth="1.2" />
                            </svg>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="content-stretch flex flex-col h-[48px] items-start justify-center overflow-clip relative shrink-0 w-full" data-name="Container">
                      <div className="h-[48px] overflow-clip relative shrink-0 w-full" data-name="SVG">
                        <div className="absolute inset-[31.25%_16.23%]" data-name="Vector">
                          <div className="absolute inset-[-5%_-0.35%_-5%_-0.27%]">
                            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 241.49 19.8">
                              <path d={svgPaths.p3e39b580} id="Vector" stroke="var(--stroke-0, #57F2F2)" strokeWidth="1.8" />
                            </svg>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <ContainerBackgroundImageAndText text="Dual wave monitors (TX/RX)" />
              </OverlayBorderOverlayBlurBackgroundImage>
              <OverlayBorderOverlayBlurBackgroundImage additionalClassNames="col-3 row-1">
                <ContainerBackgroundImage>
                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] tracking-[1.2px] uppercase w-[152.06px]">
                    <p className="leading-[16px]">Haptic (DualSense)</p>
                  </div>
                  <div className="bg-[rgba(148,163,184,0.1)] content-stretch flex flex-col items-start px-[8px] py-[2px] relative shrink-0" data-name="Overlay">
                    <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#94a3b8] text-[10px] tracking-[-0.25px] uppercase w-[53.28px]">
                      <p className="leading-[15px]">[UNWIRED]</p>
                    </div>
                  </div>
                </ContainerBackgroundImage>
                <div className="relative shrink-0 w-full" data-name="Container">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center py-[47.5px] relative w-full">
                    <div className="content-stretch flex items-center justify-center p-px relative shrink-0 size-[128px]" data-name="Border">
                      <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.2)] border-solid inset-0 pointer-events-none" />
                      <div className="bg-[#57f2f2] shadow-[0px_0px_10px_0px_#57f2f2] shrink-0 size-[8px]" data-name="Background+Shadow" />
                      <div className="absolute flex inset-[-13.78px] items-center justify-center">
                        <div className="flex-none rotate-45 size-[110px]">
                          <BackgroundImage1 additionalClassNames="relative size-full" />
                        </div>
                      </div>
                      <div className="absolute flex inset-[8.26px_8.26px_8.25px_8.25px] items-center justify-center">
                        <div className="-rotate-12 flex-none size-[94px]">
                          <div className="relative size-full" data-name="Border">
                            <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.6)] border-solid inset-0 pointer-events-none" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <ContainerBackgroundImageAndText text="3D DCC-style orientation rings" />
              </OverlayBorderOverlayBlurBackgroundImage>
              <OverlayBorderOverlayBlurBackgroundImage additionalClassNames="col-1 row-2">
                <ContainerBackgroundImage>
                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] tracking-[1.2px] uppercase w-[46.88px]">
                    <p className="leading-[16px]">Pico 2</p>
                  </div>
                  <OverlayBackgroundImageAndText text="[CONNECTED]" />
                </ContainerBackgroundImage>
                <div className="relative shrink-0 w-full" data-name="Container">
                  <div className="flex flex-row items-center justify-center size-full">
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center pb-[62.93px] pt-[62.92px] px-[24px] relative w-full">
                      <div className="flex-[1_0_0] gap-x-[8px] gap-y-[8px] grid grid-cols-[repeat(6,minmax(0,1fr))] grid-rows-[__44.56px_44.56px] h-[97.13px] min-h-px min-w-px relative" data-name="Container">
                        <BackgroundImage additionalClassNames="col-1 row-1" />
                        <div className="bg-[rgba(87,242,242,0.6)] col-2 justify-self-stretch row-1 self-stretch shrink-0" data-name="Overlay" />
                        <BackgroundImage additionalClassNames="col-3 row-1" />
                        <BackgroundImage additionalClassNames="col-4 row-1" />
                        <div className="bg-[#57f2f2] col-5 justify-self-stretch row-1 self-stretch shrink-0" data-name="Background" />
                        <BackgroundImage additionalClassNames="col-6 row-1" />
                        <BackgroundImage additionalClassNames="col-1 row-2" />
                        <div className="bg-[rgba(87,242,242,0.4)] col-2 justify-self-stretch row-2 self-stretch shrink-0" data-name="Overlay" />
                        <BackgroundImage additionalClassNames="col-3 row-2" />
                        <BackgroundImage additionalClassNames="col-4 row-2" />
                        <BackgroundImage additionalClassNames="col-5 row-2" />
                        <div className="bg-[rgba(87,242,242,0.8)] col-6 justify-self-stretch row-2 self-stretch shrink-0" data-name="Overlay" />
                      </div>
                    </div>
                  </div>
                </div>
                <ContainerBackgroundImageAndText text="Graphical GPIO map" />
              </OverlayBorderOverlayBlurBackgroundImage>
              <OverlayBorderOverlayBlurBackgroundImage additionalClassNames="col-2 row-2">
                <ContainerBackgroundImage>
                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] tracking-[1.2px] uppercase w-[195.52px]">
                    <p className="leading-[16px]">8-Channel Phased Array</p>
                  </div>
                  <OverlayBackgroundImageAndText text="[CONNECTED]" />
                </ContainerBackgroundImage>
                <ContainerBackgroundImage1>
                  <div className="relative shrink-0 size-[128px]" data-name="Border">
                    <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none" />
                    <div className="-translate-x-1/2 absolute bg-[rgba(87,242,242,0.3)] bottom-px left-[calc(50%+0.5px)] top-px w-px" data-name="Vertical Divider" />
                    <div className="-translate-y-1/2 absolute bg-[rgba(87,242,242,0.3)] h-px left-px right-px top-[calc(50%+0.5px)]" data-name="Horizontal Divider" />
                    <div className="absolute inset-px" data-name="Gradient" style={{ backgroundImage: "linear-gradient(45deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0) 50%, rgba(87, 242, 242, 0.2) 100%)" }} />
                    <div className="absolute bg-[#57f2f2] inset-[25.39%_71.48%_71.48%_25.39%]" data-name="Background" />
                  </div>
                </ContainerBackgroundImage1>
                <ContainerBackgroundImageAndText text="Radar/disc display" />
              </OverlayBorderOverlayBlurBackgroundImage>
              <div className="backdrop-blur-[4px] bg-[rgba(87,242,242,0.03)] col-3 justify-self-stretch relative row-2 self-start shrink-0" data-name="Overlay+Border+OverlayBlur">
                <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.4)] border-dashed inset-0 pointer-events-none" />
                <div className="flex flex-col items-center justify-center size-full">
                  <div className="content-stretch flex flex-col items-center justify-center px-[17px] py-[100px] relative w-full">
                    <div className="relative shrink-0 size-[47.5px]" data-name="Container">
                      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 47.4998 47.4998">
                        <g id="Container">
                          <path d={svgPaths.p2658c480} fill="var(--fill-0, #57F2F2)" id="Icon" />
                        </g>
                      </svg>
                    </div>
                    <div className="relative shrink-0" data-name="Margin">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[16px] relative">
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] tracking-[3.6px] uppercase w-[205.44px]">
                          <p className="leading-[16px]">Integrate Hardware</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="bg-gradient-to-t from-[rgba(16,34,34,0.8)] relative shrink-0 to-[rgba(16,34,34,0)] w-full" data-name="Footer">
        <div className="flex flex-row items-end size-full">
          <div className="content-stretch flex items-end justify-between p-[32px] relative w-full">
            <div className="content-stretch flex gap-[48px] h-[66px] items-start relative shrink-0" data-name="Container">
              <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[251.41px]" data-name="Container">
                <div className="content-stretch flex flex-col items-start pb-[4px] relative shrink-0 w-full" data-name="Margin">
                  <ContainerBackgroundImageAndText1 text="System Telemetry" />
                </div>
                <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[32px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[24px] text-shadow-[0px_0px_10px_rgba(87,242,242,0.4)] tracking-[-1.2px] w-[251.41px]">
                    <p className="leading-[32px]">{`STABLE // 98.4% SCAN`}</p>
                  </div>
                </div>
              </div>
              <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[82.72px]" data-name="Container">
                <div className="content-stretch flex flex-col items-start pb-[4px] relative shrink-0 w-full" data-name="Margin">
                  <ContainerBackgroundImageAndText1 text="Forensic Status" />
                </div>
                <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[32px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[24px] text-shadow-[0px_0px_10px_rgba(87,242,242,0.4)] tracking-[-1.2px] w-[82.72px]">
                    <p className="leading-[32px]">ACTIVE</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Container">
              <div className="content-stretch flex flex-col items-end relative shrink-0" data-name="Container">
                <div className="content-stretch flex flex-col items-start pb-[4px] relative shrink-0" data-name="Margin">
                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(87,242,242,0.6)] tracking-[1px] uppercase w-[54.31px]">
                    <p className="leading-[15px]">Latency</p>
                  </div>
                </div>
                <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                  <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[28px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[20px] tracking-[-1px] w-[45.17px]">
                    <p className="leading-[28px]">12ms</p>
                  </div>
                </div>
              </div>
              <div className="backdrop-blur-[4px] bg-[rgba(87,242,242,0.2)] content-stretch flex gap-[8px] h-[40px] items-center px-[25px] py-px relative shrink-0" data-name="Overlay+Border+OverlayBlur">
                <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.1)] border-solid inset-0 pointer-events-none" />
                <div className="h-[11.708px] relative shrink-0 w-[11.694px]" data-name="Container">
                  <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.6939 11.7078">
                    <g id="Container">
                      <path d={svgPaths.p17f78f00} fill="var(--fill-0, #57F2F2)" id="Icon" />
                    </g>
                  </svg>
                </div>
                <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[20px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[14px] tracking-[1.4px] uppercase w-[136.5px]">
                  <p className="leading-[20px]">Deploy System</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}