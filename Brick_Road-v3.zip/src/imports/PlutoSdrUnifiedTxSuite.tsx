import clsx from "clsx";
import svgPaths from "./svg-56xjxldgsc";
import imgHighContrastModernElectronicsLaboratoryWithOscilloscopesAndTestingEquipment from "figma:asset/6cdc195c8d447e165439b039ff926d8db70d89fb.png";
type OverlayBorder1Props = {
  additionalClassNames?: string;
};

function OverlayBorder1({ children, additionalClassNames = "" }: React.PropsWithChildren<OverlayBorder1Props>) {
  return (
    <div className={clsx("bg-[rgba(16,34,32,0.4)] justify-self-stretch relative row-1 self-stretch shrink-0", additionalClassNames)}>
      <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col items-start justify-between p-[17px] relative size-full">{children}</div>
    </div>
  );
}

function Container2({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center relative">{children}</div>
    </div>
  );
}
type OverlayBorderProps = {
  additionalClassNames?: string;
};

function OverlayBorder({ children, additionalClassNames = "" }: React.PropsWithChildren<OverlayBorderProps>) {
  return (
    <div className={clsx("relative shrink-0 w-full", additionalClassNames)}>
      <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col gap-[16px] items-start p-[17px] relative w-full">{children}</div>
    </div>
  );
}
type Container1Props = {
  additionalClassNames?: string;
};

function Container1({ children, additionalClassNames = "" }: React.PropsWithChildren<Container1Props>) {
  return (
    <div className={clsx("relative shrink-0 w-full", additionalClassNames)}>
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-start relative w-full">{children}</div>
    </div>
  );
}
type ParagraphProps = {
  additionalClassNames?: string;
};

function Paragraph({ children, additionalClassNames = "" }: React.PropsWithChildren<ParagraphProps>) {
  return (
    <div className={clsx("relative self-stretch shrink-0", additionalClassNames)}>
      <div className="bg-clip-padding border-0 border-[transparent] border-solid font-['Liberation_Mono:Regular',sans-serif] leading-[0] not-italic relative size-full text-[#54acbf]">{children}</div>
    </div>
  );
}

function Container({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between relative w-full">{children}</div>
    </div>
  );
}

function Button({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center justify-center p-[8px] relative">{children}</div>
    </div>
  );
}

function Wrapper1({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative self-stretch shrink-0">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-full items-start relative">{children}</div>
    </div>
  );
}

function Wrapper({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative w-full">{children}</div>
    </div>
  );
}
type ContainerText3Props = {
  text: string;
};

function ContainerText3({ text }: ContainerText3Props) {
  return (
    <Wrapper>
      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[24px] w-full">
        <p className="leading-[32px]">{text}</p>
      </div>
    </Wrapper>
  );
}
type ContainerText2Props = {
  text: string;
};

function ContainerText2({ text }: ContainerText2Props) {
  return (
    <Wrapper>
      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(84,172,191,0.6)] uppercase w-full">
        <p className="leading-[15px]">{text}</p>
      </div>
    </Wrapper>
  );
}
type ContainerText1Props = {
  text: string;
};

function ContainerText1({ text }: ContainerText1Props) {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full">
      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[28px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[20px] text-right w-[60.02px]">
        <p className="leading-[28px]">{text}</p>
      </div>
    </div>
  );
}
type ContainerTextProps = {
  text: string;
};

function ContainerText({ text }: ContainerTextProps) {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0">
      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] w-[18.02px]">
        <p className="leading-[15px]">{text}</p>
      </div>
    </div>
  );
}
type LabelText1Props = {
  text: string;
};

function LabelText1({ text }: LabelText1Props) {
  return (
    <Wrapper1>
      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(84,172,191,0.6)] uppercase w-[25.09px]">
        <p className="leading-[15px]">{text}</p>
      </div>
    </Wrapper1>
  );
}
type LabelTextProps = {
  text: string;
};

function LabelText({ text }: LabelTextProps) {
  return (
    <Wrapper1>
      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(84,172,191,0.6)] uppercase w-[62.02px]">
        <p className="leading-[15px]">{text}</p>
      </div>
    </Wrapper1>
  );
}

export default function PlutoSdrUnifiedTxSuite() {
  return (
    <div className="bg-[#102220] content-stretch flex flex-col items-start relative size-full" data-name="PlutoSDR+ - Unified TX Suite">
      <div className="absolute content-stretch flex flex-col inset-0 items-start justify-center" data-name="Background Image: Sharp Laboratory">
        <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="High-contrast modern electronics laboratory with oscilloscopes and testing equipment">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <img alt="" className="absolute h-[125%] left-0 max-w-none top-[-12.5%] w-full" src={imgHighContrastModernElectronicsLaboratoryWithOscilloscopesAndTestingEquipment} />
          </div>
        </div>
        <div className="absolute bg-[rgba(16,34,32,0.4)] inset-0" data-name="Overlay" />
      </div>
      <div className="h-[1024px] relative shrink-0 w-full" data-name="Main Fullscreen Slab">
        <div className="flex flex-col justify-center size-full">
          <div className="content-stretch flex flex-col items-start justify-center p-[24px] relative size-full">
            <div className="backdrop-blur-[4px] bg-[rgba(16,34,32,0.1)] flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Overlay+Border+OverlayBlur">
              <div className="content-stretch flex flex-col items-start overflow-clip p-px relative rounded-[inherit] size-full">
                <div className="relative shrink-0 w-full" data-name="Unified Header">
                  <div aria-hidden="true" className="absolute border-[rgba(84,172,191,0.3)] border-b border-solid inset-0 pointer-events-none" />
                  <div className="flex flex-row items-center size-full">
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pb-[17px] pt-[16px] px-[24px] relative w-full">
                      <div className="relative shrink-0" data-name="Container">
                        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[24px] items-center relative">
                          <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="Container">
                            <div className="h-[26.75px] relative shrink-0 w-[27.5px]" data-name="Container">
                              <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27.5 26.75">
                                <g id="Container">
                                  <path d={svgPaths.p21608380} fill="var(--fill-0, #54ACBF)" id="Icon" />
                                </g>
                              </svg>
                            </div>
                            <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Heading 1">
                              <div className="flex flex-col font-['Inter:Black',sans-serif] font-black h-[20px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[20px] tracking-[-1px] uppercase w-[170.98px]">
                                <p className="leading-[20px]">PlutoSDR+ Suite</p>
                              </div>
                            </div>
                          </div>
                          <div className="content-stretch flex gap-[4px] items-start relative shrink-0" data-name="Nav">
                            <div className="bg-[#54acbf] content-stretch flex flex-col items-center justify-center pb-[9.5px] pt-[8.5px] px-[24px] relative shrink-0" data-name="Button">
                              <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#102220] text-[12px] text-center tracking-[1.2px] uppercase w-[108.28px]">
                                <p className="leading-[16px]">TRANSMISSION</p>
                              </div>
                            </div>
                            <div className="content-stretch flex flex-col items-center justify-center px-[25px] py-[9px] relative shrink-0" data-name="Button">
                              <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
                              <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[12px] text-center tracking-[1.2px] uppercase w-[79.69px]">
                                <p className="leading-[16px]">RECEPTION</p>
                              </div>
                            </div>
                            <div className="content-stretch flex flex-col items-center justify-center px-[25px] py-[9px] relative shrink-0" data-name="Button">
                              <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
                              <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[12px] text-center tracking-[1.2px] uppercase w-[70.27px]">
                                <p className="leading-[16px]">ANALYSIS</p>
                              </div>
                            </div>
                            <div className="content-stretch flex flex-col items-center justify-center px-[25px] py-[9px] relative shrink-0" data-name="Button">
                              <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
                              <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[12px] text-center tracking-[1.2px] uppercase w-[70.16px]">
                                <p className="leading-[16px]">SETTINGS</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="relative shrink-0" data-name="Border">
                        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
                        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-px items-start p-px relative">
                          <Button>
                            <div className="h-[1.167px] relative shrink-0 w-[8.167px]" data-name="Container">
                              <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.16667 1.16667">
                                <g id="Container">
                                  <path d={svgPaths.p3ab8d800} fill="var(--fill-0, #54ACBF)" id="Icon" />
                                </g>
                              </svg>
                            </div>
                          </Button>
                          <div className="relative shrink-0" data-name="Button">
                            <div aria-hidden="true" className="absolute border-[rgba(84,172,191,0.3)] border-l border-r border-solid inset-0 pointer-events-none" />
                            <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center justify-center px-[9px] py-[8px] relative">
                              <div className="relative shrink-0 size-[10.5px]" data-name="Container">
                                <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5 10.5">
                                  <g id="Container">
                                    <path d={svgPaths.p2b5b6770} fill="var(--fill-0, #54ACBF)" id="Icon" />
                                  </g>
                                </svg>
                              </div>
                            </div>
                          </div>
                          <Button>
                            <div className="relative shrink-0 size-[8.167px]" data-name="Container">
                              <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.16667 8.16667">
                                <g id="Container">
                                  <path d={svgPaths.p2317cf00} fill="var(--fill-0, #54ACBF)" id="Icon" />
                                </g>
                              </svg>
                            </div>
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Main - Content Area">
                  <div className="flex flex-col justify-center overflow-clip rounded-[inherit] size-full">
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start justify-center p-[32px] relative size-full">
                      <div className="flex-[1_0_0] gap-x-[32px] gap-y-[32px] grid grid-cols-[repeat(12,minmax(0,1fr))] grid-rows-[_791px] min-h-px min-w-px relative w-full" data-name="Container">
                        <div className="col-[1/span_4] content-stretch flex flex-col gap-[32px] items-start justify-self-stretch relative row-1 self-stretch shrink-0" data-name="Left Column: Controls">
                          <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="TX Channels">
                            <OverlayBorder additionalClassNames="bg-[rgba(16,34,32,0.4)]">
                              <Container>
                                <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] tracking-[2px] uppercase w-[98.33px]">
                                    <p className="leading-[15px]">Channel TX-1</p>
                                  </div>
                                </div>
                                <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                                  <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[12px] w-[43.22px]">
                                    <p className="leading-[16px]">ACTIVE</p>
                                  </div>
                                </div>
                              </Container>
                              <Container1>
                                <div className="content-stretch flex h-[24px] items-start justify-between pb-[9px] relative shrink-0 w-full" data-name="HorizontalBorder">
                                  <div aria-hidden="true" className="absolute border-[rgba(84,172,191,0.2)] border-b border-solid inset-0 pointer-events-none" />
                                  <LabelText text="Frequency" />
                                  <Paragraph additionalClassNames="w-[82.83px]">
                                    <div className="-translate-y-1/2 absolute flex flex-col h-[28px] justify-center left-0 text-[18px] top-[14px] w-[64.81px]">
                                      <p className="leading-[28px]">{`2.412 `}</p>
                                    </div>
                                    <div className="-translate-y-1/2 absolute flex flex-col h-[28px] justify-center left-[64.81px] text-[10px] top-[16.5px] w-[18.02px]">
                                      <p className="leading-[28px]">GHz</p>
                                    </div>
                                  </Paragraph>
                                </div>
                                <div className="content-stretch flex h-[24px] items-start justify-between pb-[9px] relative shrink-0 w-full" data-name="HorizontalBorder">
                                  <div aria-hidden="true" className="absolute border-[rgba(84,172,191,0.2)] border-b border-solid inset-0 pointer-events-none" />
                                  <LabelText1 text="Gain" />
                                  <Paragraph additionalClassNames="w-[82.83px]">
                                    <div className="-translate-y-1/2 absolute flex flex-col h-[28px] justify-center left-0 text-[18px] top-[14px] w-[64.81px]">
                                      <p className="leading-[28px]">{`-12.0 `}</p>
                                    </div>
                                    <div className="-translate-y-1/2 absolute flex flex-col h-[28px] justify-center left-[64.81px] text-[10px] top-[16.5px] w-[18.02px]">
                                      <p className="leading-[28px]">dBm</p>
                                    </div>
                                  </Paragraph>
                                </div>
                              </Container1>
                            </OverlayBorder>
                            <OverlayBorder additionalClassNames="bg-[rgba(16,34,32,0.2)]">
                              <Container>
                                <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(84,172,191,0.4)] tracking-[2px] uppercase w-[100.09px]">
                                    <p className="leading-[15px]">Channel TX-2</p>
                                  </div>
                                </div>
                                <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                                  <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-[rgba(84,172,191,0.4)] w-[50.42px]">
                                    <p className="leading-[16px]">STANDBY</p>
                                  </div>
                                </div>
                              </Container>
                              <Container1 additionalClassNames="opacity-40">
                                <div className="content-stretch flex h-[24px] items-start justify-between pb-[9px] relative shrink-0 w-full" data-name="HorizontalBorder">
                                  <div aria-hidden="true" className="absolute border-[rgba(84,172,191,0.2)] border-b border-solid inset-0 pointer-events-none" />
                                  <LabelText text="Frequency" />
                                  <Paragraph additionalClassNames="w-[82.83px]">
                                    <div className="-translate-y-1/2 absolute flex flex-col h-[28px] justify-center left-0 text-[18px] top-[14px] w-[64.81px]">
                                      <p className="leading-[28px]">{`5.800 `}</p>
                                    </div>
                                    <div className="-translate-y-1/2 absolute flex flex-col h-[28px] justify-center left-[64.81px] text-[10px] top-[16.5px] w-[18.02px]">
                                      <p className="leading-[28px]">GHz</p>
                                    </div>
                                  </Paragraph>
                                </div>
                                <div className="content-stretch flex h-[24px] items-start justify-between pb-[9px] relative shrink-0 w-full" data-name="HorizontalBorder">
                                  <div aria-hidden="true" className="absolute border-[rgba(84,172,191,0.2)] border-b border-solid inset-0 pointer-events-none" />
                                  <LabelText1 text="Gain" />
                                  <Paragraph additionalClassNames="w-[72.03px]">
                                    <div className="-translate-y-1/2 absolute flex flex-col h-[28px] justify-center left-0 text-[18px] top-[14px] w-[54.02px]">
                                      <p className="leading-[28px]">{`-0.0 `}</p>
                                    </div>
                                    <div className="-translate-y-1/2 absolute flex flex-col h-[28px] justify-center left-[54.01px] text-[10px] top-[16.5px] w-[18.02px]">
                                      <p className="leading-[28px]">dBm</p>
                                    </div>
                                  </Paragraph>
                                </div>
                              </Container1>
                            </OverlayBorder>
                          </div>
                          <div className="bg-[rgba(16,34,32,0.4)] content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px p-px relative w-full" data-name="Waveform Generator Suite">
                            <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
                            <div className="bg-[rgba(84,172,191,0.1)] relative shrink-0 w-full" data-name="Overlay+HorizontalBorder">
                              <div aria-hidden="true" className="absolute border-[rgba(84,172,191,0.3)] border-b border-solid inset-0 pointer-events-none" />
                              <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[9px] pt-[8px] px-[16px] relative w-full">
                                <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] tracking-[2px] uppercase w-[158.75px]">
                                  <p className="leading-[15px]">Waveform Generator</p>
                                </div>
                              </div>
                            </div>
                            <div className="relative shrink-0 w-full" data-name="Container">
                              <div className="bg-clip-padding border-0 border-[transparent] border-solid gap-x-[16px] gap-y-[16px] grid grid-cols-[repeat(2,minmax(0,1fr))] grid-rows-[__93px_93px] p-[24px] relative w-full">
                                <div className="bg-[rgba(84,172,191,0.2)] col-1 content-stretch flex flex-col gap-[8px] items-center justify-center justify-self-start px-[60.33px] py-[17px] relative row-1 self-start shrink-0" data-name="Button">
                                  <div aria-hidden="true" className="absolute border border-[#54acbf] border-solid inset-0 pointer-events-none" />
                                  <div className="h-[16.25px] relative shrink-0 w-[25px]" data-name="Container">
                                    <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 16.25">
                                      <g id="Container">
                                        <path d={svgPaths.p273d8540} fill="var(--fill-0, #54ACBF)" id="Icon" />
                                      </g>
                                    </svg>
                                  </div>
                                  <Container2>
                                    <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] text-center uppercase w-[23.06px]">
                                      <p className="leading-[15px]">Sine</p>
                                    </div>
                                  </Container2>
                                </div>
                                <div className="col-2 content-stretch flex flex-col gap-[8px] items-center justify-center justify-self-start pl-[60.32px] pr-[60.35px] py-[17px] relative row-1 self-start shrink-0" data-name="Button">
                                  <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
                                  <div className="relative shrink-0 size-[25px]" data-name="Container">
                                    <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 25">
                                      <g id="Container">
                                        <path d={svgPaths.p1323a900} fill="var(--fill-0, #54ACBF)" fillOpacity="0.6" id="Icon" />
                                      </g>
                                    </svg>
                                  </div>
                                  <Container2>
                                    <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(84,172,191,0.6)] text-center uppercase w-[23.53px]">
                                      <p className="leading-[15px]">Saw</p>
                                    </div>
                                  </Container2>
                                </div>
                                <div className="col-1 content-stretch flex flex-col gap-[8px] items-center justify-center justify-self-start px-[54.55px] py-[17px] relative row-2 self-start shrink-0" data-name="Button">
                                  <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
                                  <div className="h-[20px] relative shrink-0 w-[25px]" data-name="Container">
                                    <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 20">
                                      <g id="Container">
                                        <path d={svgPaths.p8099080} fill="var(--fill-0, #54ACBF)" fillOpacity="0.6" id="Icon" />
                                      </g>
                                    </svg>
                                  </div>
                                  <Container2>
                                    <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(84,172,191,0.6)] text-center uppercase w-[41.56px]">
                                      <p className="leading-[15px]">Square</p>
                                    </div>
                                  </Container2>
                                </div>
                                <div className="col-2 content-stretch flex flex-col gap-[8px] items-center justify-center justify-self-start px-[39.89px] py-[17px] relative row-2 self-start shrink-0" data-name="Button">
                                  <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
                                  <div className="h-[22.5px] relative shrink-0 w-[20px]" data-name="Container">
                                    <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 22.5">
                                      <g id="Container">
                                        <path d={svgPaths.p1fb26300} fill="var(--fill-0, #54ACBF)" fillOpacity="0.6" id="Icon" />
                                      </g>
                                    </svg>
                                  </div>
                                  <Container2>
                                    <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(84,172,191,0.6)] text-center uppercase w-[70.89px]">
                                      <p className="leading-[15px]">Impulse UWB</p>
                                    </div>
                                  </Container2>
                                </div>
                              </div>
                            </div>
                            <div className="relative shrink-0 w-full" data-name="Container">
                              <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[16px] items-start pb-[24px] px-[24px] relative w-full">
                                <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="Container">
                                  <div className="content-stretch flex h-[15px] items-start justify-between relative shrink-0 w-full" data-name="Container">
                                    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Container">
                                      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] uppercase w-[64.39px]">
                                        <p className="leading-[15px]">Duty Cycle</p>
                                      </div>
                                    </div>
                                    <ContainerText text="50%" />
                                  </div>
                                  <div className="bg-[rgba(84,172,191,0.2)] h-[4px] relative shrink-0 w-full" data-name="Overlay">
                                    <div className="absolute bg-[#54acbf] bottom-0 left-0 right-1/2 top-0" data-name="Background" />
                                  </div>
                                </div>
                                <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="Container">
                                  <div className="content-stretch flex h-[15px] items-start justify-between relative shrink-0 w-full" data-name="Container">
                                    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Container">
                                      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] uppercase w-[104.91px]">
                                        <p className="leading-[15px]">Modulation Depth</p>
                                      </div>
                                    </div>
                                    <ContainerText text="85%" />
                                  </div>
                                  <div className="bg-[rgba(84,172,191,0.2)] h-[4px] relative shrink-0 w-full" data-name="Overlay">
                                    <div className="absolute bg-[#54acbf] inset-[0_15%_0_0]" data-name="Background" />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-[5/span_8] content-stretch flex flex-col gap-[32px] items-start justify-self-stretch relative row-1 self-stretch shrink-0" data-name="Right Column: Visualization">
                          <div className="bg-[rgba(16,34,32,0.4)] flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="3D Wave Preview Container">
                            <div className="content-stretch flex flex-col items-start justify-center overflow-clip p-px relative rounded-[inherit] size-full">
                              <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Placeholder for 3D View">
                                <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
                                  <div className="h-[256px] relative shrink-0 w-[764.67px]" data-name="SVG">
                                    <div className="absolute inset-[0_-0.11%]">
                                      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 766.291 256">
                                        <g id="SVG">
                                          <path d={svgPaths.pcc0a680} id="Vector" opacity="0.8" stroke="var(--stroke-0, #54ACBF)" strokeWidth="1.91167" />
                                          <path d={svgPaths.p1a807f80} id="Vector_2" opacity="0.4" stroke="var(--stroke-0, #54ACBF)" strokeWidth="0.955837" />
                                          <path d={svgPaths.p32546280} id="Vector_3" opacity="0.4" stroke="var(--stroke-0, #54ACBF)" strokeWidth="0.955837" />
                                        </g>
                                      </svg>
                                    </div>
                                  </div>
                                  <div className="absolute bottom-[24px] content-stretch flex gap-[15.99px] h-[40px] items-start right-[24px]" data-name="Container">
                                    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[60.02px]" data-name="Container">
                                      <div className="content-stretch flex flex-col items-end relative shrink-0 w-full" data-name="Container">
                                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[12px] justify-center leading-[0] not-italic relative shrink-0 text-[8px] text-[rgba(84,172,191,0.6)] text-right uppercase w-[47.22px]">
                                          <p className="leading-[12px]">Amplitude</p>
                                        </div>
                                      </div>
                                      <ContainerText1 text="1.44V" />
                                    </div>
                                    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[60.02px]" data-name="Container">
                                      <div className="content-stretch flex flex-col items-end relative shrink-0 w-full" data-name="Container">
                                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[12px] justify-center leading-[0] not-italic relative shrink-0 text-[8px] text-[rgba(84,172,191,0.6)] text-right uppercase w-[60px]">
                                          <p className="leading-[12px]">Phase Offset</p>
                                        </div>
                                      </div>
                                      <ContainerText1 text="12.5°" />
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="absolute bg-[rgba(16,34,32,0.8)] left-[17px] top-[14px]" data-name="Overlay">
                                <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start px-[8px] py-[2.5px] relative">
                                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] tracking-[2px] uppercase w-[244.72px]">
                                    <p className="leading-[15px]">Real-time 3D Waveform Analysis</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none" />
                          </div>
                          <div className="gap-x-[16px] gap-y-[16px] grid grid-cols-[repeat(4,minmax(0,1fr))] grid-rows-[_128px] h-[128px] relative shrink-0 w-full" data-name="Technical Readouts Bottom">
                            <OverlayBorder1 additionalClassNames="col-1">
                              <ContainerText2 text="SWR" />
                              <ContainerText3 text="1.12:1" />
                            </OverlayBorder1>
                            <OverlayBorder1 additionalClassNames="col-2">
                              <ContainerText2 text="Efficiency" />
                              <ContainerText3 text="94.2%" />
                            </OverlayBorder1>
                            <OverlayBorder1 additionalClassNames="col-3">
                              <ContainerText2 text="Temperature" />
                              <ContainerText3 text="42.8°C" />
                            </OverlayBorder1>
                            <div className="bg-[rgba(16,34,32,0.4)] col-4 justify-self-stretch relative row-1 self-stretch shrink-0" data-name="Overlay+Border">
                              <div aria-hidden="true" className="absolute border-[rgba(84,172,191,0.3)] border-b border-l-4 border-r border-solid border-t inset-0 pointer-events-none" />
                              <div className="content-stretch flex flex-col items-start justify-between pl-[20px] pr-[17px] py-[17px] relative size-full">
                                <ContainerText2 text="Signal Status" />
                                <Wrapper>
                                  <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[20px] tracking-[-0.5px] uppercase w-full">
                                    <p className="leading-[28px]">TRANSMITTING</p>
                                  </div>
                                </Wrapper>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-[rgba(16,34,32,0.6)] relative shrink-0 w-full" data-name="Unified Footer">
                  <div aria-hidden="true" className="absolute border-[rgba(84,172,191,0.3)] border-solid border-t inset-0 pointer-events-none" />
                  <div className="flex flex-row items-center size-full">
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pb-[12px] pl-[24px] pr-[23.99px] pt-[13px] relative w-full">
                      <div className="h-[15px] relative shrink-0" data-name="Container">
                        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[32px] h-full items-start relative">
                          <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Container">
                            <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(84,172,191,0.7)] uppercase w-[128.08px]">
                              <p className="leading-[15px]">Device: PlutoSDR rev.B</p>
                            </div>
                          </div>
                          <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Container">
                            <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(84,172,191,0.7)] uppercase w-[96.66px]">
                              <p className="leading-[15px]">Buffer: 1024 MS/s</p>
                            </div>
                          </div>
                          <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0" data-name="Container">
                            <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(84,172,191,0.7)] uppercase w-[108.95px]">
                              <p className="leading-[15px]">Firmware: v2.4.1-rc</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="relative shrink-0" data-name="Container">
                        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[15.99px] items-center relative">
                          <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Container">
                            <div className="bg-[#54acbf] rounded-[9999px] shrink-0 size-[8px]" data-name="Background" />
                            <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                              <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] tracking-[1px] uppercase w-[106.97px]">
                                <p className="leading-[15px]">System Nominal</p>
                              </div>
                            </div>
                          </div>
                          <div className="bg-[#54acbf] content-stretch flex flex-col items-center justify-center px-[16px] py-[4px] relative shrink-0" data-name="Button">
                            <div className="flex flex-col font-['Inter:Black',sans-serif] font-black h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#102220] text-[10px] text-center uppercase w-[88.91px]">
                              <p className="leading-[15px]">Emergency Kill</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}