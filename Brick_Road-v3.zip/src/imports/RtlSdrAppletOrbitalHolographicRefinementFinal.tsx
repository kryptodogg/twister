import clsx from "clsx";
import svgPaths from "./svg-7spq5jmfvj";
import imgHighContrastDarkRainyFuturisticCityscape from "figma:asset/4848057d62f972cd7ff1167d004ac4f21357ad47.png";
import imgVerticalDivider from "figma:asset/71d2a6ed73d78c9c3ad789dde24eaf04b6e6d0bb.png";
import imgVerticalDivider1 from "figma:asset/3011c67aebe4a54bde8a43e1c9ab4e38031d53e4.png";
import imgVerticalDivider2 from "figma:asset/2e13d25a2ab40ddfe339915c76d8575f453b1d9f.png";
import imgVerticalDivider3 from "figma:asset/fec21a7d3aebf8cfaced55cdae3ce58813c615ef.png";
import imgVerticalDivider4 from "figma:asset/be5e956d3232797c05e589e62da01614dba12b5b.png";
import imgVerticalDivider5 from "figma:asset/f8806bb8d28f9cd1d71c3a208c6da0437429a4aa.png";
import imgVerticalDivider6 from "figma:asset/b22be3c0650c119ae75dd29d22955df08c85ee32.png";
import imgVerticalDivider7 from "figma:asset/23bd661b13b2c9f998974b31c06387d6358f4de8.png";
import imgVerticalDivider8 from "figma:asset/8850aa67b11e4bc0d2a63ba6201dd81c4d806245.png";
import imgVerticalDivider9 from "figma:asset/151782ed1ee285c917a4d2ab225b4ec5dd6e44c9.png";
import imgVerticalDivider10 from "figma:asset/cf19abb5d77ffddb36d462e73c94d2cdda1410c3.png";
import imgVerticalDivider11 from "figma:asset/ed4cbe48e0c1d1b7645bfce9811c9bd8ead6e5c1.png";
import imgVerticalDivider12 from "figma:asset/ad15c18df0beefd8a879a3494ca3ea2a473849d5.png";
import imgVerticalDivider13 from "figma:asset/d223c63bd1d8d8db61abe8b0b2f892f892ab8acc.png";
import imgVerticalDivider14 from "figma:asset/94c33c25591e3109c3d1f0b63ae8735c04d0a474.png";
import imgVerticalDivider15 from "figma:asset/844824803578e4914ee0c85f79b39813048d2872.png";
import imgVerticalDivider16 from "figma:asset/ab036a71cb8f7915c5ce5556fb050a15f0af3243.png";
import imgVerticalDivider17 from "figma:asset/7cf2f00f63c089a67fee7ac3cb0619cb8d54b12f.png";
import imgHorizontalDivider from "figma:asset/a8ec01d3fafc57d657a3041a2c4f606c18109f38.png";
import { imgSection } from "./svg-xfeyl";
type OverlayBorderShadowOverlayBlurBackgroundImageProps = {
  additionalClassNames?: string;
};

function OverlayBorderShadowOverlayBlurBackgroundImage({ children, additionalClassNames = "" }: React.PropsWithChildren<OverlayBorderShadowOverlayBlurBackgroundImageProps>) {
  return (
    <div className={clsx("backdrop-blur-[6px] bg-[rgba(10,36,36,0.2)] justify-self-stretch relative row-1 self-start shrink-0", additionalClassNames)}>
      <div className="flex flex-col justify-center overflow-clip rounded-[inherit] size-full">{children}</div>
      <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.05)]" />
    </div>
  );
}
type ButtonBackgroundImage1Props = {
  additionalClassNames?: string;
};

function ButtonBackgroundImage1({ children, additionalClassNames = "" }: React.PropsWithChildren<ButtonBackgroundImage1Props>) {
  return (
    <div className={clsx("backdrop-blur-[6px] bg-[rgba(10,36,36,0.2)] relative shrink-0", additionalClassNames)}>
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">{children}</div>
      <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.05)]" />
    </div>
  );
}
type Heading3MarginBackgroundImageProps = {
  text: string;
};

function Heading3MarginBackgroundImage({ children, text }: React.PropsWithChildren<Heading3MarginBackgroundImageProps>) {
  return (
    <div className="relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[12px] relative w-full">
        <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[9px] text-[rgba(87,242,242,0.6)] tracking-[3.6px] uppercase w-full">
            <p className="leading-[13.5px]">{text}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function ContainerBackgroundImage2({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-center relative">{children}</div>
    </div>
  );
}

function ButtonBackgroundImage({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="backdrop-blur-[6px] bg-[rgba(10,36,36,0.2)] relative shrink-0">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[9px] relative rounded-[inherit]">{children}</div>
      <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.05)]" />
    </div>
  );
}

function ContainerBackgroundImage1({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative">{children}</div>
    </div>
  );
}

function ContainerBackgroundImage({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 size-[10.5px]">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5 10.5">
        <g id="Container">{children}</g>
      </svg>
    </div>
  );
}
type Section2HorizontalDividerBackgroundImageProps = {
  additionalClassNames?: string;
};

function Section2HorizontalDividerBackgroundImage({ additionalClassNames = "" }: Section2HorizontalDividerBackgroundImageProps) {
  return (
    <div className={clsx("absolute opacity-20", additionalClassNames)}>
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgHorizontalDivider} />
    </div>
  );
}
type ContainerBackgroundImageAndText1Props = {
  text: string;
};

function ContainerBackgroundImageAndText1({ text }: ContainerBackgroundImageAndText1Props) {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0">
      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[12px] justify-center leading-[0] not-italic relative shrink-0 text-[8px] text-[rgba(87,242,242,0.4)] tracking-[0.8px] uppercase w-[50.42px]">
        <p className="leading-[12px]">{text}</p>
      </div>
    </div>
  );
}
type ContainerBackgroundImageAndTextProps = {
  text: string;
};

function ContainerBackgroundImageAndText({ text }: ContainerBackgroundImageAndTextProps) {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0">
      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[12px] justify-center leading-[0] not-italic relative shrink-0 text-[8px] text-[rgba(87,242,242,0.4)] tracking-[0.8px] uppercase w-[44.81px]">
        <p className="leading-[12px]">{text}</p>
      </div>
    </div>
  );
}

function VerticalDividerBackgroundImage3() {
  return (
    <div className="h-[385.7px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider12} />
      <BackgroundImage />
    </div>
  );
}

function VerticalDividerBackgroundImage2() {
  return (
    <div className="h-[235.48px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider2} />
      <BackgroundImage />
    </div>
  );
}

function VerticalDividerBackgroundImage1() {
  return (
    <div className="h-[263.91px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]">
      <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider} />
      <BackgroundImage />
    </div>
  );
}

function BackgroundImage() {
  return (
    <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
      <div className="-translate-x-1/2 absolute bg-[#57f2f2] h-[2px] left-1/2 shadow-[0px_0px_10px_0px_#57f2f2] top-0 w-[6px]" data-name="Horizontal Divider" />
    </div>
  );
}
type VerticalDividerBackgroundImageProps = {
  additionalClassNames?: string;
};

function VerticalDividerBackgroundImage({ additionalClassNames = "" }: VerticalDividerBackgroundImageProps) {
  return (
    <div className={clsx("bg-gradient-to-t from-[rgba(10,36,36,0.2)] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 to-[rgba(87,242,242,0.8)] w-[2px]", additionalClassNames)}>
      <BackgroundImage />
    </div>
  );
}

export default function RtlSdrAppletOrbitalHolographicRefinementFinal() {
  return (
    <div className="bg-[#020617] content-stretch flex flex-col items-start relative size-full" data-name="RTL-SDR Applet - Orbital Holographic Refinement Final">
      <div className="absolute content-stretch flex flex-col inset-0 items-start justify-center" data-name="Container">
        <div className="flex-[1_0_0] min-h-px min-w-px opacity-80 relative w-full" data-name="High-contrast dark rainy futuristic cityscape">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <img alt="" className="absolute h-[125%] left-0 max-w-none top-[-12.5%] w-full" src={imgHighContrastDarkRainyFuturisticCityscape} />
          </div>
        </div>
        <div className="absolute bg-gradient-to-t from-[rgba(2,6,23,0.8)] inset-0 to-[rgba(2,6,23,0)] via-1/2 via-[rgba(2,6,23,0)]" data-name="Gradient" />
        <div className="absolute inset-0 opacity-30" data-name="Gradient" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1280 1024\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(90.51 0 0 72.408 640 512)\\'><stop stop-color=\\'rgba(87,242,242,0.05)\\' offset=\\'0.035355\\'/><stop stop-color=\\'rgba(87,242,242,0)\\' offset=\\'0.035355\\'/></radialGradient></defs></svg>')" }} />
      </div>
      <div className="h-[1024px] max-w-[1600px] relative shrink-0 w-full" data-name="Container">
        <div className="max-w-[inherit] overflow-clip rounded-[inherit] size-full">
          <div className="content-stretch flex flex-col gap-[24px] items-start max-w-[inherit] p-[40px] relative size-full">
            <div className="content-stretch flex items-end justify-between pb-[17px] relative shrink-0 w-full" data-name="Header">
              <div aria-hidden="true" className="absolute border-[rgba(87,242,242,0.2)] border-b border-solid inset-0 pointer-events-none" />
              <div className="h-[62.98px] relative shrink-0 w-[416.39px]" data-name="Container">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
                  <div className="absolute content-stretch flex flex-col items-start left-0 shadow-[0px_0px_8px_0px_rgba(87,242,242,0.5)] top-0" data-name="Heading 1">
                    <div className="flex flex-col font-['Inter:Black',sans-serif] font-black h-[48px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[48px] tracking-[-2.4px] uppercase w-[191.55px]">
                      <p className="leading-[48px]">RTL-SDR</p>
                    </div>
                  </div>
                  <div className="absolute border-[rgba(87,242,242,0.4)] border-l border-solid h-[35.98px] left-[207.55px] top-[27px] w-[208.84px]" data-name="VerticalBorder">
                    <div className="absolute content-stretch flex flex-col items-start left-[16px] pb-[0.98px] right-0 top-[-1px]" data-name="Container">
                      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[20px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[13.3px] tracking-[4px] uppercase w-[121.95px]">
                        <p className="leading-[20px]">Brick Road</p>
                      </div>
                    </div>
                    <div className="absolute content-stretch flex flex-col items-start left-[16px] right-0 top-[19.98px]" data-name="Container">
                      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[10.7px] text-[rgba(87,242,242,0.6)] w-[191.84px]">
                        <p className="leading-[16px]">SYSTEM_ID: Forensic HUD v4.2.0</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="h-[33px] relative shrink-0" data-name="Container">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] h-full items-start relative">
                  <div className="backdrop-blur-[6px] bg-[rgba(10,36,36,0.2)] relative self-stretch shrink-0" data-name="Overlay+Border+Shadow+OverlayBlur">
                    <div className="flex flex-row items-center overflow-clip rounded-[inherit] size-full">
                      <div className="content-stretch flex gap-[11.99px] h-full items-center px-[17px] py-[9px] relative">
                        <div className="h-[12.483px] relative shrink-0 w-[12.833px]" data-name="Container">
                          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.8333 12.4833">
                            <g id="Container">
                              <path d={svgPaths.p1f148c80} fill="var(--fill-0, #57F2F2)" id="Icon" />
                            </g>
                          </svg>
                        </div>
                        <ContainerBackgroundImage1>
                          <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[10px] tracking-[1px] uppercase w-[112.02px]">
                            <p className="leading-[15px]">V3_DONGLE_ACTIVE</p>
                          </div>
                        </ContainerBackgroundImage1>
                      </div>
                    </div>
                    <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.05)]" />
                  </div>
                  <div className="content-stretch flex gap-[4px] items-start relative self-stretch shrink-0" data-name="Container">
                    <ButtonBackgroundImage>
                      <div className="h-[13.333px] relative shrink-0 w-[13.4px]" data-name="Container">
                        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.4 13.3333">
                          <g id="Container">
                            <path d={svgPaths.p37a13380} fill="var(--fill-0, #57F2F2)" id="Icon" />
                          </g>
                        </svg>
                      </div>
                    </ButtonBackgroundImage>
                    <ButtonBackgroundImage>
                      <div className="relative shrink-0 size-[9.333px]" data-name="Container">
                        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.33333 9.33333">
                          <g id="Container">
                            <path d={svgPaths.p304ef380} fill="var(--fill-0, #57F2F2)" id="Icon" />
                          </g>
                        </svg>
                      </div>
                    </ButtonBackgroundImage>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex-[1_0_0] gap-x-[24px] gap-y-[24px] grid grid-cols-[repeat(12,minmax(0,1fr))] grid-rows-[_761.02px] min-h-px min-w-px relative w-full" data-name="Container">
              <div className="col-[1/span_3] content-stretch flex flex-col gap-[24px] items-start justify-self-stretch relative row-1 self-stretch shrink-0" data-name="Aside">
                <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Section:mask-group">
                  <div className="absolute backdrop-blur-[6px] bg-[rgba(10,36,36,0.2)] content-stretch flex flex-col gap-[16px] inset-0 items-start mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[282px_637.02px] p-[21px]" data-name="Section" style={{ maskImage: `url('${imgSection}')` }}>
                    <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.05)]" />
                    <div className="h-[19.98px] relative shrink-0 w-full" data-name="VerticalBorder">
                      <div aria-hidden="true" className="absolute border-[#57f2f2] border-l-2 border-solid inset-0 pointer-events-none" />
                      <div className="flex flex-row items-center size-full">
                        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pb-px pl-[14px] relative size-full">
                          <div className="relative shrink-0" data-name="Heading 3">
                            <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[0.98px] relative">
                              <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[20px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[13.3px] tracking-[1.333px] uppercase w-[104.78px]">
                                <p className="leading-[20px]">Modulation</p>
                              </div>
                            </div>
                          </div>
                          <ContainerBackgroundImage1>
                            <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[10.7px] text-[rgba(87,242,242,0.4)] w-[51.17px]">
                              <p className="leading-[16px]">MODE_SEL</p>
                            </div>
                          </ContainerBackgroundImage1>
                        </div>
                      </div>
                    </div>
                    <div className="relative shrink-0 w-full" data-name="Container">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid gap-x-[8px] gap-y-[8px] grid grid-cols-[repeat(2,minmax(0,1fr))] grid-rows-[___34px_34px_34px] relative w-full">
                        <div className="bg-[#57f2f2] col-1 content-stretch flex flex-col items-center justify-center justify-self-start pl-[42.66px] pr-[42.65px] py-[9px] relative row-1 self-start shrink-0" data-name="Button">
                          <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.5)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.4)]" />
                          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[12px] text-center w-[30.69px]">
                            <p className="leading-[16px]">WFM</p>
                          </div>
                        </div>
                        <div className="bg-[rgba(255,255,255,0.05)] col-2 content-stretch flex flex-col items-center justify-center justify-self-start px-[44.31px] py-[9px] relative row-1 self-start shrink-0" data-name="Button">
                          <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.2)] border-solid inset-0 pointer-events-none" />
                          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] text-center w-[27.38px]">
                            <p className="leading-[16px]">NFM</p>
                          </div>
                        </div>
                        <div className="bg-[rgba(255,255,255,0.05)] col-1 content-stretch flex flex-col items-center justify-center justify-self-start pl-[47.92px] pr-[47.94px] py-[9px] relative row-2 self-start shrink-0" data-name="Button">
                          <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.2)] border-solid inset-0 pointer-events-none" />
                          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] text-center w-[20.14px]">
                            <p className="leading-[16px]">AM</p>
                          </div>
                        </div>
                        <div className="bg-[rgba(255,255,255,0.05)] col-2 content-stretch flex flex-col items-center justify-center justify-self-start pl-[47.33px] pr-[47.34px] py-[9px] relative row-2 self-start shrink-0" data-name="Button">
                          <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.2)] border-solid inset-0 pointer-events-none" />
                          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] text-center w-[21.33px]">
                            <p className="leading-[16px]">CW</p>
                          </div>
                        </div>
                        <div className="bg-[rgba(255,255,255,0.05)] col-1 content-stretch flex flex-col items-center justify-center justify-self-start pl-[46.7px] pr-[46.71px] py-[9px] relative row-3 self-start shrink-0" data-name="Button">
                          <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.2)] border-solid inset-0 pointer-events-none" />
                          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] text-center w-[22.59px]">
                            <p className="leading-[16px]">LSB</p>
                          </div>
                        </div>
                        <div className="bg-[rgba(255,255,255,0.05)] col-2 content-stretch flex flex-col items-center justify-center justify-self-start pl-[45.7px] pr-[45.71px] py-[9px] relative row-3 self-start shrink-0" data-name="Button">
                          <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.2)] border-solid inset-0 pointer-events-none" />
                          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] text-center w-[24.59px]">
                            <p className="leading-[16px]">USB</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="relative shrink-0 w-full" data-name="Container">
                      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[24px] items-start pt-[15px] relative w-full">
                        <div className="content-stretch flex flex-col gap-[12px] items-start relative shrink-0 w-full" data-name="Container">
                          <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="Container">
                            <div className="content-stretch flex flex-col items-start pb-[0.98px] relative shrink-0" data-name="Label">
                              <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[20px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[13.3px] tracking-[1.333px] uppercase w-[74.91px]">
                                <p className="leading-[20px]">LNA Gain</p>
                              </div>
                            </div>
                            <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                              <div className="flex flex-col font-['Liberation_Mono:Bold',sans-serif] h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] tracking-[1.333px] uppercase w-[59.75px]">
                                <p className="leading-[16px]">32.8 dB</p>
                              </div>
                            </div>
                          </div>
                          <div className="bg-[rgba(87,242,242,0.1)] h-[4px] relative shrink-0 w-full" data-name="Input">
                            <div className="absolute content-stretch flex items-center justify-center left-0 right-0 top-[-6px]" data-name="Container">
                              <div className="flex-[1_0_0] h-[16px] min-h-px min-w-px" data-name="Container" />
                            </div>
                          </div>
                        </div>
                        <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="Container">
                          <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                            <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] tracking-[1.2px] uppercase w-[62.98px]">
                              <p className="leading-[16px]">Bias Tee</p>
                            </div>
                          </div>
                          <div className="bg-[rgba(87,242,242,0.1)] h-[16px] relative shrink-0 w-[48px]" data-name="Button">
                            <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none" />
                            <div className="absolute bg-[rgba(87,242,242,0.5)] bottom-px left-[2.08%] right-1/2 top-px" data-name="Overlay" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="Section">
                  <div className="backdrop-blur-[6px] bg-[rgba(10,36,36,0.2)] relative shrink-0" data-name="Button">
                    <div className="content-stretch flex gap-[12px] items-center overflow-clip pl-[17px] pr-[82.5px] py-[13px] relative rounded-[inherit]">
                      <ContainerBackgroundImage>
                        <path d={svgPaths.p210dd580} fill="var(--fill-0, #57F2F2)" id="Icon" />
                      </ContainerBackgroundImage>
                      <ContainerBackgroundImage2>
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] text-center tracking-[1.2px] uppercase w-[156.48px]">
                          <p className="leading-[16px]">Frequency Scanner</p>
                        </div>
                      </ContainerBackgroundImage2>
                    </div>
                    <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.05)]" />
                  </div>
                  <div className="backdrop-blur-[6px] bg-[rgba(10,36,36,0.2)] relative shrink-0" data-name="Button">
                    <div className="content-stretch flex gap-[12px] items-center overflow-clip pl-[17px] pr-[154.31px] py-[13px] relative rounded-[inherit]">
                      <ContainerBackgroundImage>
                        <path d={svgPaths.p3f18d400} fill="var(--fill-0, #57F2F2)" id="Icon" />
                      </ContainerBackgroundImage>
                      <ContainerBackgroundImage2>
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[12px] text-center tracking-[1.2px] uppercase w-[84.67px]">
                          <p className="leading-[16px]">Signal Log</p>
                        </div>
                      </ContainerBackgroundImage2>
                    </div>
                    <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.05)]" />
                  </div>
                </div>
              </div>
              <div className="col-[4/span_9] content-stretch flex flex-col gap-[24px] items-start justify-self-stretch relative row-1 self-stretch shrink-0" data-name="Main">
                <div className="backdrop-blur-[6px] bg-[rgba(10,36,36,0.2)] flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Section">
                  <div className="overflow-clip rounded-[inherit] size-full">
                    <div className="content-stretch flex flex-col isolate items-start p-[25px] relative size-full">
                      <div className="relative shrink-0 w-full z-[4]" data-name="Margin">
                        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[24px] relative w-full">
                          <div className="content-stretch flex items-start justify-between relative shrink-0 w-full" data-name="Container">
                            <div className="content-stretch flex flex-col items-start relative shrink-0 w-[220.78px]" data-name="Container">
                              <div className="h-[60px] leading-[0] not-italic relative shrink-0 text-[#57f2f2] w-full" data-name="Paragraph">
                                <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Black',sans-serif] font-black h-[60px] justify-center left-0 text-[60px] top-[30px] tracking-[-3px] w-[169.39px]">
                                  <p className="leading-[60px]">{`-42.5 `}</p>
                                </div>
                                <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Light',sans-serif] font-light h-[28px] justify-center left-[169.39px] opacity-60 text-[20px] top-[45px] tracking-[2px] uppercase w-[51.39px]">
                                  <p className="leading-[28px]">dBm</p>
                                </div>
                              </div>
                              <div className="content-stretch flex flex-col items-start pt-[8px] relative shrink-0 w-full" data-name="Margin">
                                <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-full" data-name="Container">
                                  <div className="bg-[#57f2f2] h-[2px] shrink-0 w-[32px]" data-name="Horizontal Divider" />
                                  <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                                    <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[14px] justify-center leading-[0] not-italic relative shrink-0 text-[9px] text-[rgba(87,242,242,0.7)] tracking-[3.6px] uppercase w-[168.67px]">
                                      <p className="leading-[13.5px]">Signal Flux Density</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="content-stretch flex flex-col gap-[4px] items-end relative shrink-0" data-name="Container">
                              <div className="bg-[rgba(87,242,242,0.05)] content-stretch flex flex-col items-start px-[9px] py-[5px] relative shrink-0" data-name="Overlay+Border">
                                <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.1)] border-solid inset-0 pointer-events-none" />
                                <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(87,242,242,0.6)] w-[90.02px]">
                                  <p className="leading-[15px]">FFT_CORE: 32768</p>
                                </div>
                              </div>
                              <div className="bg-[rgba(87,242,242,0.05)] content-stretch flex flex-col items-start px-[9px] py-[5px] relative shrink-0" data-name="Overlay+Border">
                                <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.1)] border-solid inset-0 pointer-events-none" />
                                <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(87,242,242,0.6)] w-[114.03px]">
                                  <p className="leading-[15px]">SAMPLE_RATE: 10 FPS</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="bg-[rgba(2,6,23,0.4)] flex-[1_0_0] min-h-px min-w-px relative w-full z-[3]" data-name="Overlay+Border">
                        <div className="flex flex-row items-end overflow-clip rounded-[inherit] size-full">
                          <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-end justify-between pl-[33px] pr-[33.27px] py-[17px] relative size-full">
                            <div className="absolute inset-[1px_1px_0.5px_1px] opacity-10" data-name="Gradient" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 842 438.02\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(59.538 0 0 30.973 421 219.01)\\'><stop stop-color=\\'rgba(87,242,242,0.05)\\' offset=\\'0.035355\\'/><stop stop-color=\\'rgba(87,242,242,0)\\' offset=\\'0.035355\\'/></radialGradient></defs></svg>')" }} />
                            <VerticalDividerBackgroundImage additionalClassNames="h-[89.31px]" />
                            <VerticalDividerBackgroundImage additionalClassNames="h-[194.88px]" />
                            <VerticalDividerBackgroundImage additionalClassNames="h-[142.09px]" />
                            <VerticalDividerBackgroundImage1 />
                            <div className="h-[357.28px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider1} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[170.52px]" />
                            <VerticalDividerBackgroundImage2 />
                            <div className="h-[397.89px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider3} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[129.92px]" />
                            <div className="h-[292.33px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider4} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[113.67px]" />
                            <div className="h-[223.3px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider5} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[73.08px]" />
                            <div className="h-[332.92px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider6} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[182.7px]" />
                            <div className="h-[276.08px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider7} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[154.28px]" />
                            <div className="h-[373.53px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider8} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[101.5px]" />
                            <div className="h-[203px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider9} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[129.92px]" />
                            <div className="h-[251.72px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider10} />
                              <BackgroundImage />
                            </div>
                            <div className="h-[345.11px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider11} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[162.41px]" />
                            <VerticalDividerBackgroundImage2 />
                            <VerticalDividerBackgroundImage3 />
                            <VerticalDividerBackgroundImage additionalClassNames="h-[121.8px]" />
                            <div className="h-[304.5px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider13} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[89.31px]" />
                            <div className="h-[211.13px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider14} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[48.72px]" />
                            <div className="h-[316.69px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider15} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[170.52px]" />
                            <VerticalDividerBackgroundImage1 />
                            <VerticalDividerBackgroundImage additionalClassNames="h-[142.09px]" />
                            <div className="h-[365.41px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider16} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[182.7px]" />
                            <div className="h-[243.61px] relative shadow-[0px_0px_10px_0px_rgba(87,242,242,0.4)] shrink-0 w-[2px]" data-name="Vertical Divider">
                              <img alt="" className="absolute bg-clip-padding border-0 border-[transparent] border-solid inset-0 max-w-none object-cover pointer-events-none size-full" src={imgVerticalDivider17} />
                              <BackgroundImage />
                            </div>
                            <VerticalDividerBackgroundImage additionalClassNames="h-[129.92px]" />
                            <VerticalDividerBackgroundImage3 />
                            <div className="absolute bottom-[4.5px] h-[12px] left-px right-px" data-name="Container">
                              <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-between px-[32px] relative size-full">
                                <ContainerBackgroundImageAndText text="88.0_MHZ" />
                                <ContainerBackgroundImageAndText text="96.0_MHZ" />
                                <ContainerBackgroundImageAndText1 text="104.0_MHZ" />
                                <ContainerBackgroundImageAndText1 text="108.0_MHZ" />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.1)] border-solid inset-0 pointer-events-none" />
                      </div>
                      <Section2HorizontalDividerBackgroundImage additionalClassNames="inset-[74.91%_-23px_24.75%_25px] z-[2]" />
                      <Section2HorizontalDividerBackgroundImage additionalClassNames="inset-[25.08%_-23px_74.58%_25px] z-[1]" />
                    </div>
                  </div>
                  <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.05)]" />
                </div>
                <div className="gap-x-[24px] gap-y-[24px] grid grid-cols-[repeat(12,minmax(0,1fr))] grid-rows-[_141.50px] relative shrink-0 w-full" data-name="Section">
                  <OverlayBorderShadowOverlayBlurBackgroundImage additionalClassNames="col-[1/span_8]">
                    <div className="content-stretch flex flex-col items-start justify-center p-[17px] relative w-full">
                      <Heading3MarginBackgroundImage text="Target_Frequency" />
                      <div className="relative shrink-0 w-full" data-name="Container">
                        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center relative w-full">
                          <ButtonBackgroundImage1 additionalClassNames="size-[40px]">
                            <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[28px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[20px] text-center w-[9.2px]">
                              <p className="leading-[28px]">-</p>
                            </div>
                          </ButtonBackgroundImage1>
                          <div className="backdrop-blur-[6px] bg-[rgba(10,36,36,0.2)] flex-[1_0_0] min-h-px min-w-px relative" data-name="Overlay+Border+Shadow+OverlayBlur">
                            <div className="flex flex-row items-center justify-center overflow-clip rounded-[inherit] size-full">
                              <div className="content-stretch flex gap-[0.01px] items-center justify-center p-[17px] relative w-full">
                                <ContainerBackgroundImage1>
                                  <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[48px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[48px] tracking-[-2.4px] w-[290.45px]">
                                    <p className="leading-[48px]">101.300.000</p>
                                  </div>
                                </ContainerBackgroundImage1>
                                <div className="relative shrink-0" data-name="Margin">
                                  <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pl-[16px] relative">
                                    <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-[rgba(87,242,242,0.4)] w-[14.41px]">
                                      <p className="leading-[16px]">HZ</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.05)]" />
                          </div>
                          <ButtonBackgroundImage1 additionalClassNames="size-[40px]">
                            <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[28px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[20px] text-center w-[13.23px]">
                              <p className="leading-[28px]">+</p>
                            </div>
                          </ButtonBackgroundImage1>
                        </div>
                      </div>
                    </div>
                  </OverlayBorderShadowOverlayBlurBackgroundImage>
                  <OverlayBorderShadowOverlayBlurBackgroundImage additionalClassNames="col-[9/span_4]">
                    <div className="content-stretch flex flex-col items-start justify-center px-[17px] py-[27px] relative w-full">
                      <Heading3MarginBackgroundImage text="Delta_Offset" />
                      <div className="relative shrink-0 w-full" data-name="Container">
                        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative w-full">
                          <ButtonBackgroundImage1 additionalClassNames="size-[32px]">
                            <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[16px] text-center w-[7.36px]">
                              <p className="leading-[24px]">-</p>
                            </div>
                          </ButtonBackgroundImage1>
                          <div className="backdrop-blur-[6px] bg-[rgba(10,36,36,0.2)] flex-[1_0_0] min-h-px min-w-px relative" data-name="Overlay+Border+Shadow+OverlayBlur">
                            <div className="flex flex-col items-center justify-center overflow-clip rounded-[inherit] size-full">
                              <div className="content-stretch flex flex-col items-center justify-center p-[9px] relative w-full">
                                <ContainerBackgroundImage1>
                                  <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[28px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[20px] w-[60.02px]">
                                    <p className="leading-[28px]">+12.4</p>
                                  </div>
                                </ContainerBackgroundImage1>
                                <ContainerBackgroundImage1>
                                  <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[10.7px] text-[rgba(87,242,242,0.4)] uppercase w-[19.19px]">
                                    <p className="leading-[16px]">kHz</p>
                                  </div>
                                </ContainerBackgroundImage1>
                              </div>
                            </div>
                            <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_0px_15px_0px_rgba(87,242,242,0.05)]" />
                          </div>
                          <ButtonBackgroundImage1 additionalClassNames="size-[32px]">
                            <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[16px] text-center w-[10.59px]">
                              <p className="leading-[24px]">+</p>
                            </div>
                          </ButtonBackgroundImage1>
                        </div>
                      </div>
                    </div>
                  </OverlayBorderShadowOverlayBlurBackgroundImage>
                </div>
              </div>
            </div>
            <div className="relative shrink-0 w-full" data-name="Footer">
              <div aria-hidden="true" className="absolute border-[rgba(87,242,242,0.2)] border-solid border-t inset-0 pointer-events-none" />
              <div className="flex flex-row items-center size-full">
                <div className="content-stretch flex items-center justify-between pr-[0.01px] pt-[17px] relative w-full">
                  <div className="relative shrink-0" data-name="Container">
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[32px] items-center relative">
                      <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Container">
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(87,242,242,0.5)] tracking-[1px] uppercase w-[29.25px]">
                            <p className="leading-[15px]">Feed</p>
                          </div>
                        </div>
                        <div className="bg-[#57f2f2] content-stretch flex gap-[8px] items-center px-[24px] py-[6px] relative shadow-[0px_0px_15px_0px_rgba(87,242,242,0.3)] shrink-0" data-name="Button">
                          <div className="h-[7px] relative shrink-0 w-[5.5px]" data-name="Container">
                            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.5 7">
                              <g id="Container">
                                <path d={svgPaths.p28600880} fill="var(--fill-0, #020617)" id="Icon" />
                              </g>
                            </svg>
                          </div>
                          <div className="flex flex-col font-['Inter:Black',sans-serif] font-black h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#020617] text-[10px] text-center uppercase w-[69.34px]">
                            <p className="leading-[15px]">Live_Stream</p>
                          </div>
                        </div>
                      </div>
                      <div className="content-stretch flex gap-[16px] items-center relative shrink-0" data-name="Container">
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[10px] text-[rgba(87,242,242,0.5)] tracking-[1px] uppercase w-[48.19px]">
                            <p className="leading-[15px]">Output</p>
                          </div>
                        </div>
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="bg-[rgba(87,242,242,0.1)] h-[38px] relative shrink-0 w-[172px]" data-name="Options">
                            <div aria-hidden="true" className="absolute border border-[rgba(87,242,242,0.2)] border-solid inset-0 pointer-events-none" />
                            <div className="absolute content-stretch flex flex-col h-[38px] items-start justify-center left-0 overflow-clip pl-[148px] pr-[9px] py-[11.5px] top-0 w-[172px]" data-name="image fill">
                              <div className="relative shrink-0 size-[15px]" data-name="SVG">
                                <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
                                  <g id="SVG">
                                    <path d="M4.5 6L7.5 9L10.5 6" id="Vector" stroke="var(--stroke-0, #6B7280)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.125" />
                                  </g>
                                </svg>
                              </div>
                            </div>
                            <div className="-translate-y-1/2 absolute content-stretch flex flex-col items-start left-[25px] overflow-clip top-1/2" data-name="Container">
                              <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[24px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[10px] uppercase w-[105.81px]">
                                <p className="leading-[24px]">Internal Speakers</p>
                              </div>
                            </div>
                          </div>
                          <div className="absolute bottom-[28.95%] content-stretch flex flex-col items-start right-[8px] top-[28.95%]" data-name="Container">
                            <div className="h-[3.7px] relative shrink-0 w-[6px]" data-name="Icon">
                              <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 6 3.7">
                                <path d={svgPaths.p2e72bd00} fill="var(--fill-0, #57F2F2)" fillOpacity="0.6" id="Icon" />
                              </svg>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex-[1_0_0] max-w-[384px] min-h-px min-w-px relative" data-name="Container">
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center max-w-[inherit] relative w-full">
                      <div className="h-[10.208px] relative shrink-0 w-[10.5px]" data-name="Container">
                        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5 10.2083">
                          <g id="Container">
                            <path d={svgPaths.p3b1dd000} fill="var(--fill-0, #57F2F2)" id="Icon" />
                          </g>
                        </svg>
                      </div>
                      <div className="bg-[rgba(87,242,242,0.2)] flex-[1_0_0] h-[2px] min-h-px min-w-px relative" data-name="Input">
                        <div className="absolute content-stretch flex items-center justify-center left-0 right-[-0.48px] top-[-7px]" data-name="Container">
                          <div className="flex-[1_0_0] h-[16px] min-h-px min-w-px" data-name="Container" />
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col items-start relative shrink-0 w-[32px]" data-name="Container">
                        <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#57f2f2] text-[10px] w-[18.02px]">
                          <p className="leading-[15px]">85%</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="relative shrink-0" data-name="Container">
                    <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[24px] items-center relative">
                      <div className="content-stretch flex flex-col items-end relative shrink-0" data-name="Container">
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[12px] justify-center leading-[0] not-italic relative shrink-0 text-[8px] text-[rgba(87,242,242,0.4)] w-[38.41px]">
                            <p className="leading-[12px]">CPU_LOAD</p>
                          </div>
                        </div>
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[18px] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-[rgba(87,242,242,0.8)] w-[21.61px]">
                            <p className="leading-[18px]">12%</p>
                          </div>
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col items-end relative shrink-0" data-name="Container">
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[12px] justify-center leading-[0] not-italic relative shrink-0 text-[8px] text-[rgba(87,242,242,0.4)] w-[43.22px]">
                            <p className="leading-[12px]">BUFFER_LT</p>
                          </div>
                        </div>
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[18px] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-[rgba(87,242,242,0.8)] w-[43.22px]">
                            <p className="leading-[18px]">1024ms</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}