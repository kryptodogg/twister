import clsx from "clsx";
import svgPaths from "./svg-t1qrptee7q";
import imgPlutoSdrUnifiedRxSuite from "figma:asset/cf93f596ab63cd0a9efacd3364a5dfa7414b2e67.png";

function Wrapper3({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="bg-[rgba(8,12,12,0.4)] h-[128px] relative shrink-0 w-full">
      <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col gap-[12px] items-start p-[13px] relative size-full">{children}</div>
    </div>
  );
}

function Container1({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-start relative w-full">{children}</div>
    </div>
  );
}

function Margin1({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pt-[7px] relative w-full">{children}</div>
    </div>
  );
}

function Container({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start justify-center relative size-full">{children}</div>
    </div>
  );
}

function Margin({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[16px] relative w-full">{children}</div>
    </div>
  );
}
type OverlayBorderProps = {
  additionalClassNames?: string;
};

function OverlayBorder({ children, additionalClassNames = "" }: React.PropsWithChildren<OverlayBorderProps>) {
  return (
    <div className={clsx("bg-[rgba(8,12,12,0.4)] justify-self-stretch relative row-1 self-start shrink-0", additionalClassNames)}>
      <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
      <div className="content-stretch flex flex-col gap-[4px] items-start p-[17px] relative w-full">{children}</div>
    </div>
  );
}

function Paragraph({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="h-[32px] relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid font-['Inter:Light',sans-serif] font-light leading-[0] not-italic relative size-full text-[#54acbf] tracking-[-0.6px]">{children}</div>
    </div>
  );
}

function Overlay({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="bg-[rgba(84,172,191,0.2)] relative shrink-0">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start px-[8px] py-[2px] relative">{children}</div>
    </div>
  );
}

function Heading({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative">{children}</div>
    </div>
  );
}

function Wrapper2({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="bg-[rgba(84,172,191,0.1)] relative shrink-0 w-full">
      <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">{children}</div>
    </div>
  );
}

function Wrapper1({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="opacity-80 relative shrink-0 w-full">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative w-full">{children}</div>
    </div>
  );
}

function Wrapper({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="bg-[rgba(8,12,12,0.2)] flex-[1_0_0] min-h-px min-w-px relative w-full">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start p-[17px] relative size-full">{children}</div>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
    </div>
  );
}
type ContainerText4Props = {
  text: string;
};

function ContainerText4({ text }: ContainerText4Props) {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] w-[66.02px]">
        <p className="leading-[15px]">{text}</p>
      </div>
    </div>
  );
}
type ContainerText3Props = {
  text: string;
};

function ContainerText3({ text }: ContainerText3Props) {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0">
      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[14px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[9px] w-[21.61px]">
        <p className="leading-[13.5px]">{text}</p>
      </div>
    </div>
  );
}
type ContainerText2Props = {
  text: string;
};

function ContainerText2({ text }: ContainerText2Props) {
  return (
    <Wrapper1>
      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] tracking-[1px] uppercase w-full">
        <p className="leading-[15px]">{text}</p>
      </div>
    </Wrapper1>
  );
}
type ContainerText1Props = {
  text: string;
};

function ContainerText1({ text }: ContainerText1Props) {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0">
      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[14px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[9px] w-[27.02px]">
        <p className="leading-[13.5px]">{text}</p>
      </div>
    </div>
  );
}
type VerticalBorderProps = {
  additionalClassNames?: string;
};

function VerticalBorder({ additionalClassNames = "" }: VerticalBorderProps) {
  return (
    <div className={clsx("justify-self-stretch relative row-1 self-stretch shrink-0", additionalClassNames)}>
      <div aria-hidden="true" className="absolute border-[rgba(84,172,191,0.1)] border-r border-solid inset-0 pointer-events-none" />
    </div>
  );
}
type ContainerTextProps = {
  text: string;
};

function ContainerText({ text }: ContainerTextProps) {
  return (
    <Wrapper1>
      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] tracking-[1px] w-full">
        <p className="leading-[15px]">{text}</p>
      </div>
    </Wrapper1>
  );
}

export default function PlutoSdrUnifiedRxSuite() {
  return (
    <div className="content-stretch flex items-center justify-center px-[32px] py-[51.2px] relative size-full" data-name="PlutoSDR+ - Unified RX Suite">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 overflow-hidden">
          <img alt="" className="absolute h-[125%] left-0 max-w-none top-[-12.5%] w-full" src={imgPlutoSdrUnifiedRxSuite} />
        </div>
        <div className="absolute bg-[rgba(0,0,0,0.6)] inset-0" />
      </div>
      <div className="backdrop-blur-[4px] bg-[rgba(8,12,12,0.1)] flex-[1_0_0] h-[921.6px] max-w-[1440px] min-h-px min-w-px relative" data-name="Main Fullscreen Slab">
        <div className="content-stretch flex flex-col items-start max-w-[inherit] overflow-clip p-px relative rounded-[inherit] size-full">
          <div className="absolute bg-[rgba(84,172,191,0.05)] blur-[32px] bottom-[-39px] right-[-39px] rounded-[9999px] size-[256px]" data-name="Background Lab Context Element" />
          <Wrapper2>
            <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between pl-[25px] pr-[25.02px] py-[13px] relative w-full">
              <div className="relative shrink-0" data-name="Container">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center relative">
                  <div className="relative shrink-0 size-[24.667px]" data-name="Background">
                    <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.6667 24.6667">
                      <g id="Background">
                        <rect fill="#54ACBF" height="24.6667" width="24.6667" />
                        <path d={svgPaths.p1778a400} fill="var(--fill-0, #080C0C)" id="Icon" />
                      </g>
                    </svg>
                  </div>
                  <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Heading 1">
                    <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[28px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[18px] tracking-[-0.9px] uppercase w-[179.56px]">
                      <p className="leading-[28px]">PlutoSDR+ RX Suite</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-row items-center self-stretch">
                <div className="h-full relative shrink-0" data-name="Tabbed Navigation">
                  <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-full items-center relative">
                    <div className="bg-[#54acbf] content-stretch flex flex-col items-start px-[24px] py-[8px] relative shrink-0" data-name="Link">
                      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#080c0c] text-[12px] tracking-[1.2px] uppercase w-[79.69px]">
                        <p className="leading-[16px]">Reception</p>
                      </div>
                    </div>
                    <div className="content-stretch flex flex-col items-start px-[24px] py-[8px] relative shrink-0" data-name="Link">
                      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[12px] tracking-[1.2px] uppercase w-[69px]">
                        <p className="leading-[16px]">Analysis</p>
                      </div>
                    </div>
                    <div className="content-stretch flex flex-col items-start px-[16px] py-[8px] relative shrink-0" data-name="Link">
                      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[12px] tracking-[1.2px] uppercase w-[57px]">
                        <p className="leading-[16px]">Decode</p>
                      </div>
                    </div>
                    <div className="content-stretch flex flex-col items-start px-[16px] py-[8px] relative shrink-0" data-name="Link">
                      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[12px] tracking-[1.2px] uppercase w-[69.33px]">
                        <p className="leading-[16px]">Settings</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative shrink-0" data-name="Container">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-center relative">
                  <div className="content-stretch flex items-center justify-center relative shrink-0 size-[32px]" data-name="Button">
                    <div className="h-[1.167px] relative shrink-0 w-[8.167px]" data-name="Container">
                      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.16667 1.16667">
                        <g id="Container">
                          <path d={svgPaths.p3ab8d800} fill="var(--fill-0, #54ACBF)" id="Icon" />
                        </g>
                      </svg>
                    </div>
                  </div>
                  <div className="content-stretch flex items-center justify-center relative shrink-0 size-[32px]" data-name="Button">
                    <div className="relative shrink-0 size-[10.5px]" data-name="Container">
                      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5 10.5">
                        <g id="Container">
                          <path d={svgPaths.p2b5b6770} fill="var(--fill-0, #54ACBF)" id="Icon" />
                        </g>
                      </svg>
                    </div>
                  </div>
                  <div className="content-stretch flex items-center justify-center relative shrink-0 size-[32px]" data-name="Button">
                    <div className="relative shrink-0 size-[8.167px]" data-name="Container">
                      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.16667 8.16667">
                        <g id="Container">
                          <path d={svgPaths.p2317cf00} fill="var(--fill-0, #54ACBF)" id="Icon" />
                        </g>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Wrapper2>
          <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Main Content Area: Split RX Channels">
            <div className="overflow-clip rounded-[inherit] size-full">
              <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[24px] items-start p-[24px] relative size-full">
                <div className="content-stretch flex flex-[1_0_0] flex-col gap-[24px] h-full items-start min-h-px min-w-px relative" data-name="Section - RX1 Channel Alpha">
                  <div className="content-stretch flex items-center justify-between pb-[9px] pt-px px-px relative shrink-0 w-full" data-name="Border">
                    <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                    <Heading>
                      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[12px] tracking-[2.4px] uppercase w-[182.27px]">
                        <p className="leading-[16px]">RX1 - Channel Alpha</p>
                      </div>
                    </Heading>
                    <Overlay>
                      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] w-[96.02px]">
                        <p className="leading-[15px]">LOCKED / 4.2 GHz</p>
                      </div>
                    </Overlay>
                  </div>
                  <div className="gap-x-[16px] gap-y-[16px] grid grid-cols-[repeat(3,minmax(0,1fr))] grid-rows-[_85px] relative shrink-0 w-full" data-name="RX1 Tuner Grid">
                    <OverlayBorder additionalClassNames="col-1">
                      <ContainerText text="FREQUENCY" />
                      <Paragraph>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[32px] justify-center left-0 text-[24px] top-[15.5px] w-[89.66px]">
                          <p className="leading-[32px]">{`104.700 `}</p>
                        </div>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[20px] justify-center left-[89.66px] text-[14px] top-[18.5px] w-[28.77px]">
                          <p className="leading-[20px]">MHz</p>
                        </div>
                      </Paragraph>
                    </OverlayBorder>
                    <OverlayBorder additionalClassNames="col-2">
                      <ContainerText text="GAIN" />
                      <Paragraph>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[32px] justify-center left-0 text-[24px] top-[15.5px] w-[53.92px]">
                          <p className="leading-[32px]">{`42.5 `}</p>
                        </div>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[20px] justify-center left-[53.92px] text-[14px] top-[18.5px] w-[16.33px]">
                          <p className="leading-[20px]">dB</p>
                        </div>
                      </Paragraph>
                    </OverlayBorder>
                    <OverlayBorder additionalClassNames="col-3">
                      <ContainerText text="BANDWIDTH" />
                      <Paragraph>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[32px] justify-center left-0 text-[24px] top-[15.5px] w-[48.73px]">
                          <p className="leading-[32px]">{`200 `}</p>
                        </div>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[20px] justify-center left-[48.73px] text-[14px] top-[18.5px] w-[23.56px]">
                          <p className="leading-[20px]">kHz</p>
                        </div>
                      </Paragraph>
                    </OverlayBorder>
                  </div>
                  <Wrapper>
                    <Margin>
                      <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="Container">
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] tracking-[1px] uppercase w-[173.81px]">
                            <p className="leading-[15px]">Holographic Spectral RX1</p>
                          </div>
                        </div>
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] w-[54.02px]">
                            <p className="leading-[15px]">-82.4 dBm</p>
                          </div>
                        </div>
                      </div>
                    </Margin>
                    <Container>
                      <div className="h-[380.09px] overflow-clip relative shrink-0 w-full" data-name="SVG">
                        <div className="absolute inset-[-17.09%_0_-51.7%_0]" data-name="Vector">
                          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 524.834 642.545">
                            <path d={svgPaths.p19f91a20} id="Vector" stroke="var(--stroke-0, #54ACBF)" strokeWidth="0.961296" />
                          </svg>
                        </div>
                        <div className="absolute inset-[-17.09%_0_-51.7%_0]" data-name="Vector">
                          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 524.5 641.583">
                            <path d={svgPaths.pef20280} fill="url(#paint0_linear_1_908)" id="Vector" opacity="0.1" />
                            <defs>
                              <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_908" x1="0" x2="0" y1="3.55033e-06" y2="641.583">
                                <stop stopColor="#54ACBF" />
                                <stop offset="1" stopColor="#54ACBF" stopOpacity="0" />
                              </linearGradient>
                            </defs>
                          </svg>
                        </div>
                      </div>
                      <div className="absolute grid grid-cols-[repeat(8,minmax(0,1fr))] grid-rows-[_380.09px] inset-[0_0_-0.49px_0]" data-name="Grid Overlay">
                        <VerticalBorder additionalClassNames="col-1" />
                        <VerticalBorder additionalClassNames="col-2" />
                        <VerticalBorder additionalClassNames="col-3" />
                        <VerticalBorder additionalClassNames="col-4" />
                        <VerticalBorder additionalClassNames="col-5" />
                        <VerticalBorder additionalClassNames="col-6" />
                        <VerticalBorder additionalClassNames="col-7" />
                      </div>
                    </Container>
                    <Margin1>
                      <div className="h-[14px] opacity-60 relative shrink-0 w-full" data-name="Container">
                        <div className="content-stretch flex items-start justify-between pr-[0.04px] relative size-full">
                          <ContainerText1 text="104.5" />
                          <ContainerText1 text="104.6" />
                          <ContainerText1 text="104.7" />
                          <ContainerText1 text="104.8" />
                          <ContainerText1 text="104.9" />
                        </div>
                      </div>
                    </Margin1>
                  </Wrapper>
                  <Wrapper3>
                    <ContainerText2 text="Modulation Matrix" />
                    <Container1>
                      <div className="bg-[#54acbf] content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[#54acbf] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#080c0c] text-[10px] text-center w-[25.56px]">
                          <p className="leading-[15px]">WFM</p>
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] text-center w-[22.81px]">
                          <p className="leading-[15px]">NFM</p>
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] text-center w-[16.8px]">
                          <p className="leading-[15px]">AM</p>
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] text-center w-[18.83px]">
                          <p className="leading-[15px]">LSB</p>
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] text-center w-[20.48px]">
                          <p className="leading-[15px]">USB</p>
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] text-center w-[17.78px]">
                          <p className="leading-[15px]">CW</p>
                        </div>
                      </div>
                    </Container1>
                  </Wrapper3>
                </div>
                <div className="bg-[rgba(84,172,191,0.2)] h-full shrink-0 w-px" data-name="Divider (Weightless Sticker look)" />
                <div className="content-stretch flex flex-[1_0_0] flex-col gap-[24px] h-full items-start min-h-px min-w-px relative" data-name="Section - RX2 Channel Beta">
                  <div className="content-stretch flex items-center justify-between pb-[9px] pt-px px-px relative shrink-0 w-full" data-name="Border">
                    <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                    <Heading>
                      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[16px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[12px] tracking-[2.4px] uppercase w-[171.94px]">
                        <p className="leading-[16px]">RX2 - Channel Beta</p>
                      </div>
                    </Heading>
                    <Overlay>
                      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] w-[102.03px]">
                        <p className="leading-[15px]">STANDBY / 2.4 GHz</p>
                      </div>
                    </Overlay>
                  </div>
                  <div className="gap-x-[16px] gap-y-[16px] grid grid-cols-[repeat(3,minmax(0,1fr))] grid-rows-[_85px] relative shrink-0 w-full" data-name="RX2 Tuner Grid">
                    <OverlayBorder additionalClassNames="col-1">
                      <ContainerText text="FREQUENCY" />
                      <Paragraph>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[32px] justify-center left-0 text-[24px] top-[15.5px] w-[69.58px]">
                          <p className="leading-[32px]">{`2.442 `}</p>
                        </div>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[20px] justify-center left-[69.58px] text-[14px] top-[18.5px] w-[26.58px]">
                          <p className="leading-[20px]">GHz</p>
                        </div>
                      </Paragraph>
                    </OverlayBorder>
                    <OverlayBorder additionalClassNames="col-2">
                      <ContainerText text="GAIN" />
                      <Paragraph>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[32px] justify-center left-0 text-[24px] top-[15.5px] w-[48.33px]">
                          <p className="leading-[32px]">{`18.0 `}</p>
                        </div>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[20px] justify-center left-[48.33px] text-[14px] top-[18.5px] w-[16.33px]">
                          <p className="leading-[20px]">dB</p>
                        </div>
                      </Paragraph>
                    </OverlayBorder>
                    <OverlayBorder additionalClassNames="col-3">
                      <ContainerText text="BANDWIDTH" />
                      <Paragraph>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[32px] justify-center left-0 text-[24px] top-[15.5px] w-[34.52px]">
                          <p className="leading-[32px]">{`20 `}</p>
                        </div>
                        <div className="-translate-y-1/2 absolute flex flex-col h-[20px] justify-center left-[34.52px] text-[14px] top-[18.5px] w-[28.77px]">
                          <p className="leading-[20px]">MHz</p>
                        </div>
                      </Paragraph>
                    </OverlayBorder>
                  </div>
                  <Wrapper>
                    <Margin>
                      <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="Container">
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] tracking-[1px] uppercase w-[175.8px]">
                            <p className="leading-[15px]">Holographic Spectral RX2</p>
                          </div>
                        </div>
                        <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                          <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] w-[60.02px]">
                            <p className="leading-[15px]">-105.1 dBm</p>
                          </div>
                        </div>
                      </div>
                    </Margin>
                    <Container>
                      <div className="h-[380.09px] overflow-clip relative shrink-0 w-full" data-name="SVG">
                        <div className="absolute inset-[13.33%_0_3.33%_0]" data-name="Vector">
                          <div className="absolute inset-[0_0_-0.15%_0]">
                            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 524.647 317.249">
                              <path d={svgPaths.p3f949080} id="Vector" stroke="var(--stroke-0, #54ACBF)" strokeWidth="0.961296" />
                            </svg>
                          </div>
                        </div>
                        <div className="absolute inset-[13.33%_0_0_0]" data-name="Vector">
                          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 524.5 329.411">
                            <path d={svgPaths.p21ddc7c0} fill="url(#paint0_linear_1_890)" id="Vector" opacity="0.1" />
                            <defs>
                              <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_890" x1="0" x2="0" y1="0" y2="329.411">
                                <stop stopColor="#54ACBF" />
                                <stop offset="1" stopColor="#54ACBF" stopOpacity="0" />
                              </linearGradient>
                            </defs>
                          </svg>
                        </div>
                      </div>
                      <div className="absolute grid grid-cols-[repeat(4,minmax(0,1fr))] grid-rows-[_380.09px] inset-[0_0_-0.49px_0]" data-name="Grid Overlay">
                        <VerticalBorder additionalClassNames="col-1" />
                        <VerticalBorder additionalClassNames="col-2" />
                        <VerticalBorder additionalClassNames="col-3" />
                      </div>
                    </Container>
                    <Margin1>
                      <div className="h-[14px] opacity-60 relative shrink-0 w-full" data-name="Container">
                        <div className="content-stretch flex items-start justify-between pr-[0.01px] relative size-full">
                          <ContainerText3 text="2432" />
                          <ContainerText3 text="2437" />
                          <ContainerText3 text="2442" />
                          <ContainerText3 text="2447" />
                          <ContainerText3 text="2452" />
                        </div>
                      </div>
                    </Margin1>
                  </Wrapper>
                  <Wrapper3>
                    <ContainerText2 text="Modulation Matrix" />
                    <Container1>
                      <div className="content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] text-center w-[28.66px]">
                          <p className="leading-[15px]">AUTO</p>
                        </div>
                      </div>
                      <div className="bg-[#54acbf] content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[#54acbf] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#080c0c] text-[10px] text-center w-[20.23px]">
                          <p className="leading-[15px]">PSK</p>
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] text-center w-[24.14px]">
                          <p className="leading-[15px]">QAM</p>
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] text-center w-[30.13px]">
                          <p className="leading-[15px]">OFDM</p>
                        </div>
                      </div>
                      <div className="content-stretch flex flex-col items-center justify-center px-[17px] py-[5px] relative shrink-0" data-name="Button">
                        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
                        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] text-center w-[26.88px]">
                          <p className="leading-[15px]">DSSS</p>
                        </div>
                      </div>
                    </Container1>
                  </Wrapper3>
                </div>
              </div>
            </div>
          </div>
          <Wrapper2>
            <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-between px-[25px] py-[9px] relative w-full">
              <div className="h-[15px] relative shrink-0" data-name="Container">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[24px] h-full items-start relative">
                  <div className="content-stretch flex gap-[8px] items-center relative self-stretch shrink-0" data-name="Container">
                    <div className="bg-[#54acbf] rounded-[9999px] shrink-0 size-[8px]" data-name="Background" />
                    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                      <div className="flex flex-col font-['Liberation_Mono:Bold',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] tracking-[1px] uppercase w-[168.03px]">
                        <p className="leading-[15px]">DEVICE: PLUTOSDR_01_REVB</p>
                      </div>
                    </div>
                  </div>
                  <div className="content-stretch flex gap-[8px] items-center relative self-stretch shrink-0" data-name="Container">
                    <div className="h-[9px] relative shrink-0 w-[5px]" data-name="Container">
                      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 9">
                        <g id="Container">
                          <path d={svgPaths.p3c1c9f00} fill="var(--fill-0, #54ACBF)" id="Icon" />
                        </g>
                      </svg>
                    </div>
                    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                      <div className="flex flex-col font-['Liberation_Mono:Regular',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] w-[42.02px]">
                        <p className="leading-[15px]">34.2 °C</p>
                      </div>
                    </div>
                  </div>
                  <div className="content-stretch flex gap-[8px] items-center relative self-stretch shrink-0" data-name="Container">
                    <div className="relative shrink-0 size-[9px]" data-name="Container">
                      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 9">
                        <g id="Container">
                          <path d={svgPaths.p1b7ed280} fill="var(--fill-0, #54ACBF)" id="Icon" />
                        </g>
                      </svg>
                    </div>
                    <ContainerText4 text="BUFFER: 42%" />
                  </div>
                </div>
              </div>
              <div className="relative shrink-0" data-name="Container">
                <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[15.99px] items-center relative">
                  <ContainerText4 text="TX DISARMED" />
                  <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
                    <div className="flex flex-col font-['Liberation_Mono:Bold',sans-serif] h-[15px] justify-center leading-[0] not-italic relative shrink-0 text-[#54acbf] text-[10px] w-[78.02px]">
                      <p className="leading-[15px]">UTC: 14:32:05</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Wrapper2>
        </div>
        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.3)] border-solid inset-0 pointer-events-none shadow-[0px_25px_50px_-12px_rgba(0,0,0,0.25)]" />
      </div>
      <div className="absolute backdrop-blur-[4px] bg-[rgba(8,12,12,0.1)] content-stretch flex flex-col gap-[4px] items-start left-[48px] p-[9px] top-[48px]" data-name="Floating UI Elements (Sticker Style)">
        <div aria-hidden="true" className="absolute border border-[rgba(84,172,191,0.4)] border-solid inset-0 pointer-events-none" />
        <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[12px] justify-center leading-[0] not-italic opacity-40 relative shrink-0 text-[#54acbf] text-[8px] tracking-[0.8px] uppercase w-[106.06px]">
          <p className="leading-[12px]">System Diagnostics</p>
        </div>
        <div className="relative shrink-0" data-name="Container">
          <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-start relative">
            <div className="bg-[rgba(84,172,191,0.4)] h-[4px] shrink-0 w-[32px]" data-name="Overlay" />
            <div className="bg-[rgba(84,172,191,0.2)] h-[4px] shrink-0 w-[24px]" data-name="Overlay" />
            <div className="bg-[rgba(84,172,191,0.6)] h-[4px] shrink-0 w-[40px]" data-name="Overlay" />
          </div>
        </div>
      </div>
    </div>
  );
}